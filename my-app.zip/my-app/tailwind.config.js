/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./src/**/*.{js,jsx,ts,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        'cms': {
          primary: '#FFD700', // Main yellow
          hover: '#FFE44D',  // Light yellow for hover
          active: '#FFB700', // Darker yellow for active states
        }
      }
    },
  },
  plugins: [
    require('tailwind-scrollbar')({ nocompatible: true }),
  ],
} 