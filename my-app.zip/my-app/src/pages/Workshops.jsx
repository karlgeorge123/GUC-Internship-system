import { useState } from 'react';

import {
  Box,
  Grid,
  Card,
  CardContent,
  Typography,
  Button,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  Stack,
  IconButton,
  Chip,
  Divider,
  Container,
} from '@mui/material';
import {
  Add as AddIcon,
  Edit as EditIcon,
  Delete as DeleteIcon,
  Event as EventIcon,
  Person as PersonIcon,
  Schedule as ScheduleIcon,
} from '@mui/icons-material';

// Dummy data for workshops
const dummyWorkshops = [
  {
    id: 1,
    name: 'Career Development in Tech',
    date: '2024-04-15',
    time: '14:00',
    description: 'Learn about career paths and opportunities in the tech industry. Discover the skills needed for different roles and how to plan your career progression.',
    speaker: {
      name: 'Dr. Ahmed Hassan',
      bio: 'Senior Tech Lead at Google with 15 years of industry experience. Expert in software architecture and team leadership.',
      expertise: 'Software Engineering, Career Mentoring, Technical Leadership',
    },
    agenda: [
      'Introduction to Tech Careers',
      'Skills Required in Modern Tech',
      'Career Growth Strategies',
      'Industry Trends and Opportunities',
      'Q&A Session',
    ],
    location: 'Room 301, Building B',
    duration: '2 hours',
    capacity: 50,
    registeredCount: 35,
    type: 'Career Development'
  },
  {
    id: 2,
    name: 'Interview Preparation Workshop',
    date: '2024-04-20',
    time: '15:30',
    description: 'Master the art of technical and behavioral interviews. Learn effective techniques for answering common questions and presenting yourself professionally.',
    speaker: {
      name: 'Sarah Mohamed',
      bio: 'HR Manager at Microsoft with expertise in talent acquisition. Over 10 years of experience in tech recruitment.',
      expertise: 'HR, Recruitment, Career Counseling, Interview Techniques',
    },
    agenda: [
      'Common Interview Questions',
      'Technical Interview Tips',
      'Mock Interview Sessions',
      'Body Language and Communication',
      'Feedback and Discussion',
    ],
    location: 'Room 205, Building A',
    duration: '3 hours',
    capacity: 30,
    registeredCount: 25,
    type: 'Skill Development'
  },
  {
    id: 3,
    name: 'Resume Writing Masterclass',
    date: '2024-04-25',
    time: '13:00',
    description: 'Learn how to create a compelling resume that stands out to employers. Focus on highlighting your skills and experiences effectively.',
    speaker: {
      name: 'Dr. Emily Brown',
      bio: 'Career Development Specialist with experience at top tech companies. Professional resume reviewer and career coach.',
      expertise: 'Resume Writing, Personal Branding, Career Coaching',
    },
    agenda: [
      'Resume Structure and Format',
      'Writing Impactful Statements',
      'Portfolio Development',
      'Online Presence Management',
      'Practical Workshop Session',
    ],
    location: 'Room 102, Building C',
    duration: '2.5 hours',
    capacity: 40,
    registeredCount: 38,
    type: 'Skill Development'
  },
  {
    id: 4,
    name: 'Financial Technology Trends',
    date: '2024-04-28',
    time: '11:00',
    description: 'Explore the latest trends in FinTech and their impact on the financial industry. Learn about emerging technologies and career opportunities.',
    speaker: {
      name: 'Dr. Michael Chen',
      bio: 'CTO at FinTech Solutions with extensive experience in financial technology innovation.',
      expertise: 'FinTech, Blockchain, Digital Banking, Innovation',
    },
    agenda: [
      'Current FinTech Landscape',
      'Emerging Technologies',
      'Career Opportunities in FinTech',
      'Industry Case Studies',
      'Networking Session',
    ],
    location: 'Room 401, Building D',
    duration: '2 hours',
    capacity: 45,
    registeredCount: 30,
    type: 'Industry Insights'
  },
  {
    id: 5,
    name: 'Design Thinking Workshop',
    date: '2024-05-02',
    time: '10:00',
    description: 'Learn the principles of design thinking and how to apply them to solve real-world problems. Hands-on workshop with practical exercises.',
    speaker: {
      name: 'Nour Ahmed',
      bio: 'Lead Designer at Creative Design Studio with expertise in UX/UI design and design thinking methodology.',
      expertise: 'UX/UI Design, Design Thinking, Product Design',
    },
    agenda: [
      'Introduction to Design Thinking',
      'User Research Methods',
      'Ideation Techniques',
      'Prototyping Workshop',
      'User Testing Basics',
    ],
    location: 'Design Lab, Building E',
    duration: '4 hours',
    capacity: 25,
    registeredCount: 20,
    type: 'Skill Development'
  },
  {
    id: 6,
    name: 'Consulting Skills Workshop',
    date: '2024-05-05',
    time: '14:30',
    description: 'Develop essential consulting skills including problem-solving, client communication, and project management.',
    speaker: {
      name: 'Dr. Sarah Thompson',
      bio: 'Senior Partner at Global Consulting Firm with 20 years of consulting experience.',
      expertise: 'Management Consulting, Strategy, Business Analysis',

    },
    agenda: [
      'Consulting Fundamentals',
      'Problem-Solving Frameworks',
      'Client Communication',
      'Project Management Essentials',
      'Case Study Analysis',
    ],
    location: 'Room 301, Building A',
    duration: '3 hours',
    capacity: 35,
    registeredCount: 28,
    type: 'Skill Development'
  },
  {
    id: 7,
    name: 'Engineering Leadership',
    date: '2024-05-08',
    time: '13:30',
    description: 'Learn about leadership in engineering contexts, including team management, project leadership, and technical decision-making.',
    speaker: {
      name: 'Eng. Karim Adel',
      bio: 'Engineering Director at Engineering Solutions with extensive experience in leading large-scale projects.',
      expertise: 'Engineering Management, Project Leadership, Technical Strategy',
    },
    agenda: [
      'Engineering Leadership Principles',
      'Team Management',
      'Technical Decision Making',
      'Project Planning',
      'Leadership Case Studies',
    ],
    location: 'Engineering Hall, Building F',
    duration: '2.5 hours',
    capacity: 40,
    registeredCount: 32,
    type: 'Leadership Development'
  }
];

function Workshops() {
  const [workshops, setWorkshops] = useState(dummyWorkshops);
  const [selectedWorkshop, setSelectedWorkshop] = useState(null);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [isDeleteConfirmOpen, setIsDeleteConfirmOpen] = useState(false);
  const [isEditMode, setIsEditMode] = useState(false);

  const [formData, setFormData] = useState({
    name: '',
    date: '',
    time: '',
    description: '',
    speaker: {
      name: '',
      bio: '',
      expertise: '',
    },
    agenda: [''],
  });

  const handleOpenDialog = (workshop = null) => {
    if (workshop) {
      setFormData(workshop);
      setIsEditMode(true);
    } else {
      setFormData({
        name: '',
        date: '',
        time: '',
        description: '',
        speaker: {
          name: '',
          bio: '',
          expertise: '',
        },
        agenda: [''],
      });
      setIsEditMode(false);
    }
    setIsDialogOpen(true);
  };

  const handleCloseDialog = () => {
    setIsDialogOpen(false);
    setSelectedWorkshop(null);
  };

  const handleInputChange = (field, value) => {
    if (field.startsWith('speaker.')) {
      const speakerField = field.split('.')[1];
      setFormData({
        ...formData,
        speaker: {
          ...formData.speaker,
          [speakerField]: value,
        },
      });
    } else {
      setFormData({
        ...formData,
        [field]: value,
      });
    }
  };

  const handleAgendaChange = (index, value) => {
    const newAgenda = [...formData.agenda];
    newAgenda[index] = value;
    setFormData({
      ...formData,
      agenda: newAgenda,
    });
  };

  const handleAddAgendaItem = () => {
    setFormData({
      ...formData,
      agenda: [...formData.agenda, ''],
    });
  };

  const handleRemoveAgendaItem = (index) => {
    const newAgenda = formData.agenda.filter((_, i) => i !== index);
    setFormData({
      ...formData,
      agenda: newAgenda,
    });
  };

  const handleSaveWorkshop = () => {
    if (isEditMode) {
      setWorkshops(
        workshops.map((workshop) =>
          workshop.id === formData.id ? { ...formData } : workshop
        )
      );
    } else {
      setWorkshops([
        ...workshops,
        {
          ...formData,
          id: workshops.length + 1,
        },
      ]);
    }
    handleCloseDialog();
  };

  const handleDeleteWorkshop = (workshop) => {
    setSelectedWorkshop(workshop);
    setIsDeleteConfirmOpen(true);
  };

  const confirmDelete = () => {
    setWorkshops(workshops.filter((w) => w.id !== selectedWorkshop.id));
    setIsDeleteConfirmOpen(false);
    setSelectedWorkshop(null);
  };

  return (

    <Container maxWidth="xl">
      <Box>
        <Box sx={{ 
          display: 'flex', 
          justifyContent: 'space-between', 
          alignItems: 'center', 
          mb: 4 
        }}>
          <Typography variant="h4" sx={{ color: 'text.primary' }}>
            Career Workshops
          </Typography>
          <Button
            variant="contained"
            startIcon={<AddIcon />}
            onClick={() => handleOpenDialog()}
          >
            Add Workshop
          </Button>
        </Box>

        <Grid container spacing={3}>
          {workshops.map((workshop) => (
            <Grid 
              item 
              xs={12} 
              sm={6} 
              md={4} 
              key={workshop.id}
              sx={{ display: 'flex', width: '100%' }}
            >
              <Card sx={{ 
                width: '100%',
                display: 'flex',
                flexDirection: 'column',
                transition: 'all 0.3s ease',
                cursor: 'pointer',
                '&:hover': {
                  transform: 'translateY(-8px)',
                  boxShadow: 6,
                }
              }}>
                <CardContent sx={{ 
                  display: 'flex',
                  flexDirection: 'column',
                  p: 3,
                  '&:last-child': { pb: 3 }
                }}>
                  <Box sx={{ 
                    display: 'flex', 
                    justifyContent: 'space-between', 
                    alignItems: 'flex-start',
                    mb: 2
                  }}>
                    <Typography variant="h6" gutterBottom>
                      {workshop.name}
                    </Typography>
                    <Box>
                      <IconButton
                        size="small"
                        onClick={() => handleOpenDialog(workshop)}
                        sx={{ mr: 1 }}
                      >
                        <EditIcon />
                      </IconButton>
                      <IconButton
                        size="small"
                        color="error"
                        onClick={() => handleDeleteWorkshop(workshop)}
                      >
                        <DeleteIcon />
                      </IconButton>
                    </Box>
                  </Box>
                  <Stack spacing={2}>
                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                      <EventIcon color="action" fontSize="small" />
                      <Typography variant="body2">
                        {workshop.date} at {workshop.time}
                      </Typography>
                    </Box>
                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                      <PersonIcon color="action" fontSize="small" />
                      <Typography variant="body2">
                        {workshop.speaker.name}
                      </Typography>
                    </Box>
                    <Typography variant="body2" color="text.secondary">
                      {workshop.description}
                    </Typography>
                    <Box>
                      <Typography variant="subtitle2" gutterBottom>
                        Agenda:
                      </Typography>
                      <Stack spacing={1}>
                        {workshop.agenda.map((item, index) => (
                          <Chip
                            key={index}
                            label={item}
                            size="small"
                            variant="outlined"
                          />
                        ))}
                      </Stack>
                    </Box>
                  </Stack>
                </CardContent>
              </Card>
            </Grid>
          ))}
        </Grid>

        {/* Workshop Form Dialog */}
        <Dialog open={isDialogOpen} onClose={handleCloseDialog} maxWidth="md" fullWidth>
          <DialogTitle>
            {isEditMode ? 'Edit Workshop' : 'Add New Workshop'}
          </DialogTitle>
          <DialogContent>
            <Stack spacing={3} sx={{ mt: 2 }}>
              <TextField
                label="Workshop Name"
                fullWidth
                value={formData.name}
                onChange={(e) => handleInputChange('name', e.target.value)}
              />
              <Grid container spacing={2}>
                <Grid item xs={12} sm={6}>
                  <TextField
                    label="Date"
                    type="date"
                    fullWidth
                    value={formData.date}
                    onChange={(e) => handleInputChange('date', e.target.value)}
                    InputLabelProps={{ shrink: true }}
                  />
                </Grid>
                <Grid item xs={12} sm={6}>
                  <TextField
                    label="Time"
                    type="time"
                    fullWidth
                    value={formData.time}
                    onChange={(e) => handleInputChange('time', e.target.value)}
                    InputLabelProps={{ shrink: true }}
                  />
                </Grid>
              </Grid>
              <TextField
                label="Description"
                fullWidth
                multiline
                rows={3}
                value={formData.description}
                onChange={(e) => handleInputChange('description', e.target.value)}
              />
              <Divider>Speaker Information</Divider>
              <TextField
                label="Speaker Name"
                fullWidth
                value={formData.speaker.name}
                onChange={(e) => handleInputChange('speaker.name', e.target.value)}
              />
              <TextField
                label="Speaker Bio"
                fullWidth
                multiline
                rows={2}
                value={formData.speaker.bio}
                onChange={(e) => handleInputChange('speaker.bio', e.target.value)}
              />
              <TextField
                label="Speaker Expertise"
                fullWidth
                value={formData.speaker.expertise}
                onChange={(e) => handleInputChange('speaker.expertise', e.target.value)}
              />
              <Divider>Agenda</Divider>
              {formData.agenda.map((item, index) => (
                <Box key={index} sx={{ display: 'flex', gap: 1 }}>
                  <TextField
                    label={`Agenda Item ${index + 1}`}
                    fullWidth
                    value={item}
                    onChange={(e) => handleAgendaChange(index, e.target.value)}
                  />
                  {formData.agenda.length > 1 && (
                    <IconButton
                      color="error"
                      onClick={() => handleRemoveAgendaItem(index)}
                    >
                      <DeleteIcon />
                    </IconButton>
                  )}
                </Box>
              ))}
              <Button
                startIcon={<AddIcon />}
                onClick={handleAddAgendaItem}
                sx={{ alignSelf: 'flex-start' }}
              >
                Add Agenda Item
              </Button>
            </Stack>
          </DialogContent>
          <DialogActions>
            <Button onClick={handleCloseDialog}>Cancel</Button>
            <Button
              variant="contained"
              onClick={handleSaveWorkshop}
              disabled={!formData.name || !formData.date || !formData.time}
            >
              {isEditMode ? 'Update' : 'Create'}
            </Button>
          </DialogActions>
        </Dialog>

        {/* Delete Confirmation Dialog */}
        <Dialog open={isDeleteConfirmOpen} onClose={() => setIsDeleteConfirmOpen(false)}>
          <DialogTitle>Confirm Delete</DialogTitle>
          <DialogContent>
            <Typography>
              Are you sure you want to delete "{selectedWorkshop?.name}"?
            </Typography>
          </DialogContent>
          <DialogActions>
            <Button onClick={() => setIsDeleteConfirmOpen(false)}>Cancel</Button>
            <Button color="error" onClick={confirmDelete}>
              Delete
            </Button>
          </DialogActions>
        </Dialog>
      </Box>
    </Container>
  );
}

export default Workshops; 