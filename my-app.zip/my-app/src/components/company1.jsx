import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import "../styles/company1.css";
import { useJob } from "../context/JobContext";

const JobPostSection = ({ sectionId }) => {
  const {
    company1LeftCards,
    setCompany1LeftCards,
    company1RightCards,
    setCompany1RightCards
  } = useJob();
  
  const [cards, setCards] = useState(
    sectionId === "left" ? company1LeftCards : company1RightCards
  );
  const [activeSearchText, setActiveSearchText] = useState('');
  const [activeCategoryFilter, setActiveCategoryFilter] = useState({ type: '', value: '' });
  const [showModal, setShowModal] = useState(false);
  const [showAddModal, setShowAddModal] = useState(false);
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [showFilterModal, setShowFilterModal] = useState(false);
  const [currentCard, setCurrentCard] = useState(null);
  const [cardToDelete, setCardToDelete] = useState(null);
  const [editMode, setEditMode] = useState(false);
  const [formData, setFormData] = useState({});
  const [filterValue, setFilterValue] = useState('');
  const [selectedFilterType, setSelectedFilterType] = useState('');

  // Update the parent context whenever cards change
  React.useEffect(() => {
    if (sectionId === "left") {
      setCompany1LeftCards(cards);
    } else {
      setCompany1RightCards(cards);
    }
  }, [cards, sectionId, setCompany1LeftCards, setCompany1RightCards]);

  // Initialize cards whenever parent context changes
  React.useEffect(() => {
    setCards(sectionId === "left" ? company1LeftCards : company1RightCards);
  }, [sectionId, company1LeftCards, company1RightCards]);

  const parseContent = (content) => {
    const lines = content.split('\n');
    const data = {
      description: '',
      duration: '',
      paid: '',
      skills: '',
      salary: ''
    };

    lines.forEach(line => {
      const [key, ...rest] = line.split(':');
      if (!key || rest.length === 0) return;

      const value = rest.join(':').trim();
      const normalizedKey = key.trim().toLowerCase();

      if (normalizedKey === 'job description') data.description = value;
      else if (normalizedKey === 'duration') data.duration = value;
      else if (normalizedKey === 'paid') data.paid = value;
      else if (normalizedKey === 'skills required') data.skills = value;
      else if (normalizedKey === 'expected salary') data.salary = value;
    });

    return data;
  };

  const applyCombinedFilters = (card) => {
    const title = card.title.toLowerCase();
    let matchesTitle = true;
    let matchesCategory = true;

    if (activeSearchText) {
      matchesTitle = title.includes(activeSearchText.toLowerCase());
    }

    if (activeCategoryFilter.type && activeCategoryFilter.value) {
      const value = activeCategoryFilter.value.toLowerCase();
      if (sectionId === "left") {
        // Filter logic for left card (applicants)
        matchesCategory = card.internshipPost.toLowerCase().includes(value);
      } else {
        // Filter logic for right card (job posts)
        switch (activeCategoryFilter.type) {
          case 'option1': matchesCategory = card.description.toLowerCase().includes(value); break;
          case 'option2': matchesCategory = card.duration.toLowerCase().includes(value); break;
          case 'option3': matchesCategory = card.paid.toLowerCase().includes(value); break;
          case 'option4': matchesCategory = card.skills.toLowerCase().includes(value); break;
          case 'option5': matchesCategory = card.salary.toLowerCase().includes(value); break;
          default: break;
        }
      }
    }

    return matchesTitle && matchesCategory;
  };

  const handleSearch = (e) => {
    setActiveSearchText(e.target.value);
  };

  const handleCategoryFilter = (e) => {
    const selectedCategory = e.target.value;
    if (!selectedCategory) return;
    
    setSelectedFilterType(selectedCategory);
    setShowFilterModal(true);
  };

  const applyFilter = () => {
    setActiveCategoryFilter({ type: selectedFilterType, value: filterValue.trim() });
    setShowFilterModal(false);
    setFilterValue('');
    setSelectedFilterType('');
  };

  const resetFilters = () => {
    setActiveSearchText('');
    setActiveCategoryFilter({ type: '', value: '' });
  };

  const openModal = (card) => {
    setCurrentCard(card);
    setEditMode(false);
    setShowModal(true);
  };

  const closeModal = () => {
    setShowModal(false);
    setCurrentCard(null);
    setEditMode(false);
  };

  const editMiniCard = (card, e) => {
    e.stopPropagation();
    setCurrentCard(card);
    setEditMode(true);
    setFormData(card);
    setShowModal(true);
  };

  const deleteMiniCard = (card, e) => {
    e.stopPropagation();
    setCardToDelete(card);
    setShowDeleteModal(true);
  };

  const confirmDelete = () => {
    if (cardToDelete) {
      setCards(cards.filter(card => card.title !== cardToDelete.title));
    }
    setShowDeleteModal(false);
    setCardToDelete(null);
  };

  const handleFormChange = (e) => {
    const { name, value } = e.target;
    if (name === 'paid' && value === 'No') {
      setFormData(prev => ({ ...prev, [name]: value, salary: "0" }));
    } else {
      setFormData(prev => ({ ...prev, [name]: value }));
    }
  };

  const saveChanges = () => {
    setCards(cards.map(card => 
      card.title === currentCard.title ? formData : card
    ));
    closeModal();
  };

  const addMiniCard = () => {
    if (!formData.title || !formData.description) {
      alert("Please fill in at least the title and job description.");
      return;
    }
    const newCard = {
      ...formData,
      applications: 0 // Initialize applications count to 0 for new posts
    };
    setCards([...cards, newCard]);
    setShowAddModal(false);
    setFormData({});
  };

  const handleStatusChange = (e) => {
    const newStatus = e.target.value;
    setFormData(prev => ({ ...prev, status: newStatus }));
    
    // If we're not in edit mode, update the card immediately
    if (!editMode) {
      setCards(cards.map(card => 
        card.title === currentCard.title 
          ? { ...card, status: newStatus }
          : card
      ));
    }
  };

  return (
    <div className="card-wrapper">
      <div className="above-content">
        <div className="job-posts-header-card">
          {sectionId === "left" ? (
            <div style={{ textAlign: 'center', width: '100%' }}>Job Applications</div>
          ) : (
            "Job Posts"
          )}
        </div>
      </div>
      <div className="card">
        <div className="search-bar-wrapper">
          <input
            type="text"
            className="search-input"
            placeholder="Search..."
            value={activeSearchText}
            onChange={handleSearch}
          />
        </div>
        <select 
          value={activeCategoryFilter.type} 
          onChange={handleCategoryFilter}
          id={`categoryFilter-${sectionId}`}
        >
          {sectionId === "left" ? (
            // Filter options for left card (applicants)
            <>
              <option value="" hidden>Filter by Category</option>
              <option value="internshipPost">Internship Post</option>
            </>
          ) : (
            // Filter options for right card (job posts)
            <>
              <option value="" hidden>Filter by category</option>
              <option value="option1">Job Description</option>
              <option value="option2">Duration</option>
              <option value="option3">Paid</option>
              <option value="option4">Skills Required</option>
              <option value="option5">Expected Salary</option>
            </>
          )}
        </select>
        <div className="card-scrollable-content">
          {cards.filter(applyCombinedFilters).map((card, index) => (
            <div
              key={`${sectionId}-${index}`}
              className="mini-card"
              onClick={() => openModal(card)}
            >
              <div className="mini-card-content">{card.title}</div>
              <div className="mini-card-icons">
                <span onClick={(e) => editMiniCard(card, e)}>✏️</span>
                <span onClick={(e) => deleteMiniCard(card, e)}>🗑</span>
              </div>
            </div>
          ))}
        </div>
      </div>
      <div style={{ display: 'flex', justifyContent: 'space-between', width: '100%', marginTop: '10px' }}>
        {sectionId === "right" && (
          <button className="primary-btn" onClick={() => setShowAddModal(true)}>
            Add Internship Post
          </button>
        )}
        <button className="primary-btn" onClick={resetFilters} style={{ marginLeft: sectionId === "left" ? 'auto' : '0' }}>
          Reset Filter
        </button>
      </div>

      {showModal && (
        <div className="modal" style={{ display: 'flex' }} id={`modal-${sectionId}`}>
          <div className={`modal-content ${sectionId === "right" ? 'job-post-edit' : ''}`}>
            {sectionId === "left" ? (
              // Left card modal content (Applicant details)
              !editMode ? (
                <div id="popupDisplay">
                  <p><strong>Name:</strong> {currentCard.name}</p>
                  <p><strong>Age:</strong> {currentCard.age}</p>
                  <p><strong>Gender:</strong> {currentCard.gender}</p>
                  <p><strong>Internship Post:</strong> {currentCard.internshipPost}</p>
                  <p><strong>Application Status:</strong> {currentCard.status}</p>
                  {currentCard.status === "Accepted" && (
                    <p><strong>Internship Status:</strong> {currentCard.internshipStatus}</p>
                  )}
                  <div className="modal-buttons">
                    <button className="save-btn" onClick={closeModal}>Close</button>
                  </div>
                </div>
              ) : (
                <div>
                  <div className="form-group">
                    <label>Name:</label>
                    <input
                      type="text"
                      name="name"
                      value={formData.name || ""}
                      disabled
                      style={{ backgroundColor: '#f0f0f0' }}
                    />
                  </div>
                  <div className="form-group">
                    <label>Age:</label>
                    <input
                      type="text"
                      name="age"
                      value={formData.age || ""}
                      disabled
                      style={{ backgroundColor: '#f0f0f0' }}
                    />
                  </div>
                  <div className="form-group">
                    <label>Gender:</label>
                    <input
                      type="text"
                      name="gender"
                      value={formData.gender || ""}
                      disabled
                      style={{ backgroundColor: '#f0f0f0' }}
                    />
                  </div>
                  <div className="form-group">
                    <label>Internship Post:</label>
                    <input
                      type="text"
                      name="internshipPost"
                      value={formData.internshipPost || ""}
                      disabled
                      style={{ backgroundColor: '#f0f0f0' }}
                    />
                  </div>
                  <div className="form-group">
                    <label>Application Status:</label>
                    <select
                      name="status"
                      value={formData.status || ""}
                      onChange={handleFormChange}
                    >
                      <option value="" hidden>Current Status: {currentCard.status}</option>
                      <option value="Finalized">Finalized</option>
                      <option value="Accepted">Accepted</option>
                      <option value="Rejected">Rejected</option>
                    </select>
                  </div>
                  {formData.status === "Accepted" && (
                    <div className="form-group">
                      <label>Internship Status:</label>
                      <select
                        name="internshipStatus"
                        value={formData.internshipStatus || ""}
                        onChange={handleFormChange}
                      >
                        <option value="" hidden>Current Status: {currentCard.internshipStatus || "Not Set"}</option>
                        <option value="Current Intern">Current Intern</option>
                        <option value="Internship Complete">Internship Complete</option>
                      </select>
                    </div>
                  )}
                  <div className="modal-buttons">
                    <button className="save-btn" onClick={saveChanges}>Save</button>
                    <button className="save-btn" onClick={closeModal}>Close</button>
                  </div>
                </div>
              )
            ) : (
              // Right card modal content (remains unchanged)
              !editMode ? (
                <div id="popupDisplay">
                  <p><strong>Internship Title:</strong> {currentCard.title}</p>
                  <p><strong>Job Description:</strong> {currentCard.description}</p>
                  <p><strong>Duration:</strong> {currentCard.duration}</p>
                  <p><strong>Paid:</strong> {currentCard.paid}</p>
                  <p><strong>Skills Required:</strong> {currentCard.skills}</p>
                  <p><strong>Expected Salary:</strong> {currentCard.salary}</p>
                  <p><strong>No. of Applications:</strong> {currentCard.applications}</p>
                  <div className="modal-buttons">
                    <button className="save-btn" onClick={closeModal}>Close</button>
                  </div>
                </div>
              ) : (
                <div>
                  <div className="form-group">
                    <label>Internship Title:</label>
                    <input
                      type="text"
                      name="title"
                      value={formData.title || ""}
                      onChange={handleFormChange}
                    />
                  </div>
                  <div className="form-group">
                    <label>Job Description:</label>
                    <textarea
                      name="description"
                      value={formData.description || ""}
                      onChange={handleFormChange}
                    />
                  </div>
                  <div className="form-group">
                    <label>Duration:</label>
                    <input
                      type="text"
                      name="duration"
                      value={formData.duration || ""}
                      onChange={handleFormChange}
                    />
                  </div>
                  <div className="form-group">
                    <label>Is it Paid?</label>
                    <select
                      name="paid"
                      value={formData.paid || ""}
                      onChange={handleFormChange}
                    >
                      <option value="" hidden>choose an option</option>
                      <option value="Yes">Yes</option>
                      <option value="No">No</option>
                    </select>
                  </div>
                  <div className="form-group">
                    <label>Skills Required:</label>
                    <textarea
                      name="skills"
                      value={formData.skills || ""}
                      onChange={handleFormChange}
                    />
                  </div>
                  <div className="form-group">
                    <label>Expected Salary:</label>
                    <input
                      type="text"
                      name="salary"
                      value={formData.salary || ""}
                      onChange={handleFormChange}
                      disabled={formData.paid === "No"}
                      style={{ backgroundColor: formData.paid === "No" ? '#f0f0f0' : '#fff' }}
                      placeholder="e.g. $1000/month"
                    />
                  </div>
                  <div className="form-group">
                    <label>No. of Applications:</label>
                    <input
                      type="number"
                      name="applications"
                      value={formData.applications || 0}
                      disabled
                      style={{ backgroundColor: '#f0f0f0' }}
                    />
                  </div>
                  <div className="modal-buttons">
                    <button className="save-btn" onClick={saveChanges}>Save</button>
                    <button className="save-btn" onClick={closeModal}>Close</button>
                  </div>
                </div>
              )
            )}
          </div>
        </div>
      )}

      {showAddModal && (
        <div className="modal" style={{ display: 'flex' }} id={`addModal-${sectionId}`}>
          <div className="modal-content">
            <h3 style={{ marginBottom: '15px' }}>Add Internship Post</h3>
            <div className="form-group">
              <label>Internship Title:</label>
              <input
                type="text"
                name="title"
                placeholder="Enter title"
                value={formData.title || ""}
                onChange={handleFormChange}
              />
            </div>
            <div className="form-group">
              <label>Job Description:</label>
              <textarea
                name="description"
                placeholder="Enter job description"
                value={formData.description || ""}
                onChange={handleFormChange}
              />
            </div>
            <div className="form-group">
              <label>Duration:</label>
              <input
                type="text"
                name="duration"
                placeholder="e.g. 3 months"
                value={formData.duration || ""}
                onChange={handleFormChange}
              />
            </div>
            <div className="form-group">
              <label>Is it Paid?</label>
              <select
                name="paid"
                value={formData.paid || ""}
                onChange={handleFormChange}
              >
                <option value="" hidden>choose an option</option>
                <option value="Yes">Yes</option>
                <option value="No">No</option>
              </select>
            </div>
            <div className="form-group">
              <label>Skills Required:</label>
              <textarea
                name="skills"
                placeholder="e.g. HTML, CSS, JavaScript"
                value={formData.skills || ""}
                onChange={handleFormChange}
              />
            </div>
            <div className="form-group">
              <label>Expected Salary:</label>
              <input
                type="text"
                name="salary"
                placeholder="e.g. $1000/month"
                value={formData.salary || ""}
                onChange={handleFormChange}
                disabled={formData.paid === "No"}
                style={{ backgroundColor: formData.paid === "No" ? '#f0f0f0' : '#fff' }}
              />
            </div>
            <div className="modal-buttons">
              <button className="save-btn" onClick={addMiniCard}>Add</button>
              <button className="save-btn" onClick={() => {
                setShowAddModal(false);
                setFormData({});
              }}>Close</button>
            </div>
          </div>
        </div>
      )}

      {showDeleteModal && (
        <div className="modal" style={{ display: 'flex' }} id={`deleteModal-${sectionId}`}>
          <div className="modal-content">
            <p>{sectionId === "left" ? "Are you sure you want to delete this Job Application?" : "Are you sure you want to delete this Job Post?"}</p>
            <div className="modal-buttons">
              <button className="save-btn" onClick={confirmDelete}>Yes</button>
              <button className="save-btn" onClick={() => setShowDeleteModal(false)}>Cancel</button>
            </div>
          </div>
        </div>
      )}

      {showFilterModal && (
        <div className="filter-modal">
          <div className="filter-modal-content">
            <h3>Enter Filter Value</h3>
            <input
              type="text"
              className="filter-input"
              placeholder="Enter value to filter by..."
              value={filterValue}
              onChange={(e) => setFilterValue(e.target.value)}
            />
            <div className="filter-modal-buttons">
              <button className="filter-btn" onClick={applyFilter}>Apply</button>
              <button 
                className="filter-btn" 
                onClick={() => {
                  setShowFilterModal(false);
                  setFilterValue('');
                  setSelectedFilterType('');
                }}
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

const Company1 = () => {
  const navigate = useNavigate();
  const [showNotificationModal, setShowNotificationModal] = useState(false);
  
  // Dummy notification data
  const notifications = [
    {
      id: 1,
      name: "John Smith",
      age: 22,
      position: "UI/UX Designer Internship",
      date: "13/05/2024",
      status: "New",
      email: "john.smith@email.com"
    },
    {
      id: 2,
      name: "Emma Davis",
      age: 23,
      position: "Full Stack Developer Internship",
      date: "13/05/2024",
      status: "New",
      email: "emma.davis@email.com"
    },
    {
      id: 3,
      name: "Michael Chang",
      age: 21,
      position: "Data Science Intern",
      date: "12/05/2024",
      status: "New",
      email: "michael.chang@email.com"
    },
    {
      id: 4,
      name: "Sofia Garcia",
      age: 22,
      position: "AI Research Intern",
      date: "12/05/2024",
      status: "New",
      email: "sofia.garcia@email.com"
    }
  ];

  return (
    <div className="container">
      <header style={{ backgroundColor:'#f5f5f5',display: 'flex', alignItems: 'center', padding: '10px 20px' }}>
        <div style={{ marginLeft: 'auto', display: 'flex', gap: '10px', alignItems: 'center' }}>
          <button 
            className="primary-btn"
            onClick={() => setShowNotificationModal(true)}
            style={{
              display: 'flex',
              alignItems: 'center',
              gap: '5px',
              backgroundColor: '#fff',
              border: '1px solid #ffd54f',
              padding: '8px 16px',
              borderRadius: '4px',
              cursor: 'pointer'
            }}
          >
            🔔 Notifications {notifications.length > 0 && `(${notifications.length})`}
          </button>
          <button className="primary-btn" onClick={() => {
            localStorage.clear();
            window.location.href = '/login';
          }}>
            Logout
          </button>
        </div>
      </header>

      {showNotificationModal && (
        <div className="modal" style={{ display: 'flex' }}>
          <div className="modal-content">
            <h3 style={{ marginBottom: '20px' }}>New Internship Applications</h3>
            <div style={{ maxHeight: '400px', overflowY: 'auto' }}>
              {notifications.map(notification => (
                <div 
                  key={notification.id}
                  style={{
                    padding: '15px',
                    marginBottom: '10px',
                    backgroundColor: '#f5f5f5',
                    borderRadius: '4px',
                    borderLeft: '4px solid #ffd54f'
                  }}
                >
                  <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '5px' }}>
                    <strong>{notification.name}</strong>
                    <span style={{ 
                      backgroundColor: '#ffd54f',
                      padding: '2px 8px',
                      borderRadius: '10px',
                      fontSize: '12px'
                    }}>
                      {notification.status}
                    </span>
                  </div>
                  <p style={{ marginBottom: '5px' }}>Position: {notification.position}</p>
                  <p style={{ marginBottom: '5px' }}>Age: {notification.age}</p>
                  <p style={{ marginBottom: '5px' }}>Email: {notification.email}</p>
                  <p style={{ color: '#666', fontSize: '12px' }}>Applied on: {notification.date}</p>
                </div>
              ))}
            </div>
            <div className="modal-buttons">
              <button className="save-btn" onClick={() => setShowNotificationModal(false)}>Close</button>
            </div>
          </div>
        </div>
      )}

      <main>
        <div className="midsection">
          <div className="card-container">
            <JobPostSection sectionId="left" />
            <JobPostSection sectionId="right" />
          </div>
        </div>
      </main>

      <footer style={{backgroundColor:'#f5f5f5'}}>
        {/* <button className="primary-btn" onClick={() => alert("Previous button clicked")}>Previous</button> */}
        <button style={{marginLeft:'auto'}}className="primary-btn" onClick={() => navigate('/company2')}>Next</button>
      </footer>
    </div>
  );
};

export default Company1;