import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Box,
  Grid,
  Card,
  CardContent,
  Typography,
  Button,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  Stack,
  Chip,
  IconButton,
  Tab,
  Tabs,
  Badge,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
} from '@mui/material';
import {
  VideoCall as VideoCallIcon,
  CheckCircle as CheckCircleIcon,
  Cancel as CancelIcon,
  Schedule as ScheduleIcon,
  Person as PersonIcon,
  CalendarMonth as CalendarMonthIcon,
} from '@mui/icons-material';
import { AdapterDateFns } from '@mui/x-date-pickers/AdapterDateFns';
import { LocalizationProvider, DateTimePicker } from '@mui/x-date-pickers';

// Dummy data for appointments
const dummyAppointments = [
  {
    id: 1,
    studentName: 'Ahmed Mohamed',
    studentId: '2020-12345',
    date: '2024-03-25T14:00:00',
    status: 'pending',
    reason: 'Career guidance - Seeking advice on internship selection',
    type: 'career_guidance',
    isOnline: true,
    scadEmail: 'dr.ahmed@guc.edu.eg'
  },
  {
    id: 2,
    studentName: 'Sarah Ahmed',
    studentId: '2020-12346',
    date: '2024-03-26T15:30:00',
    status: 'accepted',
    reason: 'Report clarification - Need to discuss feedback on latest report',
    type: 'report_clarification',
    isOnline: false,
    scadEmail: 'dr.mohamed@guc.edu.eg'
  },
  {
    id: 3,
    studentName: 'Mohamed Hassan',
    studentId: '2020-12347',
    date: '2024-03-27T11:00:00',
    status: 'rejected',
    reason: 'Career guidance - Discussion about potential career paths',
    type: 'career_guidance',
    isOnline: false,
    scadEmail: 'dr.sara@guc.edu.eg'
  },
  {
    id: 4,
    studentName: 'Nour Ibrahim',
    studentId: '2021-45678',
    date: '2024-03-28T13:00:00',
    status: 'pending',
    reason: 'Report clarification - Questions about technical documentation requirements',
    type: 'report_clarification',
    isOnline: true,
    scadEmail: 'dr.ali@guc.edu.eg'
  },
  {
    id: 5,
    studentName: 'Youssef Ali',
    studentId: '2021-98765',
    date: '2024-03-29T10:00:00',
    status: 'accepted',
    reason: 'Career guidance - Discussing software engineering career opportunities',
    type: 'career_guidance',
    isOnline: true,
    scadEmail: 'dr.nadia@guc.edu.eg'
  },
  {
    id: 6,
    studentName: 'Mariam Khaled',
    studentId: '2020-34567',
    date: '2024-03-29T16:00:00',
    status: 'rejected',
    reason: 'Report clarification - Need help with report formatting',
    type: 'report_clarification',
    isOnline: false,
    scadEmail: 'dr.hassan@guc.edu.eg'
  },
  {
    id: 7,
    studentName: 'Omar Mahmoud',
    studentId: '2021-23456',
    date: '2024-03-30T11:30:00',
    status: 'pending',
    reason: 'Career guidance - Advice on choosing between multiple internship offers',
    type: 'career_guidance',
    isOnline: true,
    scadEmail: 'dr.laila@guc.edu.eg'
  },
  {
    id: 8,
    studentName: 'Rana Adel',
    studentId: '2020-87654',
    date: '2024-03-30T14:30:00',
    status: 'accepted',
    reason: 'Report clarification - Discussion about project outcomes section',
    type: 'report_clarification',
    isOnline: true,
    scadEmail: 'dr.karim@guc.edu.eg'
  },
  {
    id: 9,
    studentName: 'Karim Essam',
    studentId: '2021-34521',
    date: '2024-03-31T09:00:00',
    status: 'pending',
    reason: 'Career guidance - Need advice on resume improvement',
    type: 'career_guidance',
    isOnline: false,
    scadEmail: 'dr.hoda@guc.edu.eg'
  },
  {
    id: 10,
    studentName: 'Hana Mostafa',
    studentId: '2020-65432',
    date: '2024-03-31T13:00:00',
    status: 'rejected',
    reason: 'Report clarification - Questions about technical skills evaluation',
    type: 'report_clarification',
    isOnline: false,
    scadEmail: 'dr.omar@guc.edu.eg'
  }
];

const appointmentTypes = [
  { value: 'career_guidance', label: 'Career Guidance' },
  { value: 'report_clarification', label: 'Report Clarification' },
];

function Appointments() {
  const navigate = useNavigate();
  const [appointments, setAppointments] = useState(dummyAppointments);
  const [selectedDate, setSelectedDate] = useState(null);
  const [currentTab, setCurrentTab] = useState(0);
  const [appointmentDialogOpen, setAppointmentDialogOpen] = useState(false);
  const [selectedAppointment, setSelectedAppointment] = useState(null);
  const [viewedSections, setViewedSections] = useState({
    pending: false,
    accepted: false,
    rejected: false
  });
  const [newAppointment, setNewAppointment] = useState({
    date: null,
    reason: '',
    type: 'career_guidance',
    scadEmail: '',
  });

  const handleTabChange = (event, newValue) => {
    setCurrentTab(newValue);
    // Mark the section as viewed when switching to it
    const sections = ['pending', 'accepted', 'rejected'];
    setViewedSections(prev => ({
      ...prev,
      [sections[newValue]]: true
    }));
  };

  // Get unviewed counts
  const getUnviewedCount = (status) => {
    if (viewedSections[status]) {
      return 0;
    }
    return appointments.filter(a => a.status === status).length;
  };

  const handleAppointmentAction = (appointmentId, action) => {
    setAppointments(appointments.map(appointment => {
      if (appointment.id === appointmentId) {
        return { ...appointment, status: action };
      }
      return appointment;
    }));
    // Reset the viewed status for both the old and new status sections
    setViewedSections(prev => ({
      ...prev,
      [action]: false,
      pending: false
    }));
    setSelectedAppointment(null);
  };

  const handleCreateAppointment = () => {
    const appointment = {
      id: appointments.length + 1,
      studentName: 'Current Student Name', // Would come from auth context
      studentId: 'Current Student ID', // Would come from auth context
      date: newAppointment.date,
      status: 'pending',
      reason: newAppointment.reason,
      type: newAppointment.type,
      isOnline: false,
      scadEmail: newAppointment.scadEmail,
    };
    setAppointments([...appointments, appointment]);
    setAppointmentDialogOpen(false);
    setNewAppointment({ date: null, reason: '', type: 'career_guidance', scadEmail: '' });
    // Reset pending section viewed status when new appointment is added
    setViewedSections(prev => ({
      ...prev,
      pending: false
    }));
  };

  const filteredAppointments = appointments.filter(appointment => {
    if (currentTab === 0) return appointment.status === 'pending';
    if (currentTab === 1) return appointment.status === 'accepted';
    return appointment.status === 'rejected';
  });

  const statusColors = {
    pending: 'warning',
    accepted: 'success',
    rejected: 'error',
  };

  const statusIcons = {
    pending: <ScheduleIcon />,
    accepted: <CheckCircleIcon />,
    rejected: <CancelIcon />,
  };

  return (
    <Box>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 4 }}>
        <Typography variant="h4">
          Appointments
        </Typography>
        <Button
          variant="contained"
          startIcon={<VideoCallIcon />}
          onClick={() => setAppointmentDialogOpen(true)}
        >
          Request Appointment
        </Button>
      </Box>

      <Tabs value={currentTab} onChange={handleTabChange} sx={{ mb: 4 }}>
        <Tab 
          label={
            <Badge 
              badgeContent={getUnviewedCount('pending')} 
              color="warning"
              sx={{ '& .MuiBadge-badge': { display: getUnviewedCount('pending') === 0 ? 'none' : 'block' } }}
            >
              Pending
            </Badge>
          } 
        />
        <Tab 
          label={
            <Badge 
              badgeContent={getUnviewedCount('accepted')} 
              color="success"
              sx={{ '& .MuiBadge-badge': { display: getUnviewedCount('accepted') === 0 ? 'none' : 'block' } }}
            >
              Accepted
            </Badge>
          } 
        />
        <Tab 
          label={
            <Badge 
              badgeContent={getUnviewedCount('rejected')} 
              color="error"
              sx={{ '& .MuiBadge-badge': { display: getUnviewedCount('rejected') === 0 ? 'none' : 'block' } }}
            >
              Rejected
            </Badge>
          } 
        />
      </Tabs>

      <Grid container spacing={3}>
        {filteredAppointments.map((appointment) => (
          <Grid 
            item 
            xs={12} 
            sm={6} 
            md={4} 
            key={appointment.id}
            sx={{ display: 'flex', width: '100%' }}
          >
            <Card 
              sx={{ 
                width: '100%',
                display: 'flex',
                flexDirection: 'column',
                transition: 'all 0.3s ease',
                cursor: 'pointer',
                '&:hover': {
                  transform: 'translateY(-8px)',
                  boxShadow: 6,
                }
              }}
            >
              <CardContent sx={{ 
                display: 'flex',
                flexDirection: 'column',
                p: 3,
                '&:last-child': { pb: 3 }
              }}>
                <Box sx={{ 
                  display: 'flex', 
                  justifyContent: 'space-between', 
                  alignItems: 'flex-start',
                  mb: 2 
                }}>
                  <Typography variant="h6" gutterBottom>
                    {appointment.studentName}
                  </Typography>
                  <Badge
                    overlap="circular"
                    anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}
                    variant="dot"
                    color={appointment.isOnline ? 'success' : 'error'}
                  >
                    <PersonIcon />
                  </Badge>
                </Box>
                
                <Stack spacing={2}>
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                    <CalendarMonthIcon color="action" fontSize="small" />
                    <Typography variant="body2">
                      {new Date(appointment.date).toLocaleString()}
                    </Typography>
                  </Box>

                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                    <PersonIcon color="action" fontSize="small" />
                    <Typography variant="body2">
                      ID: {appointment.studentId}
                    </Typography>
                  </Box>

                  <Box>
                    <Typography variant="subtitle2" gutterBottom>
                      Reason:
                    </Typography>
                    <Typography variant="body2" color="text.secondary">
                      {appointment.reason}
                    </Typography>
                  </Box>

                  <Box sx={{ mt: 'auto', pt: 2, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                    <Chip
                      icon={statusIcons[appointment.status]}
                      label={appointment.status.charAt(0).toUpperCase() + appointment.status.slice(1)}
                      color={statusColors[appointment.status]}
                      sx={{ minWidth: '100px' }}
                    />
                    {appointment.status === 'pending' && (
                      <Box sx={{ display: 'flex', gap: 1 }}>
                        <Button
                          variant="contained"
                          color="error"
                          size="small"
                          onClick={() => handleAppointmentAction(appointment.id, 'rejected')}
                          sx={{ 
                            border: 'none',
                            outline: 'none',
                            '&:focus': {
                              outline: 'none',
                              border: 'none'
                            }
                          }}
                        >
                          Reject
                        </Button>
                        <Button
                          variant="contained"
                          color="success"
                          size="small"
                          onClick={() => handleAppointmentAction(appointment.id, 'accepted')}
                          sx={{ 
                            border: 'none',
                            outline: 'none',
                            '&:focus': {
                              outline: 'none',
                              border: 'none'
                            }
                          }}
                        >
                          Accept
                        </Button>
                      </Box>
                    )}
                    {appointment.status === 'accepted' && (
                      <Button
                        variant="contained"
                        startIcon={<VideoCallIcon />}
                        onClick={() => navigate('/calling', { state: { appointmentData: appointment } })}
                        size="small"
                        sx={{ 
                          border: 'none',
                          outline: 'none',
                          '&:focus': {
                            outline: 'none',
                            border: 'none'
                          }
                        }}
                      >
                        Join Call
                      </Button>
                    )}
                  </Box>
                </Stack>
              </CardContent>
            </Card>
          </Grid>
        ))}
      </Grid>

      {/* New Appointment Dialog */}
      <Dialog 
        open={appointmentDialogOpen} 
        onClose={() => setAppointmentDialogOpen(false)}
        maxWidth="sm"
        fullWidth
      >
        <DialogTitle>Request New Appointment</DialogTitle>
        <DialogContent>
          <Stack spacing={3} sx={{ mt: 1 }}>
            <TextField
              fullWidth
              label="SCAD Member Email"
              type="email"
              value={newAppointment.scadEmail}
              onChange={(e) => setNewAppointment({ ...newAppointment, scadEmail: e.target.value })}
              required
              helperText="Enter the email of the SCAD member you want to meet with"
            />

            <LocalizationProvider dateAdapter={AdapterDateFns}>
              <DateTimePicker
                label="Date & Time"
                value={newAppointment.date}
                onChange={(newValue) => setNewAppointment({ ...newAppointment, date: newValue })}
                renderInput={(params) => <TextField {...params} fullWidth />}
              />
            </LocalizationProvider>

            <FormControl fullWidth>
              <InputLabel>Appointment Type</InputLabel>
              <Select
                value={newAppointment.type}
                label="Appointment Type"
                onChange={(e) => setNewAppointment({ ...newAppointment, type: e.target.value })}
              >
                {appointmentTypes.map((type) => (
                  <MenuItem key={type.value} value={type.value}>
                    {type.label}
                  </MenuItem>
                ))}
              </Select>
            </FormControl>

            <TextField
              fullWidth
              label="Reason for Appointment"
              multiline
              rows={4}
              value={newAppointment.reason}
              onChange={(e) => setNewAppointment({ ...newAppointment, reason: e.target.value })}
            />
          </Stack>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setAppointmentDialogOpen(false)}
            sx={{ 
              border: 'none',
              outline: 'none',
              '&:focus': {
                outline: 'none',
                border: 'none'
              }
            }}
          >
            Cancel
          </Button>
          <Button 
            variant="contained"
            onClick={handleCreateAppointment}
            disabled={!newAppointment.date || !newAppointment.reason || !newAppointment.scadEmail}
            sx={{ 
              border: 'none',
              outline: 'none',
              '&:focus': {
                outline: 'none',
                border: 'none'
              }
            }}
          >
            Request Appointment
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
}

export default Appointments; 