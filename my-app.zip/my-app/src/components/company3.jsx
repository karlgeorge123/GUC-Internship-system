import React, { useRef, useState } from 'react';
import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';
import { useNavigate } from "react-router-dom";
import "../styles/company3.css";

const Company3 = () => {
  const navigate = useNavigate();
  const reportRef = useRef();
  const [showNotificationModal, setShowNotificationModal] = useState(false);
  
  // Dummy notification data - same as other company pages
  const notifications = [
    {
      id: 1,
      name: "John Smith",
      age: 22,
      position: "UI/UX Designer Internship",
      date: "13/05/2024",
      status: "New",
      email: "john.smith@email.com"
    },
    {
      id: 2,
      name: "Emma Davis",
      age: 23,
      position: "Full Stack Developer Internship",
      date: "13/05/2024",
      status: "New",
      email: "emma.davis@email.com"
    },
    {
      id: 3,
      name: "Michael Chang",
      age: 21,
      position: "Data Science Intern",
      date: "12/05/2024",
      status: "New",
      email: "michael.chang@email.com"
    },
    {
      id: 4,
      name: "Sofia Garcia",
      age: 22,
      position: "AI Research Intern",
      date: "12/05/2024",
      status: "New",
      email: "sofia.garcia@email.com"
    }
  ];

  const handleDownloadPdf = async () => {
    const element = reportRef.current;
    const canvas = await html2canvas(element);
    const imgData = canvas.toDataURL('image/png');

    const pdf = new jsPDF();
    const imgProps = pdf.getImageProperties(imgData);
    const pdfWidth = pdf.internal.pageSize.getWidth();
    const pdfHeight = (imgProps.height * pdfWidth) / imgProps.width;

    pdf.addImage(imgData, 'PNG', 0, 0, pdfWidth, pdfHeight);
    pdf.save("monthly-sales-report.pdf");
  };

  return (
    <div className="container">
      <header>
        <div style={{ marginLeft: 'auto', display: 'flex', gap: '10px', alignItems: 'center' }}>
          <button 
            className="primary-btn"
            onClick={() => setShowNotificationModal(true)}
            style={{
              display: 'flex',
              alignItems: 'center',
              gap: '5px',
              backgroundColor: '#fff',
              border: '1px solid #ffd54f',
              padding: '8px 16px',
              borderRadius: '4px',
              cursor: 'pointer'
            }}
          >
            🔔 Notifications {notifications.length > 0 && `(${notifications.length})`}
          </button>
          <button className="primary-btn" onClick={() => {
            localStorage.clear();
            window.location.href = '/login';
          }}>
            Logout
          </button>
        </div>
      </header>

      {showNotificationModal && (
        <div className="modal" style={{ display: 'flex' }}>
          <div className="modal-content">
            <h3 style={{ marginBottom: '20px' }}>New Internship Applications</h3>
            <div style={{ maxHeight: '400px', overflowY: 'auto' }}>
              {notifications.map(notification => (
                <div 
                  key={notification.id}
                  style={{
                    padding: '15px',
                    marginBottom: '10px',
                    backgroundColor: '#f5f5f5',
                    borderRadius: '4px',
                    borderLeft: '4px solid #ffd54f'
                  }}
                >
                  <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '5px' }}>
                    <strong>{notification.name}</strong>
                    <span style={{ 
                      backgroundColor: '#ffd54f',
                      padding: '2px 8px',
                      borderRadius: '10px',
                      fontSize: '12px'
                    }}>
                      {notification.status}
                    </span>
                  </div>
                  <p style={{ marginBottom: '5px' }}>Position: {notification.position}</p>
                  <p style={{ marginBottom: '5px' }}>Age: {notification.age}</p>
                  <p style={{ marginBottom: '5px' }}>Email: {notification.email}</p>
                  <p style={{ color: '#666', fontSize: '12px' }}>Applied on: {notification.date}</p>
                </div>
              ))}
            </div>
            <div className="modal-buttons">
              <button 
                className="save-btn" 
                onClick={() => setShowNotificationModal(false)}
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      <div 
        ref={reportRef} 
        className="report-container"
        style={{
          backgroundColor: '#ffffff',
          padding: '30px',
          fontFamily: 'Arial, sans-serif',
          color: '#000',
          lineHeight: 1.6,
          border: '2px solid #f7e600',
          boxShadow: '0 0 10px rgba(0,0,0,0.1)'
        }}
      >
        <h1 style={{ backgroundColor: '#f7e600', padding: '10px', textAlign: 'center' }}>
          Monthly Sales Report
        </h1>

        <p><strong>Report Date:</strong> May 14, 2025</p>
        <p><strong>Prepared By:</strong> Sales Department</p>

        <h2 style={{ color: '#f7b800' }}>Executive Summary</h2>
        <p>
          This report provides an overview of sales performance for the month of April. 
          Overall, sales increased by 12% compared to the previous month, with notable growth in the EMEA and APAC regions.
        </p>

        <h2 style={{ color: '#f7b800' }}>Key Metrics</h2>
        <ul>
          <li>Total Revenue: $120,000</li>
          <li>New Customers: 45</li>
          <li>Returning Customers: 102</li>
          <li>Top Product: UltraWidget Pro</li>
        </ul>

        <h2 style={{ color: '#f7b800' }}>Regional Breakdown</h2>
        <table 
          style={{
            width: '100%',
            borderCollapse: 'collapse',
            marginBottom: '20px'
          }}
        >
          <thead style={{ backgroundColor: '#fffad0' }}>
            <tr>
              <th style={{ border: '1px solid #ccc', padding: '8px' }}>Region</th>
              <th style={{ border: '1px solid #ccc', padding: '8px' }}>Sales ($)</th>
              <th style={{ border: '1px solid #ccc', padding: '8px' }}>Growth (%)</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td style={{ border: '1px solid #ccc', padding: '8px' }}>North America</td>
              <td style={{ border: '1px solid #ccc', padding: '8px' }}>50,000</td>
              <td style={{ border: '1px solid #ccc', padding: '8px' }}>+8%</td>
            </tr>
            <tr>
              <td style={{ border: '1px solid #ccc', padding: '8px' }}>EMEA</td>
              <td style={{ border: '1px solid #ccc', padding: '8px' }}>40,000</td>
              <td style={{ border: '1px solid #ccc', padding: '8px' }}>+15%</td>
            </tr>
            <tr>
              <td style={{ border: '1px solid #ccc', padding: '8px' }}>APAC</td>
              <td style={{ border: '1px solid #ccc', padding: '8px' }}>30,000</td>
              <td style={{ border: '1px solid #ccc', padding: '8px' }}>+18%</td>
            </tr>
          </tbody>
        </table>

        <h2 style={{ color: '#f7b800' }}>Conclusion</h2>
        <p>
          Continued investment in targeted marketing campaigns is recommended to sustain momentum, 
          especially in high-performing regions.
        </p>
      </div>

      <div style={{ textAlign: 'center', marginTop: '20px', marginBottom: '20px' }}>
        <button 
          onClick={handleDownloadPdf} 
          className="download-btn"
        >
          Download as PDF
        </button>
      </div>
      
      <footer>
        <button className="primary-btn" onClick={() => navigate('/company2')}>Previous</button>
        {/* <button className="primary-btn" onClick={() => alert("Next button clicked")}>Next</button> */}
      </footer>
    </div>
  );
};

export default Company3;
