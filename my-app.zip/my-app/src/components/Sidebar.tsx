'use client';

import { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import {
  LayoutDashboard,
  Building2,
  Briefcase,
  GraduationCap,
  BarChart3,
  Users,
  FileText,
  Menu,
  X
} from 'lucide-react';
import React from 'react';
import LogoutButton from './LogoutButton';

interface NavItem {
  name: string;
  href: string;
  icon: React.ElementType;
}

const navigation: NavItem[] = [
  { name: 'Dashboard', href: '/dashboard', icon: LayoutDashboard },
  { name: 'Company Applications', href: '/company-applications', icon: Building2 },
  { name: 'Internships', href: '/internships', icon: Briefcase },
  { name: 'Workshops', href: '/workshops', icon: GraduationCap },
  { name: 'Statistics', href: '/statistics', icon: BarChart3 },
  { name: 'Students', href: '/students', icon: Users },
  { name: 'Reports', href: '/internship-reports', icon: FileText },
];

interface SidebarProps {
  onLogout: () => void;
}

const Sidebar = ({ onLogout }: SidebarProps) => {
  const [isOpen, setIsOpen] = useState(false);
  const location = useLocation();

  const handleToggle = () => {
    setIsOpen(!isOpen);
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' || e.key === ' ') {
      handleToggle();
    }
  };

  return (
    <>
      {/* Mobile menu button */}
      <button
        onClick={handleToggle}
        onKeyDown={handleKeyDown}
        className="fixed top-4 left-4 z-50 p-2 rounded-md text-gray-700 hover:bg-yellow-100 focus:outline-none focus:ring-2 focus:ring-yellow-500 lg:hidden"
        aria-label="Toggle menu"
        tabIndex={0}
      >
        {isOpen ? <X size={24} /> : <Menu size={24} />}
      </button>

      {/* Sidebar */}
      <aside
        className={`fixed top-0 left-0 w-full max-w-full bg-white shadow-lg transform transition-transform duration-300 ease-in-out z-40
          ${isOpen ? 'translate-y-0' : '-translate-y-full'} lg:translate-y-0 lg:h-auto`}
        style={{ height: isOpen ? 'auto' : '0', overflow: isOpen ? 'visible' : 'hidden' }}
      >
        <div className="flex flex-col h-full">
          {/* Logo */}
          <div className="p-6 border-b border-gray-200">
          </div>

          {/* Navigation */}
          <nav className="flex-1 px-4 py-8 space-y-[100px] overflow-y-auto">
            {navigation.map((item) => {
              const isActive = location.pathname === item.href;
              return (
                <Link
                  key={item.name}
                  to={item.href}
                  className={`flex items-center px-4 py-6 text-sm font-medium rounded-lg transition-colors duration-200 ml-8
                    ${isActive
                      ? 'bg-yellow-100 text-yellow-700'
                      : 'text-gray-700 hover:bg-yellow-50 hover:text-yellow-600'
                    }`}
                  aria-current={isActive ? 'page' : undefined}
                  onClick={() => setIsOpen(false)}
                >
                  <item.icon
                    className={`mr-3 h-5 w-5 ${
                      isActive ? 'text-yellow-600' : 'text-gray-500'
                    }`}
                    aria-hidden="true"
                  />
                  {item.name}
                </Link>
              );
            })}
          </nav>
        </div>
      </aside>

      {/* Logout button rendered through portal */}
      <LogoutButton onLogout={onLogout} />

      {/* Overlay */}
      {isOpen && (
        <div
          className="fixed inset-0 bg-black bg-opacity-50 z-30 lg:hidden"
          onClick={handleToggle}
          aria-hidden="true"
        />
      )}
    </>
  );
};

export default Sidebar; 