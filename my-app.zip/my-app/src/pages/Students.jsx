import { useState } from 'react';

import {
  Box,
  Grid,
  Card,
  CardContent,
  Typography,
  Button,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Chip,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Avatar,
  Stack,
  Divider,
} from '@mui/material';
import {
  School as SchoolIcon,
  Work as WorkIcon,
  Assignment as AssignmentIcon,
} from '@mui/icons-material';


// Dummy data for students
const dummyStudents = [
  {
    id: 1,
    name: 'Ahmed Mohamed',
    studentId: '2020-12345',
    major: 'Computer Science',
    gpa: 3.7,
    email: 'ahmed.mohamed@student.guc.edu.eg',
    phone: '+20 123 456 7890',
    internshipStatus: 'enrolled',
    currentInternship: {
      company: 'Tech Solutions Inc.',
      position: 'Software Developer Intern',
      startDate: '2024-02-01',
      endDate: '2024-05-01',
    },
    academicYear: 'Senior',
    completedInternships: 1,
    avatar: '👨‍🎓',
  },
  {
    id: 2,
    name: 'Sarah Ahmed',
    studentId: '2020-12346',
    major: 'Business Administration',
    gpa: 3.5,
    email: 'sarah.ahmed@student.guc.edu.eg',
    phone: '+20 123 456 7891',
    internshipStatus: 'seeking',
    academicYear: 'Junior',
    completedInternships: 0,
    avatar: '👩‍🎓',
  },
  {
    id: 3,
    name: 'Mohamed Hassan',
    studentId: '2020-12347',
    major: 'Computer Science',
    gpa: 3.8,
    email: 'mohamed.hassan@student.guc.edu.eg',
    phone: '+20 123 456 7892',
    internshipStatus: 'completed',
    completedInternships: 2,
    academicYear: 'Senior',
    lastInternship: {
      company: 'Global Tech Corp',
      position: 'Software Engineer Intern',
      startDate: '2023-06-01',
      endDate: '2023-09-01',
    },
    avatar: '👨‍🎓',
  },
  {
    id: 4,
    name: 'Nour Ibrahim',
    studentId: '2020-12348',
    major: 'Finance',
    gpa: 3.9,
    email: 'nour.ibrahim@student.guc.edu.eg',
    phone: '+20 123 456 7893',
    internshipStatus: 'enrolled',
    currentInternship: {
      company: 'FinTech Solutions',
      position: 'Financial Analyst Intern',
      startDate: '2024-03-01',
      endDate: '2024-06-01',
    },
    academicYear: 'Senior',
    completedInternships: 1,
    avatar: '👩‍🎓',
  },
  {
    id: 5,
    name: 'Omar Khalil',
    studentId: '2020-12349',
    major: 'Computer Science',
    gpa: 3.6,
    email: 'omar.khalil@student.guc.edu.eg',
    phone: '+20 123 456 7894',
    internshipStatus: 'seeking',
    academicYear: 'Junior',
    completedInternships: 1,
    lastInternship: {
      company: 'Tech Innovators',
      position: 'Mobile Developer Intern',
      startDate: '2023-06-01',
      endDate: '2023-09-01',
    },
    avatar: '👨‍🎓',
  },
  {
    id: 6,
    name: 'Yara Mahmoud',
    studentId: '2020-12350',
    major: 'Graphic Design',
    gpa: 3.7,
    email: 'yara.mahmoud@student.guc.edu.eg',
    phone: '+20 123 456 7895',
    internshipStatus: 'completed',
    completedInternships: 2,
    academicYear: 'Senior',
    lastInternship: {
      company: 'Creative Design Studio',
      position: 'UI/UX Design Intern',
      startDate: '2024-01-01',
      endDate: '2024-03-01',
    },
    avatar: '👩‍🎓',
  },
  {
    id: 7,
    name: 'Karim Adel',
    studentId: '2020-12351',
    major: 'Business Administration',
    gpa: 3.4,
    email: 'karim.adel@student.guc.edu.eg',
    phone: '+20 123 456 7896',
    internshipStatus: 'enrolled',
    currentInternship: {
      company: 'Global Consulting Firm',
      position: 'Business Analyst Intern',
      startDate: '2024-02-15',
      endDate: '2024-05-15',
    },
    academicYear: 'Junior',
    completedInternships: 0,
    avatar: '👨‍🎓',
  },
  {
    id: 8,
    name: 'Layla Hassan',
    studentId: '2020-12352',
    major: 'Engineering',
    gpa: 3.8,
    email: 'layla.hassan@student.guc.edu.eg',
    phone: '+20 123 456 7897',
    internshipStatus: 'seeking',
    academicYear: 'Senior',
    completedInternships: 1,
    lastInternship: {
      company: 'Engineering Solutions',
      position: 'Mechanical Engineer Intern',
      startDate: '2023-06-01',
      endDate: '2023-09-01',
    },
    avatar: '👩‍🎓',
  }
];

const statusColors = {
  enrolled: 'success',
  seeking: 'warning',
  completed: 'info',
};

const statusLabels = {
  enrolled: 'Currently Enrolled',
  seeking: 'Seeking Internship',
  completed: 'Completed',
};

function Students() {
  const [students, setStudents] = useState(dummyStudents);
  const [selectedStatus, setSelectedStatus] = useState('all');
  const [selectedStudent, setSelectedStudent] = useState(null);
  const [detailsOpen, setDetailsOpen] = useState(false);

  const handleStatusChange = (event) => {
    setSelectedStatus(event.target.value);
  };

  const filteredStudents = students.filter((student) => {
    if (selectedStatus === 'all') return true;
    return student.internshipStatus === selectedStatus;
  });

  const handleViewProfile = (student) => {
    setSelectedStudent(student);
    setDetailsOpen(true);
  };

  return (

    <Box>
      <Typography variant="h4" gutterBottom>
        Students
      </Typography>

      <Box sx={{ mb: 4 }}>
        <FormControl sx={{ minWidth: 200 }}>
          <InputLabel>Filter by Status</InputLabel>
          <Select
            value={selectedStatus}
            label="Filter by Status"
            onChange={handleStatusChange}
          >
            <MenuItem value="all">All Students</MenuItem>
            <MenuItem value="enrolled">Currently Enrolled</MenuItem>
            <MenuItem value="seeking">Seeking Internship</MenuItem>
            <MenuItem value="completed">Completed</MenuItem>
          </Select>
        </FormControl>
      </Box>

      <Grid container spacing={3}>
        {filteredStudents.map((student) => (
          <Grid item xs={12} md={6} key={student.id}>
            <Card sx={{
              width: '100%',
              transition: 'all 0.3s ease',
              cursor: 'pointer',
              '&:hover': {
                transform: 'translateY(-8px)',
                boxShadow: 6,
              }
            }}>
              <CardContent>
                <Box sx={{ display: 'flex', alignItems: 'center', mb: 2, gap: 2 }}>
                  <Avatar sx={{ width: 56, height: 56, fontSize: '2rem' }}>
                    {student.avatar}
                  </Avatar>
                  <Box>
                    <Typography variant="h6" gutterBottom>
                      {student.name}
                    </Typography>
                    <Typography color="text.secondary">
                      ID: {student.studentId}
                    </Typography>
                  </Box>
                </Box>
                <Stack spacing={1.5} sx={{ mb: 3 }}>
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5 }}>
                    <SchoolIcon color="action" />
                    <Typography variant="body2">
                      {student.major} • {student.academicYear}
                    </Typography>
                  </Box>
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5 }}>
                    <WorkIcon color="action" />
                    <Typography variant="body2">
                      Completed Internships: {student.completedInternships}
                    </Typography>
                  </Box>
                </Stack>
                <Box sx={{ 
                  display: 'flex', 
                  justifyContent: 'space-between', 
                  alignItems: 'center',
                  mt: 2,
                  gap: 3 
                }}>
                  <Chip
                    label={statusLabels[student.internshipStatus]}
                    color={statusColors[student.internshipStatus]}
                    sx={{ minWidth: '140px', justifyContent: 'center' }}
                  />
                  <Button
                    variant="contained"
                    onClick={() => handleViewProfile(student)}
                    sx={{ minWidth: '120px' }}
                  >
                    View Profile
                  </Button>
                </Box>
              </CardContent>
            </Card>
          </Grid>
        ))}
      </Grid>

      <Dialog open={detailsOpen} onClose={() => setDetailsOpen(false)} maxWidth="md" fullWidth>
        {selectedStudent && (
          <>
            <DialogTitle>
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
                <Avatar sx={{ width: 64, height: 64, fontSize: '2rem' }}>
                  {selectedStudent.avatar}
                </Avatar>
                <Box>
                  <Typography variant="h6">{selectedStudent.name}</Typography>
                  <Typography variant="subtitle1" color="text.secondary">
                    Student ID: {selectedStudent.studentId}
                  </Typography>
                </Box>
              </Box>
            </DialogTitle>
            <DialogContent>
              <Grid container spacing={3}>
                <Grid item xs={12} md={6}>
                  <Typography variant="subtitle1" gutterBottom>
                    Academic Information
                  </Typography>
                  <Stack spacing={2}>
                    <Box>
                      <Typography variant="body2" color="text.secondary">
                        Major
                      </Typography>
                      <Typography variant="body1">
                        {selectedStudent.major}
                      </Typography>
                    </Box>
                    <Box>
                      <Typography variant="body2" color="text.secondary">
                        Academic Year
                      </Typography>
                      <Typography variant="body1">
                        {selectedStudent.academicYear}
                      </Typography>
                    </Box>
                    <Box>
                      <Typography variant="body2" color="text.secondary">
                        GPA
                      </Typography>
                      <Typography variant="body1">
                        {selectedStudent.gpa}
                      </Typography>
                    </Box>
                  </Stack>
                </Grid>
                <Grid item xs={12} md={6}>
                  <Typography variant="subtitle1" gutterBottom>
                    Contact Information
                  </Typography>
                  <Stack spacing={2}>
                    <Box>
                      <Typography variant="body2" color="text.secondary">
                        Email
                      </Typography>
                      <Typography variant="body1">
                        {selectedStudent.email}
                      </Typography>
                    </Box>
                    <Box>
                      <Typography variant="body2" color="text.secondary">
                        Phone
                      </Typography>
                      <Typography variant="body1">
                        {selectedStudent.phone}
                      </Typography>
                    </Box>
                  </Stack>
                </Grid>
                <Grid item xs={12}>
                  <Divider sx={{ my: 2 }} />
                  <Typography variant="subtitle1" gutterBottom>
                    Internship Status
                  </Typography>
                  {selectedStudent.internshipStatus === 'enrolled' && selectedStudent.currentInternship && (
                    <Box>
                      <Typography variant="body2" color="text.secondary">
                        Current Internship
                      </Typography>
                      <Card variant="outlined" sx={{ mt: 1 }}>
                        <CardContent>
                          <Typography variant="subtitle2">
                            {selectedStudent.currentInternship.position}
                          </Typography>
                          <Typography color="text.secondary">
                            {selectedStudent.currentInternship.company}
                          </Typography>
                          <Typography variant="body2" sx={{ mt: 1 }}>
                            {selectedStudent.currentInternship.startDate} - {selectedStudent.currentInternship.endDate}
                          </Typography>
                        </CardContent>
                      </Card>
                    </Box>
                  )}
                  {selectedStudent.internshipStatus === 'completed' && selectedStudent.lastInternship && (
                    <Box>
                      <Typography variant="body2" color="text.secondary">
                        Last Completed Internship
                      </Typography>
                      <Card variant="outlined" sx={{ mt: 1 }}>
                        <CardContent>
                          <Typography variant="subtitle2">
                            {selectedStudent.lastInternship.position}
                          </Typography>
                          <Typography color="text.secondary">
                            {selectedStudent.lastInternship.company}
                          </Typography>
                          <Typography variant="body2" sx={{ mt: 1 }}>
                            {selectedStudent.lastInternship.startDate} - {selectedStudent.lastInternship.endDate}
                          </Typography>
                        </CardContent>
                      </Card>
                    </Box>
                  )}
                </Grid>
              </Grid>
            </DialogContent>
            <DialogActions>
              <Button onClick={() => setDetailsOpen(false)}>Close</Button>
            </DialogActions>
          </>
        )}
      </Dialog>
    </Box>
  );
}

export default Students; 