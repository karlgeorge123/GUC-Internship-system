import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import "../styles/company2.css";
import { useJob } from "../context/JobContext";

const JobPostSection = ({ sectionId }) => {
  const {
    company2LeftCards,
    setCompany2LeftCards,
    company2RightCards,
    setCompany2RightCards
  } = useJob();
  
  const [cards, setCards] = useState(
    sectionId === "left" ? company2LeftCards : company2RightCards
  );
  const [activeSearchText, setActiveSearchText] = useState('');
  const [activeCategoryFilter, setActiveCategoryFilter] = useState({ type: '', value: '' });
  const [showModal, setShowModal] = useState(false);
  const [showFilterModal, setShowFilterModal] = useState(false);
  const [showEvaluationModal, setShowEvaluationModal] = useState(false);
  const [showDeleteEvalModal, setShowDeleteEvalModal] = useState(false);
  const [showViewEvalModal, setShowViewEvalModal] = useState(false);
  const [isEditingEvaluation, setIsEditingEvaluation] = useState(false);
  const [currentCard, setCurrentCard] = useState(null);
  const [filterValue, setFilterValue] = useState('');
  const [selectedFilterType, setSelectedFilterType] = useState('');
  const [evaluationData, setEvaluationData] = useState({
    performance: '',
    skills: '',
    attitude: '',
    comments: '',
    rating: ''
  });

  // Update the parent context whenever cards change
  React.useEffect(() => {
    if (sectionId === "left") {
      setCompany2LeftCards(cards);
    } else {
      setCompany2RightCards(cards);
    }
  }, [cards, sectionId, setCompany2LeftCards, setCompany2RightCards]);

  // Initialize cards whenever parent context changes
  React.useEffect(() => {
    setCards(sectionId === "left" ? company2LeftCards : company2RightCards);
  }, [sectionId, company2LeftCards, company2RightCards]);

  const parseContent = (content) => {
    const lines = content.split('\n');
    const data = {
      description: '',
      duration: '',
      paid: '',
      skills: '',
      salary: ''
    };

    lines.forEach(line => {
      const [key, ...rest] = line.split(':');
      if (!key || rest.length === 0) return;

      const value = rest.join(':').trim();
      const normalizedKey = key.trim().toLowerCase();

      if (normalizedKey === 'job description') data.description = value;
      else if (normalizedKey === 'duration') data.duration = value;
      else if (normalizedKey === 'paid') data.paid = value;
      else if (normalizedKey === 'skills required') data.skills = value;
      else if (normalizedKey === 'expected salary') data.salary = value;
    });

    return data;
  };

  const applyCombinedFilters = (card) => {
    let matchesTitle = true;
    let matchesCategory = true;

    if (activeSearchText) {
      const searchText = activeSearchText.toLowerCase();
      if (sectionId === "left") {
        // Search in both name and internshipPost for left section
        matchesTitle = card.name.toLowerCase().includes(searchText) || 
                      (card.internshipPost && card.internshipPost.toLowerCase().includes(searchText));
      } else {
        // For right section, search in title and company name
        matchesTitle = card.title.toLowerCase().includes(searchText) ||
                      card.companyName.toLowerCase().includes(searchText);
      }
    }

    if (activeCategoryFilter.type && activeCategoryFilter.value) {
      const value = activeCategoryFilter.value.toLowerCase();
      if (sectionId === "left") {
        matchesCategory = card.internshipStatus && card.internshipStatus.toLowerCase().includes(value);
      } else {
        switch (activeCategoryFilter.type) {
          case 'industry': 
            matchesCategory = card.industry.toLowerCase().includes(value);
            break;
          case 'duration': 
            matchesCategory = card.duration.toLowerCase().includes(value);
            break;
          case 'paid': 
            matchesCategory = card.paid.toLowerCase() === value.toLowerCase();
            break;
          default: 
            break;
        }
      }
    }

    return matchesTitle && matchesCategory;
  };

  const handleSearch = (e) => {
    setActiveSearchText(e.target.value);
  };

  const handleCategoryFilter = (e) => {
    const selectedCategory = e.target.value;
    if (!selectedCategory) return;
    
    setSelectedFilterType(selectedCategory);
    setShowFilterModal(true);
  };

  const applyFilter = () => {
    setActiveCategoryFilter({ type: selectedFilterType, value: filterValue.trim() });
    setShowFilterModal(false);
    setFilterValue('');
    setSelectedFilterType('');
  };

  const resetFilters = () => {
    setActiveSearchText('');
    setActiveCategoryFilter({ type: '', value: '' });
  };

  const openModal = (card) => {
    setCurrentCard(card);
    setShowModal(true);
  };

  const closeModal = () => {
    setShowModal(false);
    setCurrentCard(null);
  };

  const handleEvaluationChange = (e) => {
    const { name, value } = e.target;
    setEvaluationData(prev => ({ ...prev, [name]: value }));
  };

  const editEvaluation = () => {
    setEvaluationData(currentCard.evaluation);
    setIsEditingEvaluation(true);
    setShowEvaluationModal(true);
    setShowModal(false);
  };

  const saveEvaluation = () => {
    const updatedCards = cards.map(card => 
      card.name === currentCard.name 
        ? { ...card, evaluation: evaluationData }
        : card
    );
    setCards(updatedCards);
    setShowEvaluationModal(false);
    setCurrentCard({ ...currentCard, evaluation: evaluationData });
    setShowModal(true);
    setIsEditingEvaluation(false);
    setEvaluationData({
      performance: '',
      skills: '',
      attitude: '',
      comments: '',
      rating: ''
    });
  };

  const deleteEvaluation = () => {
    const updatedCards = cards.map(card => 
      card.name === currentCard.name 
        ? { ...card, evaluation: null }
        : card
    );
    setCards(updatedCards);
    setShowDeleteEvalModal(false);
    setCurrentCard({ ...currentCard, evaluation: null });
    setShowModal(true);
  };

  const viewEvaluation = (e, card) => {
    e.stopPropagation();
    setCurrentCard(card);
    setShowViewEvalModal(true);
  };

  return (
    <div className="card-wrapper">
      <div className="above-content">
        <div className="job-posts-header-card">
          {sectionId === "left" ? (
            <div style={{ textAlign: 'center', width: '100%' }}>My Interns</div>
          ) : (
            "SCAD Internships"
          )}
        </div>
      </div>
      <div className="card">
        <div className="search-bar-wrapper">
          <input
            type="text"
            className="search-input"
            placeholder="Search"
            value={activeSearchText}
            onChange={handleSearch}
          />
        </div>
        <select 
          value={activeCategoryFilter.type} 
          onChange={handleCategoryFilter}
          id={`categoryFilter-${sectionId}`}
        >
          {sectionId === "left" ? (
            <>
              <option value="" hidden>Filter by Category</option>
              <option value="internshipStatus">Internship Status</option>
            </>
          ) : (
            <>
              <option value="" hidden>Filter by category</option>
              <option value="industry">Industry</option>
              <option value="duration">Duration</option>
              <option value="paid">Paid</option>
            </>
          )}
        </select>
        <div className="card-scrollable-content">
          {cards.filter(applyCombinedFilters).map((card, index) => (
            <div
              key={`${sectionId}-${index}`}
              className="mini-card"
              onClick={() => openModal(card)}
            >
              <div className="mini-card-content">
                {sectionId === "left" ? (
                  <>
                    <div style={{ fontWeight: 'bold', marginBottom: '4px' }}>{card.name}</div>
                    <div>{card.internshipPost}</div>
                    {card.internshipStatus === "Internship Complete" && card.evaluation && (
                      <button
                        className="view-eval-btn"
                        onClick={(e) => viewEvaluation(e, card)}
                        style={{
                          marginTop: '4px',
                          padding: '2px 8px',
                          fontSize: '12px',
                          backgroundColor: '#ffd54f',
                          border: '1px solid #ffc107',
                          borderRadius: '4px',
                          cursor: 'pointer'
                        }}
                      >
                        👁️ View Evaluation
                      </button>
                    )}
                  </>
                ) : (
                  <>
                    <div style={{ fontWeight: 'bold', marginBottom: '4px' }}>{card.companyName}</div>
                    <div>{card.title}</div>
                  </>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>
      <div style={{ display: 'flex', justifyContent: 'space-between', width: '100%', marginTop: '10px' }}>
        <button className="primary-btn" onClick={resetFilters} style={{ marginLeft: 'auto' }}>
          Reset Filter
        </button>
      </div>

      {showModal && (
        <div className="modal" style={{ display: 'flex' }} id={`modal-${sectionId}`}>
          <div className="modal-content">
            {sectionId === "left" ? (
              <div id="popupDisplay">
                <p><strong>Name:</strong> {currentCard.name}</p>
                <p><strong>Age:</strong> {currentCard.age}</p>
                <p><strong>Gender:</strong> {currentCard.gender}</p>
                <p><strong>Internship Title:</strong> {currentCard.internshipPost}</p>
                {(currentCard.status === "Accepted" || currentCard.status === "Finalized") && (
                  <p><strong>Internship Status:</strong> {currentCard.internshipStatus}</p>
                )}
                {currentCard.internshipStatus === "Internship Complete" && (
                  <div className="modal-buttons" style={{ marginTop: '10px' }}>
                    {currentCard.evaluation ? (
                      <button 
                        className="primary-btn"
                        onClick={() => {
                          setShowViewEvalModal(true);
                          setShowModal(false);
                        }}
                      >
                        👁️ View Evaluation
                      </button>
                    ) : (
                      <button 
                        className="primary-btn" 
                        onClick={() => {
                          setShowEvaluationModal(true);
                          setShowModal(false);
                        }}
                      >
                        Add Evaluation
                      </button>
                    )}
                  </div>
                )}
                <div className="modal-buttons">
                  <button className="save-btn" onClick={closeModal}>Close</button>
                </div>
              </div>
            ) : (
              <div id="popupDisplay">
                <p><strong>Company Name:</strong> {currentCard.companyName}</p>
                <p><strong>Industry:</strong> {currentCard.industry}</p>
                <p><strong>Internship Title:</strong> {currentCard.title}</p>
                <p><strong>Job Description:</strong> {currentCard.description}</p>
                <p><strong>Duration:</strong> {currentCard.duration}</p>
                <p><strong>Paid:</strong> {currentCard.paid}</p>
                <p><strong>Skills Required:</strong> {currentCard.skills}</p>
                <p><strong>Expected Salary:</strong> {currentCard.salary}</p>
                <div className="modal-buttons">
                  <button className="save-btn" onClick={closeModal}>Close</button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {showFilterModal && (
        <div className="filter-modal">
          <div className="filter-modal-content">
            <h3>Enter Filter Value</h3>
            {selectedFilterType === 'paid' ? (
              <select
                className="filter-input"
                value={filterValue}
                onChange={(e) => setFilterValue(e.target.value)}
              >
                <option value="" hidden>Select option</option>
                <option value="Yes">Yes</option>
                <option value="No">No</option>
              </select>
            ) : selectedFilterType === 'internshipStatus' ? (
              <select
                className="filter-input"
                value={filterValue}
                onChange={(e) => setFilterValue(e.target.value)}
              >
                <option value="" hidden>Select status</option>
                <option value="Current Intern">Current Intern</option>
                <option value="Internship Complete">Internship Complete</option>
              </select>
            ) : (
              <input
                type="text"
                className="filter-input"
                placeholder={
                  selectedFilterType === 'industry' 
                    ? "Enter industry (e.g., Technology, Software Development)" 
                    : selectedFilterType === 'duration'
                    ? "Enter duration (e.g., 3 months, 6 months)"
                    : "Enter value to filter by..."
                }
                value={filterValue}
                onChange={(e) => setFilterValue(e.target.value)}
              />
            )}
            <div className="filter-modal-buttons">
              <button className="filter-btn" onClick={applyFilter}>Apply</button>
              <button 
                className="filter-btn" 
                onClick={() => {
                  setShowFilterModal(false);
                  setFilterValue('');
                  setSelectedFilterType('');
                }}
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}

      {showEvaluationModal && (
        <div className="modal" style={{ display: 'flex' }}>
          <div className="modal-content">
            <h3>{isEditingEvaluation ? 'Edit Evaluation' : 'Add Evaluation'} - {currentCard.name}</h3>
            <div className="form-group">
              <label>Performance Assessment:</label>
              <textarea
                name="performance"
                value={evaluationData.performance}
                onChange={handleEvaluationChange}
                placeholder="Assess the intern's overall performance and achievement of objectives..."
              />
            </div>
            <div className="form-group">
              <label>Skills Development:</label>
              <textarea
                name="skills"
                value={evaluationData.skills}
                onChange={handleEvaluationChange}
                placeholder="Evaluate the technical and soft skills developed during the internship..."
              />
            </div>
            <div className="form-group">
              <label>Work Attitude:</label>
              <textarea
                name="attitude"
                value={evaluationData.attitude}
                onChange={handleEvaluationChange}
                placeholder="Comment on professionalism, initiative, and team collaboration..."
              />
            </div>
            <div className="form-group">
              <label>Additional Comments:</label>
              <textarea
                name="comments"
                value={evaluationData.comments}
                onChange={handleEvaluationChange}
                placeholder="Any additional feedback or recommendations..."
              />
            </div>
            <div className="form-group">
              <label>Overall Rating (1-5):</label>
              <select
                name="rating"
                value={evaluationData.rating}
                onChange={handleEvaluationChange}
              >
                <option value="" hidden>Select rating</option>
                <option value="1">1 - Poor</option>
                <option value="2">2 - Fair</option>
                <option value="3">3 - Good</option>
                <option value="4">4 - Very Good</option>
                <option value="5">5 - Excellent</option>
              </select>
            </div>
            <div className="modal-buttons">
              <button className="save-btn" onClick={saveEvaluation}>
                {isEditingEvaluation ? 'Update Evaluation' : 'Submit Evaluation'}
              </button>
              <button 
                className="save-btn"
                onClick={() => {
                  setShowEvaluationModal(false);
                  setShowModal(true);
                  setIsEditingEvaluation(false);
                  setEvaluationData({
                    performance: '',
                    skills: '',
                    attitude: '',
                    comments: '',
                    rating: ''
                  });
                }}
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}

      {showDeleteEvalModal && (
        <div className="modal" style={{ display: 'flex' }}>
          <div className="modal-content">
            <h3>Delete Evaluation</h3>
            {/* <p>{sectionId === "left" ? "Are you sure you want to delete this Job Application?" : "Are you sure you want to delete this Job Post?"}</p> */}
            <p>{sectionId === "left" ? "Are you sure you want to delete this Job Evaluation?" : "Are you sure you want to delete this Job Evaluation?"}</p>
            <p>This action cannot be undone.</p>
            <div className="modal-buttons">
              <button className="save-btn" onClick={deleteEvaluation}>Delete</button>
              <button className="save-btn" onClick={() => setShowDeleteEvalModal(false)}>Cancel</button>
            </div>
          </div>
        </div>
      )}

      {showViewEvalModal && (
        <div className="modal" style={{ display: 'flex' }}>
          <div className="modal-content">
            <h3>Evaluation for {currentCard.name}</h3>
            <div className="evaluation-details" style={{ margin: '20px 0' }}>
              <p><strong>Performance:</strong> {currentCard.evaluation.performance}</p>
              <p><strong>Skills Development:</strong> {currentCard.evaluation.skills}</p>
              <p><strong>Work Attitude:</strong> {currentCard.evaluation.attitude}</p>
              <p><strong>Additional Comments:</strong> {currentCard.evaluation.comments}</p>
              <p><strong>Overall Rating:</strong> {currentCard.evaluation.rating}/5</p>
            </div>
            <div className="modal-buttons">
              <button 
                className="icon-btn"
                onClick={() => {
                  setShowViewEvalModal(false);
                  editEvaluation();
                }}
                style={{ marginRight: '8px' }}
              >
                ✏️ Edit
              </button>
              <button 
                className="icon-btn"
                onClick={() => {
                  setShowViewEvalModal(false);
                  setShowDeleteEvalModal(true);
                }}
                style={{ marginRight: '8px' }}
              >
                🗑️ Delete
              </button>
              <button 
                className="save-btn"
                onClick={() => setShowViewEvalModal(false)}
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

const Company2 = () => {
  const navigate = useNavigate();
  const [showNotificationModal, setShowNotificationModal] = useState(false);
  
  // Dummy notification data
  const notifications = [
    {
      id: 1,
      name: "John Smith",
      age: 22,
      position: "UI/UX Designer Internship",
      date: "13/05/2024",
      status: "New",
      email: "john.smith@email.com"
    },
    {
      id: 2,
      name: "Emma Davis",
      age: 23,
      position: "Full Stack Developer Internship",
      date: "13/05/2024",
      status: "New",
      email: "emma.davis@email.com"
    },
    {
      id: 3,
      name: "Michael Chang",
      age: 21,
      position: "Data Science Intern",
      date: "12/05/2024",
      status: "New",
      email: "michael.chang@email.com"
    },
    {
      id: 4,
      name: "Sofia Garcia",
      age: 22,
      position: "AI Research Intern",
      date: "12/05/2024",
      status: "New",
      email: "sofia.garcia@email.com"
    }
  ];

  return (
    <div className="container">
      <header style={{backgroundColor:'#f5f5f5',display: 'flex', alignItems: 'center', padding: '10px 20px' }}>
        <div style={{ marginLeft: 'auto', display: 'flex', gap: '10px', alignItems: 'center' }}>
          <button 
            className="primary-btn"
            onClick={() => setShowNotificationModal(true)}
            style={{
              display: 'flex',
              alignItems: 'center',
              gap: '5px',
              backgroundColor: '#fff',
              border: '1px solid #ffd54f',
              padding: '8px 16px',
              borderRadius: '4px',
              cursor: 'pointer'
            }}
          >
            🔔 Notifications {notifications.length > 0 && `(${notifications.length})`}
          </button>
          <button className="primary-btn" onClick={() => {
            localStorage.clear();
            window.location.href = '/login';
          }}>
            Logout
          </button>
        </div>
      </header>

      {showNotificationModal && (
        <div className="modal" style={{ display: 'flex' }}>
          <div className="modal-content">
            <h3 style={{ marginBottom: '20px' }}>New Internship Applications</h3>
            <div style={{ maxHeight: '400px', overflowY: 'auto' }}>
              {notifications.map(notification => (
                <div 
                  key={notification.id}
                  style={{
                    padding: '15px',
                    marginBottom: '10px',
                    backgroundColor: '#f5f5f5',
                    borderRadius: '4px',
                    borderLeft: '4px solid #ffd54f'
                  }}
                >
                  <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '5px' }}>
                    <strong>{notification.name}</strong>
                    <span style={{ 
                      backgroundColor: '#ffd54f',
                      padding: '2px 8px',
                      borderRadius: '10px',
                      fontSize: '12px'
                    }}>
                      {notification.status}
                    </span>
                  </div>
                  <p style={{ marginBottom: '5px' }}>Position: {notification.position}</p>
                  <p style={{ marginBottom: '5px' }}>Age: {notification.age}</p>
                  <p style={{ marginBottom: '5px' }}>Email: {notification.email}</p>
                  <p style={{ color: '#666', fontSize: '12px' }}>Applied on: {notification.date}</p>
                </div>
              ))}
            </div>
            <div className="modal-buttons">
              <button 
                className="save-btn"
                onClick={() => setShowNotificationModal(false)}
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      <main>
        <div className="midsection">
          <div className="card-container">
            <JobPostSection sectionId="left" />
            <JobPostSection sectionId="right" />
          </div>
        </div>
      </main>

      <footer style={{backgroundColor:'#f5f5f5'}}>
        <button style={{marginright:'auto'}} className="primary-btn" onClick={() => navigate('/company1')}>Previous</button>
         <button style={{marginleft:'auto'}} className="primary-btn" onClick={() => navigate('/company3')}>Next</button> 
      </footer>
    </div>
  );
};

export default Company2;