import { useState } from 'react';
import { MagnifyingGlassIcon } from '@heroicons/react/24/outline';

const CompanyApplications = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [industryFilter, setIndustryFilter] = useState('all');

  // Dummy data
  const companies = [
    {
      id: 1,
      name: 'Tech Solutions Inc.',
      industry: 'Technology',
      date: '2024-03-15',
      status: 'Pending',
    },
    {
      id: 2,
      name: 'Global Finance Ltd.',
      industry: 'Finance',
      date: '2024-03-14',
      status: 'Approved',
    },
    {
      id: 3,
      name: 'Healthcare Plus',
      industry: 'Healthcare',
      date: '2024-03-13',
      status: 'Rejected',
    },
    // Add more dummy data as needed
  ];

  const industries = ['all', 'Technology', 'Finance', 'Healthcare', 'Manufacturing', 'Retail'];

  const filteredCompanies = companies.filter(company => {
    const matchesSearch = company.name.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesIndustry = industryFilter === 'all' || company.industry === industryFilter;
    return matchesSearch && matchesIndustry;
  });

  const handleStatusChange = (companyId, newStatus) => {
    // In a real application, this would make an API call
    console.log(`Changing status of company ${companyId} to ${newStatus}`);
  };

  return (
    <div className="dashboard-container">
      <div className="section-card p-6 !w-[1000px] !h-[800px] !max-w-[1000px] overflow-auto" style={{ marginLeft: '300px' }}>
        <h1 className="text-2xl font-semibold text-gray-900">Company Applications</h1>
        <p className="mt-1 text-sm text-gray-500">
          Review and manage company applications for internships.
        </p>

        {/* Filters */}
        <div className="flex flex-col sm:flex-row gap-4 mt-6">
          <div className="flex-1">
            <div className="relative rounded-md shadow-sm">
              <input
                type="text"
                className="block w-full rounded-md border-0 py-2 pl-9 text-gray-900 ring-1 ring-inset ring-gray-300 placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-[#FFD700] sm:text-sm sm:leading-6 bg-[url('data:image/svg+xml;utf8,<svg xmlns=%22http://www.w3.org/2000/svg%22 fill=%22none%22 viewBox=%220 0 24 24%22 stroke-width=%221.5%22 stroke=%22currentColor%22 class=%22w-4 h-4%22><path stroke-linecap=%22round%22 stroke-linejoin=%22round%22 d=%22M21 21l-5.197-5.197m0 0A7.5 7.5 0 105.196 5.196a7.5 7.5 0 0010.607 10.607z%22 /></svg>')] bg-no-repeat bg-[length:16px_16px] bg-[center_left_12px]"
                placeholder="Search companies..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
          </div>
          <div className="sm:w-48">
            <select
              className="block w-full rounded-md border-0 py-2 pl-3 pr-10 text-gray-900 ring-1 ring-inset ring-gray-300 focus:ring-2 focus:ring-[#FFD700] sm:text-sm sm:leading-6"
              value={industryFilter}
              onChange={(e) => setIndustryFilter(e.target.value)}
            >
              {industries.map((industry) => (
                <option key={industry} value={industry}>
                  {industry.charAt(0).toUpperCase() + industry.slice(1)}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Table */}
        <div className="mt-8 flow-root">
          <div className="-mx-4 -my-2 overflow-x-auto sm:-mx-6 lg:-mx-8">
            <div className="inline-block min-w-full py-2 align-middle">
              <div className="overflow-hidden shadow-sm ring-1 ring-black ring-opacity-5 rounded-lg">
                <table className="min-w-full divide-y divide-gray-300">
                  <thead className="bg-gray-50">
                    <tr>
                      <th scope="col" className="py-3.5 pl-4 pr-3 text-left text-sm font-semibold text-gray-900 sm:pl-6">
                        Name
                      </th>
                      <th scope="col" className="px-3 py-3.5 text-left text-sm font-semibold text-gray-900">
                        Industry
                      </th>
                      <th scope="col" className="px-3 py-3.5 text-left text-sm font-semibold text-gray-900">
                        Date
                      </th>
                      <th scope="col" className="px-3 py-3.5 text-left text-sm font-semibold text-gray-900">
                        Status
                      </th>
                      <th scope="col" className="relative py-3.5 pl-3 pr-4 sm:pr-6">
                        <span className="sr-only">Actions</span>
                      </th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-200 bg-white">
                    {filteredCompanies.map((company) => (
                      <tr key={company.id} className="hover:bg-gray-50 transition-colors duration-200">
                        <td className="whitespace-nowrap py-4 pl-4 pr-3 text-sm font-medium text-gray-900 sm:pl-6">
                          {company.name}
                        </td>
                        <td className="whitespace-nowrap px-3 py-4 text-sm text-gray-500">
                          {company.industry}
                        </td>
                        <td className="whitespace-nowrap px-3 py-4 text-sm text-gray-500">
                          {company.date}
                        </td>
                        <td className="whitespace-nowrap px-3 py-4 text-sm text-gray-500">
                          <span
                            className={`inline-flex rounded-full px-2 text-xs font-semibold leading-5 ${
                              company.status === 'Approved'
                                ? 'bg-green-100 text-green-800'
                                : company.status === 'Rejected'
                                ? 'bg-red-100 text-red-800'
                                : 'bg-yellow-100 text-yellow-800'
                            }`}
                          >
                            {company.status}
                          </span>
                        </td>
                        <td className="relative whitespace-nowrap py-4 pl-3 pr-4 text-right text-sm font-medium sm:pr-6">
                          {company.status === 'Pending' && (
                            <div className="flex justify-end space-x-2">
                              <button
                                onClick={() => handleStatusChange(company.id, 'Approved')}
                                className="text-green-600 hover:text-green-900 transition-colors duration-200"
                              >
                                Approve
                              </button>
                              <button
                                onClick={() => handleStatusChange(company.id, 'Rejected')}
                                className="text-red-600 hover:text-red-900 transition-colors duration-200"
                              >
                                Reject
                              </button>
                            </div>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CompanyApplications; 