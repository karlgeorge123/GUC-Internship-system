import { useState } from 'react';
import {
  Box,
  TextField,
  MenuItem,
  Grid,
  Card,
  CardContent,
  Typography,
  Button,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Chip,
} from '@mui/material';

// Dummy data for companies
const dummyCompanies = [
  {
    id: 1,
    name: 'Tech Solutions Inc.',
    industry: 'Software Development',
    status: 'pending',
    description: 'Leading software development company specializing in enterprise solutions, cloud computing, and mobile applications. We work with cutting-edge technologies and offer comprehensive training programs for both technical and soft skills development.',
    location: 'Cairo, Egypt',
    website: 'www.techsolutions.com',
    contactPerson: 'Ahmed Hassan',
    email: 'ahmed@techsolutions.com',
    phone: '+20 123 456 7890',
    employeeCount: '100-500',
    foundedYear: 2010,
    internshipHistory: {
      totalInterns: 45,
      successRate: '92%',
      averageRating: 4.8
    }
  },
  {
    id: 2,
    name: 'Global Marketing Group',
    industry: 'Marketing',
    status: 'pending',
    description: 'International marketing agency with focus on digital transformation, brand development, and social media marketing. We provide hands-on experience in modern marketing techniques and comprehensive digital strategy training for future marketers.',
    location: 'Alexandria, Egypt',
    website: 'www.gmg.com',
    contactPerson: 'Sarah Mohamed',
    email: 'sarah@gmg.com',
    phone: '+20 123 456 7891',
    employeeCount: '50-100',
    foundedYear: 2015,
    internshipHistory: {
      totalInterns: 30,
      successRate: '88%',
      averageRating: 4.6
    }
  },
  {
    id: 3,
    name: 'FinTech Solutions',
    industry: 'Finance',
    status: 'accepted',
    description: 'Innovative financial technology company providing cutting-edge solutions for banking and investment sectors. We offer comprehensive training in financial analysis, technology implementation, and modern fintech practices for aspiring professionals.',
    location: 'Cairo, Egypt',
    website: 'www.fintechsolutions.com',
    contactPerson: 'Mohamed Ibrahim',
    email: 'mohamed@fintechsolutions.com',
    phone: '+20 123 456 7892',
    employeeCount: '100-500',
    foundedYear: 2012,
    internshipHistory: {
      totalInterns: 35,
      successRate: '90%',
      averageRating: 4.7
    }
  },
  {
    id: 4,
    name: 'Creative Design Studio',
    industry: 'Design',
    status: 'rejected',
    description: 'Creative agency specializing in UI/UX design, branding, and digital media production. We provide a collaborative environment for learning design principles and hands-on experience with industry-standard tools and creative workflows.',
    location: 'Cairo, Egypt',
    website: 'www.creativedesign.com',
    contactPerson: 'Nour Ahmed',
    email: 'nour@creativedesign.com',
    phone: '+20 123 456 7893',
    employeeCount: '10-50',
    foundedYear: 2018,
    internshipHistory: {
      totalInterns: 15,
      successRate: '85%',
      averageRating: 4.3
    }
  },
  {
    id: 5,
    name: 'AI Research Lab',
    industry: 'Software Development',
    status: 'accepted',
    description: 'Research-focused company specializing in artificial intelligence and machine learning solutions. We offer unique opportunities to work on cutting-edge AI projects while learning from experienced researchers and industry professionals.',
    location: 'Giza, Egypt',
    website: 'www.airesearchlab.com',
    contactPerson: 'Dr. Omar Khalil',
    email: 'omar@airesearchlab.com',
    phone: '+20 123 456 7894',
    employeeCount: '50-100',
    foundedYear: 2016,
    internshipHistory: {
      totalInterns: 25,
      successRate: '95%',
      averageRating: 4.9
    }
  },
  {
    id: 6,
    name: 'Global Consulting Firm',
    industry: 'Consulting',
    status: 'pending',
    description: 'International consulting firm offering services in business strategy, operations, and digital transformation. We provide comprehensive training in consulting methodologies, project management, and real-world business problem-solving techniques.',
    location: 'Cairo, Egypt',
    website: 'www.globalconsulting.com',
    contactPerson: 'Layla Hassan',
    email: 'layla@globalconsulting.com',
    phone: '+20 123 456 7895',
    employeeCount: '500+',
    foundedYear: 2008,
    internshipHistory: {
      totalInterns: 50,
      successRate: '87%',
      averageRating: 4.5
    }
  },
  {
    id: 7,
    name: 'Engineering Solutions',
    industry: 'Engineering',
    status: 'accepted',
    description: 'Leading engineering firm specializing in mechanical, electrical, and civil engineering projects. We offer practical experience in real-world engineering challenges and comprehensive technical training programs with industry-leading experts.',
    location: 'Alexandria, Egypt',
    website: 'www.engineeringsolutions.com',
    contactPerson: 'Karim Adel',
    email: 'karim@engineeringsolutions.com',
    phone: '+20 123 456 7896',
    employeeCount: '100-500',
    foundedYear: 2005,
    internshipHistory: {
      totalInterns: 40,
      successRate: '92%',
      averageRating: 4.7
    }
  }
];

const industries = [
  'All',
  'Software Development',
  'Marketing',
  'Finance',
  'Design',
  'Consulting',
  'Engineering',
  'Healthcare',
  'Manufacturing'
];

function Companies() {
  const [companies, setCompanies] = useState(dummyCompanies);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedIndustry, setSelectedIndustry] = useState('All');
  const [selectedCompany, setSelectedCompany] = useState(null);
  const [detailsOpen, setDetailsOpen] = useState(false);

  const handleSearch = (event) => {
    setSearchTerm(event.target.value);
  };

  const handleIndustryChange = (event) => {
    setSelectedIndustry(event.target.value);
  };

  const filteredCompanies = companies.filter((company) => {
    const matchesSearch = company.name
      .toLowerCase()
      .includes(searchTerm.toLowerCase());
    const matchesIndustry =
      selectedIndustry === 'All' || company.industry === selectedIndustry;
    return matchesSearch && matchesIndustry;
  });

  const handleViewDetails = (company) => {
    setSelectedCompany(company);
    setDetailsOpen(true);
  };

  const handleCloseDetails = () => {
    setDetailsOpen(false);
  };

  const handleApplicationDecision = (companyId, decision) => {
    setCompanies(
      companies.map((company) =>
        company.id === companyId
          ? { ...company, status: decision }
          : company
      )
    );
    setDetailsOpen(false);
  };

  return (
    <Box>
      <Typography variant="h4" gutterBottom>
        Company Applications
      </Typography>

      <Grid container spacing={2} sx={{ mb: 4 }}>
        <Grid item xs={12} md={6}>
          <TextField
            fullWidth
            label="Search Companies"
            value={searchTerm}
            onChange={handleSearch}
          />
        </Grid>
        <Grid item xs={12} md={6}>
          <TextField
            fullWidth
            select
            label="Filter by Industry"
            value={selectedIndustry}
            onChange={handleIndustryChange}
          >
            {industries.map((industry) => (
              <MenuItem key={industry} value={industry}>
                {industry}
              </MenuItem>
            ))}
          </TextField>
        </Grid>
      </Grid>

      <Grid container spacing={3}>
        {filteredCompanies.map((company) => (
          <Grid item xs={12} md={6} key={company.id} sx={{ display: 'flex' }}>
            <Card sx={{ 
              display: 'flex', 
              flexDirection: 'column', 
              width: '100%', 
              minHeight: 250,
              height: '100%',
              transition: 'all 0.3s ease',
              cursor: 'pointer',
              '&:hover': {
                transform: 'translateY(-8px)',
                boxShadow: 6,
              }
            }}>
              <CardContent sx={{ 
                flex: 1, 
                display: 'flex', 
                flexDirection: 'column',
                padding: '24px',
                '&:last-child': { paddingBottom: '24px' }
              }}>
                <Box sx={{ mb: 2 }}>
                  <Typography variant="h6" gutterBottom>
                    {company.name}
                  </Typography>
                  <Typography color="text.secondary">
                    {company.industry}
                  </Typography>
                </Box>
                <Typography 
                  variant="body2" 
                  sx={{ 
                    flex: 1,
                    mb: 2,
                    overflow: 'hidden',
                    display: '-webkit-box',
                    WebkitLineClamp: 3,
                    WebkitBoxOrient: 'vertical',
                    textOverflow: 'ellipsis'
                  }}
                >
                  {company.description}
                </Typography>
                <Box sx={{ 
                  display: 'flex', 
                  justifyContent: 'space-between', 
                  alignItems: 'center',
                  mt: 'auto'
                }}>
                  <Chip
                    label={company.status}
                    color={
                      company.status === 'accepted'
                        ? 'success'
                        : company.status === 'rejected'
                        ? 'error'
                        : 'warning'
                    }
                  />
                  <Button
                    variant="contained"
                    onClick={() => handleViewDetails(company)}
                  >
                    View Details
                  </Button>
                </Box>
              </CardContent>
            </Card>
          </Grid>
        ))}
      </Grid>

      <Dialog open={detailsOpen} onClose={handleCloseDetails} maxWidth="md" fullWidth>
        {selectedCompany && (
          <>
            <DialogTitle>{selectedCompany.name}</DialogTitle>
            <DialogContent>
              <Grid container spacing={2}>
                <Grid item xs={12} md={6}>
                  <Typography variant="subtitle1">Industry</Typography>
                  <Typography color="text.secondary" paragraph>
                    {selectedCompany.industry}
                  </Typography>

                  <Typography variant="subtitle1">Location</Typography>
                  <Typography color="text.secondary" paragraph>
                    {selectedCompany.location}
                  </Typography>

                  <Typography variant="subtitle1">Website</Typography>
                  <Typography color="text.secondary" paragraph>
                    {selectedCompany.website}
                  </Typography>
                </Grid>
                <Grid item xs={12} md={6}>
                  <Typography variant="subtitle1">Contact Person</Typography>
                  <Typography color="text.secondary" paragraph>
                    {selectedCompany.contactPerson}
                  </Typography>

                  <Typography variant="subtitle1">Email</Typography>
                  <Typography color="text.secondary" paragraph>
                    {selectedCompany.email}
                  </Typography>

                  <Typography variant="subtitle1">Phone</Typography>
                  <Typography color="text.secondary" paragraph>
                    {selectedCompany.phone}
                  </Typography>
                </Grid>
                <Grid item xs={12}>
                  <Typography variant="subtitle1">Description</Typography>
                  <Typography color="text.secondary" paragraph>
                    {selectedCompany.description}
                  </Typography>
                </Grid>
              </Grid>
            </DialogContent>
            <DialogActions>
              {selectedCompany.status === 'pending' && (
                <>
                  <Button
                    onClick={() =>
                      handleApplicationDecision(selectedCompany.id, 'rejected')
                    }
                    color="error"
                  >
                    Reject
                  </Button>
                  <Button
                    onClick={() =>
                      handleApplicationDecision(selectedCompany.id, 'accepted')
                    }
                    color="success"
                    variant="contained"
                  >
                    Accept
                  </Button>
                </>
              )}
              <Button onClick={handleCloseDetails}>Close</Button>
            </DialogActions>
          </>
        )}
      </Dialog>
    </Box>
  );
}

export default Companies; 