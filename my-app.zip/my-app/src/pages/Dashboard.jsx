import { Box, Typography, Paper, Grid, Button, Dialog, DialogTitle, DialogContent, DialogActions, TextField, Stack } from '@mui/material';
import {
  Business as BusinessIcon,
  Work as WorkIcon,
  People as PeopleIcon,
  Description as DescriptionIcon,
  Event as EventIcon,
  CalendarMonth as CalendarMonthIcon,
  Assignment as AssignmentIcon,
  School as SchoolIcon,
} from '@mui/icons-material';
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';

// Dummy data for statistics
const stats = {
  companies: 45,
  activeInternships: 120,
  enrolledStudents: 350,
  pendingReports: 28,
};

function StatCard({ icon, value, label }) {
  return (
    <Paper
      elevation={2}
      sx={{
        p: 3,
        display: 'flex',
        alignItems: 'center',
        gap: 2,
        transition: 'all 0.3s ease',
        cursor: 'pointer',
        '&:hover': {
          transform: 'translateY(-8px)',
          boxShadow: 6,
        },
      }}
    >
      <Box
        sx={{
          color: 'primary.main',
          display: 'flex',
          alignItems: 'center',
          fontSize: '2.5rem',
        }}
      >
        {icon}
      </Box>
      <Box>
        <Typography variant="h4" component="div" sx={{ fontWeight: 'normal', mb: 1 }}>
          {value}
        </Typography>
        <Typography variant="body2" color="text.secondary">
          {label}
        </Typography>
      </Box>
    </Paper>
  );
}

function Dashboard() {
  const navigate = useNavigate();
  const [openCycleDatesDialog, setOpenCycleDatesDialog] = useState(false);
  const [cycleData, setCycleData] = useState({
    startDate: '',
    endDate: '',
    name: ''
  });

  const stats = [
    {
      icon: <BusinessIcon sx={{ fontSize: 'inherit' }} />,
      value: '45',
      label: 'Registered Companies',
    },
    {
      icon: <WorkIcon sx={{ fontSize: 'inherit' }} />,
      value: '120',
      label: 'Active Internships',
    },
    {
      icon: <PeopleIcon sx={{ fontSize: 'inherit' }} />,
      value: '350',
      label: 'Enrolled Students',
    },
    {
      icon: <DescriptionIcon sx={{ fontSize: 'inherit' }} />,
      value: '28',
      label: 'Pending Reports',
    },
  ];

  const quickActions = [
    {
      title: 'Set internship cycle dates',
      icon: <CalendarMonthIcon />,
      action: () => setOpenCycleDatesDialog(true),
      color: 'warning'
    },
    {
      title: 'Review pending company applications',
      icon: <BusinessIcon />,
      action: () => navigate('/companies'),
      color: 'warning'
    },
    {
      title: 'Manage upcoming workshops',
      icon: <SchoolIcon />,
      action: () => navigate('/workshops'),
      color: 'warning'
    },
    {
      title: 'Review submitted internship reports',
      icon: <AssignmentIcon />,
      action: () => navigate('/reports'),
      color: 'warning'
    },
  ];

  const handleCloseCycleDatesDialog = () => {
    setOpenCycleDatesDialog(false);
  };

  const handleSaveCycleDates = () => {
    // Here you would typically save the cycle dates to your backend
    console.log('Saving cycle dates:', cycleData);
    setOpenCycleDatesDialog(false);
    // Show success message or update UI as needed
  };

  return (
    <Box>
      <Typography variant="h4" gutterBottom>
        Welcome to GUC Internship Portal
      </Typography>
      <Typography variant="h6" color="text.secondary" gutterBottom>
        Current Internship Cycle: Winter 2024
      </Typography>

      <Grid container spacing={3} sx={{ mb: 4, mt: 2 }}>
        {stats.map((stat, index) => (
          <Grid item xs={12} sm={6} md={3} key={index}>
            <StatCard {...stat} />
          </Grid>
        ))}
      </Grid>

      <Typography variant="h5" gutterBottom sx={{ mt: 4, mb: 3 }}>
        Quick Actions
      </Typography>
      <Grid 
        container 
        spacing={2} 
        sx={{ 
          width: '100%',
          margin: 0,
          display: 'grid',
          gridTemplateColumns: { xs: '1fr', sm: '1fr 1fr' },
          gap: 2
        }}
      >
        {quickActions.map((action, index) => (
          <Button
            key={index}
            variant="contained"
            color={action.color}
            startIcon={action.icon}
            onClick={action.action}
            sx={{
              height: '64px',
              py: 2,
              px: 3,
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'flex-start',
              textAlign: 'left',
              gap: 1,
              boxShadow: 2,
              bgcolor: '#ffc107',
              '&:hover': {
                bgcolor: '#ffca28',
                boxShadow: 6,
                transform: 'translateY(-2px)',
              },
              transition: 'all 0.3s ease',
              whiteSpace: 'nowrap',
              overflow: 'hidden',
              textOverflow: 'ellipsis',
            }}
          >
            {action.title}
          </Button>
        ))}
      </Grid>

      {/* Cycle Dates Dialog */}
      <Dialog open={openCycleDatesDialog} onClose={handleCloseCycleDatesDialog}>
        <DialogTitle>Set Internship Cycle Dates</DialogTitle>
        <DialogContent>
          <Stack spacing={3} sx={{ mt: 2, minWidth: 300 }}>
            <TextField
              label="Cycle Name"
              fullWidth
              value={cycleData.name}
              onChange={(e) => setCycleData({ ...cycleData, name: e.target.value })}
              placeholder="e.g., Summer 2024"
            />
            <TextField
              label="Start Date"
              type="date"
              fullWidth
              value={cycleData.startDate}
              onChange={(e) => setCycleData({ ...cycleData, startDate: e.target.value })}
              InputLabelProps={{ shrink: true }}
            />
            <TextField
              label="End Date"
              type="date"
              fullWidth
              value={cycleData.endDate}
              onChange={(e) => setCycleData({ ...cycleData, endDate: e.target.value })}
              InputLabelProps={{ shrink: true }}
            />
          </Stack>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleCloseCycleDatesDialog}>Cancel</Button>
          <Button 
            onClick={handleSaveCycleDates} 
            variant="contained"
            disabled={!cycleData.name || !cycleData.startDate || !cycleData.endDate}
          >
            Save
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
}

export default Dashboard; 