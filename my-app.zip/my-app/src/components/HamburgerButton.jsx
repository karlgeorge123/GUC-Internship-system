import React from 'react';
import './HamburgerButton.css';

const HamburgerButton = ({ onClick }) => {
  const handleKeyDown = (event) => {
    if (event.key === 'Enter' || event.key === ' ') {
      event.preventDefault();
      onClick();
    }
  };

  return (
    <button
      className="hamburger-button"
      onClick={onClick}
      onKeyDown={handleKeyDown}
      aria-label="Toggle menu"
      tabIndex={0}
    >
      <div className="hamburger-icon">
        <span className="line"></span>
        <span className="line"></span>
        <span className="line"></span>
      </div>
    </button>
  );
};

export default HamburgerButton; 