import { useState } from 'react';

import {
  Box,
  TextField,
  MenuItem,
  Grid,
  Card,
  CardContent,
  Typography,
  Button,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Chip,
  FormControl,
  InputLabel,
  Select,
  Stack,
} from '@mui/material';
import {
  Work as WorkIcon,
  LocationOn as LocationIcon,
  AccessTime as TimeIcon,
  AttachMoney as MoneyIcon,
} from '@mui/icons-material';


// Dummy data for internships
const dummyInternships = [
  {
    id: 1,
    title: 'Software Developer Intern',
    company: 'Tech Solutions Inc.',
    industry: 'Software Development',
    location: 'Cairo, Egypt',
    duration: '3 months',
    isPaid: true,
    salary: '5000 EGP/month',
    description: 'Join our development team and work on cutting-edge web applications using React and Node.js. You will have the opportunity to work on real projects and learn from experienced developers.',
    requirements: [
      'Currently pursuing a degree in Computer Science or related field',
      'Knowledge of JavaScript, HTML, and CSS',
      'Basic understanding of web development concepts',
      'Strong problem-solving skills',
      'Good communication skills in English'
    ],
    responsibilities: [
      'Develop and maintain web applications',
      'Collaborate with senior developers',
      'Participate in code reviews',
      'Write clean, maintainable code',
      'Debug and fix software issues'
    ],
    status: 'active',
    applicationDeadline: '2024-04-30',
    startDate: '2024-05-15',
    workingHours: '40 hours/week',
    workMode: 'Hybrid'
  },
  {
    id: 2,
    title: 'Marketing Intern',
    company: 'Global Marketing Group',
    industry: 'Marketing',
    location: 'Alexandria, Egypt',
    duration: '6 months',
    isPaid: true,
    salary: '4000 EGP/month',
    description: 'Gain hands-on experience in digital marketing and social media management. Work with a dynamic team on real marketing campaigns for various clients.',
    requirements: [
      'Marketing or Business Administration student',
      'Strong communication skills',
      'Creative mindset',
      'Knowledge of social media platforms',
      'Basic understanding of marketing analytics'
    ],
    responsibilities: [
      'Assist in social media campaigns',
      'Create marketing content',
      'Analyze marketing metrics',
      'Conduct market research',
      'Support event planning and execution'
    ],
    status: 'active',
    applicationDeadline: '2024-04-25',
    startDate: '2024-05-01',
    workingHours: '30 hours/week',
    workMode: 'On-site'
  },
  {
    id: 3,
    title: 'Financial Analyst Intern',
    company: 'FinTech Solutions',
    industry: 'Finance',
    location: 'Cairo, Egypt',
    duration: '6 months',
    isPaid: true,
    salary: '6000 EGP/month',
    description: 'Join our financial analysis team and gain practical experience in financial modeling, data analysis, and reporting. Work with the latest fintech tools and methodologies.',
    requirements: [
      'Finance or Economics major',
      'Strong analytical skills',
      'Proficiency in Excel',
      'Knowledge of financial markets',
      'Attention to detail'
    ],
    responsibilities: [
      'Assist in financial analysis',
      'Prepare financial reports',
      'Conduct market research',
      'Support investment decisions',
      'Help in process automation'
    ],
    status: 'active',
    applicationDeadline: '2024-05-15',
    startDate: '2024-06-01',
    workingHours: '40 hours/week',
    workMode: 'On-site'
  },
  {
    id: 4,
    title: 'UI/UX Design Intern',
    company: 'Creative Design Studio',
    industry: 'Design',
    location: 'Cairo, Egypt',
    duration: '3 months',
    isPaid: true,
    salary: '4500 EGP/month',
    description: 'Work on exciting design projects and learn modern UI/UX design principles. Get hands-on experience with industry-standard design tools and methodologies.',
    requirements: [
      'Design or related field student',
      'Knowledge of design tools (Figma, Adobe XD)',
      'Basic understanding of UI/UX principles',
      'Creative portfolio',
      'Team player'
    ],
    responsibilities: [
      'Create user interface designs',
      'Conduct user research',
      'Develop wireframes and prototypes',
      'Participate in design reviews',
      'Collaborate with development team'
    ],
    status: 'active',
    applicationDeadline: '2024-04-20',
    startDate: '2024-05-01',
    workingHours: '35 hours/week',
    workMode: 'Remote'
  },
  {
    id: 5,
    title: 'Machine Learning Intern',
    company: 'AI Research Lab',
    industry: 'Software Development',
    location: 'Giza, Egypt',
    duration: '6 months',
    isPaid: true,
    salary: '7000 EGP/month',
    description: 'Join our AI research team and work on cutting-edge machine learning projects. Gain experience in developing and deploying ML models.',
    requirements: [
      'Computer Science or related field',
      'Knowledge of Python',
      'Understanding of ML concepts',
      'Experience with ML frameworks',
      'Strong mathematical background'
    ],
    responsibilities: [
      'Develop ML models',
      'Process and analyze data',
      'Implement AI algorithms',
      'Conduct experiments',
      'Document research findings'
    ],
    status: 'active',
    applicationDeadline: '2024-05-30',
    startDate: '2024-06-15',
    workingHours: '40 hours/week',
    workMode: 'Hybrid'
  },
  {
    id: 6,
    title: 'Business Analyst Intern',
    company: 'Global Consulting Firm',
    industry: 'Consulting',
    location: 'Cairo, Egypt',
    duration: '4 months',
    isPaid: true,
    salary: '5500 EGP/month',
    description: 'Gain practical experience in business analysis and consulting. Work with experienced consultants on various client projects.',
    requirements: [
      'Business Administration or related field',
      'Strong analytical skills',
      'Excellent communication',
      'Proficiency in MS Office',
      'Problem-solving ability'
    ],
    responsibilities: [
      'Conduct business analysis',
      'Prepare client presentations',
      'Gather requirements',
      'Support project teams',
      'Document business processes'
    ],
    status: 'active',
    applicationDeadline: '2024-05-10',
    startDate: '2024-06-01',
    workingHours: '40 hours/week',
    workMode: 'On-site'
  },
  {
    id: 7,
    title: 'Mechanical Engineering Intern',
    company: 'Engineering Solutions',
    industry: 'Engineering',
    location: 'Alexandria, Egypt',
    duration: '6 months',
    isPaid: true,
    salary: '5000 EGP/month',
    description: 'Join our engineering team and work on real-world mechanical engineering projects. Gain practical experience in design and manufacturing.',
    requirements: [
      'Mechanical Engineering student',
      'CAD software knowledge',
      'Basic understanding of manufacturing processes',
      'Technical drawing skills',
      'Team player'
    ],
    responsibilities: [
      'Assist in engineering design',
      'Create technical drawings',
      'Support project implementation',
      'Conduct testing and analysis',
      'Document technical specifications'
    ],
    status: 'active',
    applicationDeadline: '2024-05-20',
    startDate: '2024-06-01',
    workingHours: '40 hours/week',
    workMode: 'On-site'
  }
];

const industries = [
  'All',
  'Software Development',
  'Marketing',
  'Finance',
  'Design',
  'Consulting',
  'Engineering',
  'Healthcare',
  'Manufacturing'
];

const durations = [
  'All',
  '2 months',
  '3 months',
  '4 months',
  '6 months'
];

const workModes = [
  'All',
  'On-site',
  'Remote',
  'Hybrid'
];

function Internships() {
  const [internships, setInternships] = useState(dummyInternships);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedIndustry, setSelectedIndustry] = useState('All');
  const [selectedDuration, setSelectedDuration] = useState('All');
  const [paidFilter, setPaidFilter] = useState('All');
  const [selectedInternship, setSelectedInternship] = useState(null);
  const [detailsOpen, setDetailsOpen] = useState(false);

  const handleSearch = (event) => {
    setSearchTerm(event.target.value);
  };

  const filteredInternships = internships.filter((internship) => {
    const matchesSearch = 
      internship.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      internship.company.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesIndustry =
      selectedIndustry === 'All' || internship.industry === selectedIndustry;
    const matchesDuration =
      selectedDuration === 'All' || internship.duration === selectedDuration;
    const matchesPaid =
      paidFilter === 'All' ||
      (paidFilter === 'Paid' && internship.isPaid) ||
      (paidFilter === 'Unpaid' && !internship.isPaid);

    return matchesSearch && matchesIndustry && matchesDuration && matchesPaid;
  });

  const handleViewDetails = (internship) => {
    setSelectedInternship(internship);
    setDetailsOpen(true);
  };

  return (
    <Box>
      <Typography variant="h4" gutterBottom>
        Available Internships
      </Typography>

      <Grid container spacing={2} sx={{ mb: 4 }}>
        <Grid item xs={12}>
          <TextField
            fullWidth
            label="Search by Job Title or Company"
            value={searchTerm}
            onChange={handleSearch}
          />
        </Grid>
        <Grid item xs={12} sm={6} md={4}>
          <FormControl fullWidth>
            <InputLabel>Industry</InputLabel>
            <Select
              value={selectedIndustry}
              label="Industry"
              onChange={(e) => setSelectedIndustry(e.target.value)}
            >
              {industries.map((industry) => (
                <MenuItem key={industry} value={industry}>
                  {industry}
                </MenuItem>
              ))}
            </Select>
          </FormControl>
        </Grid>
        <Grid item xs={12} sm={6} md={4}>
          <FormControl fullWidth>
            <InputLabel>Duration</InputLabel>
            <Select
              value={selectedDuration}
              label="Duration"
              onChange={(e) => setSelectedDuration(e.target.value)}
            >
              {durations.map((duration) => (
                <MenuItem key={duration} value={duration}>
                  {duration}
                </MenuItem>
              ))}
            </Select>
          </FormControl>
        </Grid>
        <Grid item xs={12} sm={6} md={4}>
          <FormControl fullWidth>
            <InputLabel>Payment</InputLabel>
            <Select
              value={paidFilter}
              label="Payment"
              onChange={(e) => setPaidFilter(e.target.value)}
            >
              <MenuItem value="All">All</MenuItem>
              <MenuItem value="Paid">Paid</MenuItem>
              <MenuItem value="Unpaid">Unpaid</MenuItem>
            </Select>
          </FormControl>
        </Grid>
      </Grid>

      <Grid container spacing={3} sx={{ mt: 2 }}>
        {filteredInternships.map((internship) => (
          <Grid 
            item 
            xs={12} 
            sm={6} 
            key={internship.id} 
            sx={{ 
              display: 'flex',
              width: '100%'
            }}
          >
            <Card 
              sx={{ 
                display: 'flex',
                flexDirection: 'column',
                width: '100%',
                height: '100%',
                minHeight: '250px',
                transition: 'all 0.3s ease',
                cursor: 'pointer',
                '&:hover': {
                  transform: 'translateY(-8px)',
                  boxShadow: 6,
                }
              }}
            >
              <CardContent 
                sx={{ 
                  display: 'flex',
                  flexDirection: 'column',
                  height: '100%',
                  p: 3,
                  '&:last-child': { 
                    pb: 3 
                  }
                }}
              >
                <Box sx={{ mb: 2 }}>
                  <Typography variant="h6" gutterBottom>
                    {internship.title}
                  </Typography>
                  <Typography color="text.secondary" gutterBottom>
                    {internship.company}
                  </Typography>
                </Box>
                <Stack 
                  spacing={1.5} 
                  sx={{ 
                    flex: 1,
                    mb: 2 
                  }}
                >
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5 }}>
                    <LocationIcon color="action" />
                    <Typography variant="body2">{internship.location}</Typography>
                  </Box>
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5 }}>
                    <TimeIcon color="action" />
                    <Typography variant="body2">{internship.duration}</Typography>
                  </Box>
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5 }}>
                    <MoneyIcon color="action" />
                    <Typography variant="body2">
                      {internship.isPaid ? internship.salary : 'Unpaid'}
                    </Typography>
                  </Box>
                </Stack>
                <Box 
                  sx={{ 
                    display: 'flex', 
                    justifyContent: 'space-between', 
                    alignItems: 'center',
                    mt: 'auto',
                    gap: 2
                  }}
                >
                  <Chip
                    icon={<WorkIcon />}
                    label={internship.industry}
                    color="primary"
                    variant="outlined"
                    sx={{ 
                      flex: 1,
                      maxWidth: '200px',
                      '& .MuiChip-icon': { ml: 1 },
                      '& .MuiChip-label': { 
                        flex: 1,
                        textAlign: 'center',
                        pr: 1
                      }
                    }}
                  />
                  <Button
                    variant="contained"
                    onClick={() => handleViewDetails(internship)}
                    sx={{ minWidth: '120px' }}
                  >
                    View Details
                  </Button>
                </Box>
              </CardContent>
            </Card>
          </Grid>
        ))}
      </Grid>

      <Dialog open={detailsOpen} onClose={() => setDetailsOpen(false)} maxWidth="md" fullWidth>
        {selectedInternship && (
          <>
            <DialogTitle>
              <Typography variant="h6">{selectedInternship.title}</Typography>
              <Typography variant="subtitle1" color="text.secondary">
                {selectedInternship.company}
              </Typography>
            </DialogTitle>
            <DialogContent>
              <Grid container spacing={3}>
                <Grid item xs={12} md={6}>
                  <Typography variant="subtitle1" gutterBottom>
                    Details
                  </Typography>
                  <Stack spacing={2}>
                    <Box>
                      <Typography variant="body2" color="text.secondary">
                        Location
                      </Typography>
                      <Typography variant="body1">
                        {selectedInternship.location}
                      </Typography>
                    </Box>
                    <Box>
                      <Typography variant="body2" color="text.secondary">
                        Duration
                      </Typography>
                      <Typography variant="body1">
                        {selectedInternship.duration}
                      </Typography>
                    </Box>
                    <Box>
                      <Typography variant="body2" color="text.secondary">
                        Compensation
                      </Typography>
                      <Typography variant="body1">
                        {selectedInternship.isPaid ? selectedInternship.salary : 'Unpaid'}
                      </Typography>
                    </Box>
                  </Stack>
                </Grid>
                <Grid item xs={12} md={6}>
                  <Typography variant="subtitle1" gutterBottom>
                    Description
                  </Typography>
                  <Typography variant="body1" paragraph>
                    {selectedInternship.description}
                  </Typography>
                </Grid>
                <Grid item xs={12}>
                  <Typography variant="subtitle1" gutterBottom>
                    Requirements
                  </Typography>
                  <ul>
                    {selectedInternship.requirements.map((req, index) => (
                      <li key={index}>
                        <Typography variant="body1">{req}</Typography>
                      </li>
                    ))}
                  </ul>
                </Grid>
                <Grid item xs={12}>
                  <Typography variant="subtitle1" gutterBottom>
                    Responsibilities
                  </Typography>
                  <ul>
                    {selectedInternship.responsibilities.map((resp, index) => (
                      <li key={index}>
                        <Typography variant="body1">{resp}</Typography>
                      </li>
                    ))}
                  </ul>
                </Grid>
              </Grid>
            </DialogContent>
            <DialogActions sx={{ p: 2.5, gap: 1 }}>
              <Button 
                onClick={() => setDetailsOpen(false)}
                variant="outlined"
                sx={{ minWidth: '100px' }}
              >
                Close
              </Button>
            </DialogActions>
          </>
        )}
      </Dialog>
    </Box>
  );
}

export default Internships; 