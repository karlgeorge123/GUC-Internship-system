import React, { useState, useEffect } from 'react';
import './MyInternships.css';

const MyInternships = () => {
  const [search, setSearch] = useState('');
  const [filters, setFilters] = useState({ status: '', date: '' });
  const internships = [
    {
      id: 101,
      companyName: 'OldTech',
      jobTitle: 'Junior Developer',
      duration: '6 months',
      startDate: '2023-01-15',
      status: 'Completed',
    },
    {
      id: 102,
      companyName: 'GrowEasy',
      jobTitle: 'Marketing Assistant',
      duration: '3 months',
      startDate: '2024-06-01',
      status: 'Current',
    },
  ];
  const [evaluations, setEvaluations] = useState([]);
  const [reports, setReports] = useState([]);
  const [selectedInternship, setSelectedInternship] = useState(null);
  const [courses, setCourses] = useState([]);
  const [selectedCourses, setSelectedCourses] = useState([]);
  const [notifications, setNotifications] = useState([]);
  const [successMessage, setSuccessMessage] = useState('');
  const [successMessageVisible, setSuccessMessageVisible] = useState(false);



  const handleEvaluationUpdate = (internshipId) => {
    setEvaluations((prev) => prev.filter((evaluation) => evaluation.internshipId !== internshipId));
  };

  const handleReportUpdate = (internshipId) => {
    setReports((prev) => prev.filter((rep) => rep.internshipId !== internshipId));
  };




  // Sync major from StudentProfile
  const [major, setMajor] = useState('');
  useEffect(() => {
    const savedProfile = localStorage.getItem('studentProfile');
    if (savedProfile) {
      const profile = JSON.parse(savedProfile);
      setMajor(profile.major || 'Computer Science');
    }
  }, []);

  // Load data from localStorage
  useEffect(() => {
    const savedEvaluations = localStorage.getItem('internshipEvaluations');
    if (savedEvaluations) setEvaluations(JSON.parse(savedEvaluations));
    const savedReports = localStorage.getItem('internshipReports');
    if (savedReports) setReports(JSON.parse(savedReports));
    const savedNotifications = localStorage.getItem('internshipNotifications');
    if (savedNotifications) setNotifications(JSON.parse(savedNotifications));
  }, []);

  // Save data to localStorage
  useEffect(() => {
    localStorage.setItem('internshipEvaluations', JSON.stringify(evaluations));
    localStorage.setItem('internshipReports', JSON.stringify(reports));
    localStorage.setItem('internshipNotifications', JSON.stringify(notifications));
  }, [evaluations, reports, notifications]);

  // Dummy courses by major
  const courseData = {
    'Computer Science': [
      'Data Structures',
      'Algorithms',
      'Web Development',
      'Database Systems',
    ],
    'Mechanical Engineering': [
      'Thermodynamics',
      'Fluid Mechanics',
      'Machine Design',
      'Manufacturing Processes',
    ],
    'Business Administration': [
      'Marketing',
      'Finance',
      'Operations Management',
      'Business Strategy',
    ],
    'Electrical Engineering': [
      'Circuit Analysis',
      'Signals and Systems',
      'Power Electronics',
      'Control Systems',
    ],
  };

  useEffect(() => {
    setCourses(courseData[major] || courseData['Computer Science']);
  }, [major]);

  // Search and filter logic
  const filteredInternships = internships.filter((internship) => {
    const matchesSearch =
      internship.jobTitle.toLowerCase().includes(search.toLowerCase()) ||
      internship.companyName.toLowerCase().includes(search.toLowerCase());
    const matchesStatus = filters.status ? internship.status === filters.status : true;
    const matchesDate = filters.date
      ? new Date(internship.startDate).getFullYear().toString() === filters.date
      : true;
    return matchesSearch && matchesStatus && matchesDate;
  });

  const handleEvaluationSubmit = (e) => {
    e.preventDefault();
    const existingEvaluation = evaluations.find(
      (evaluation) => evaluation.internshipId === selectedInternship.id
    );
    if (existingEvaluation) {
      alert('An evaluation for this internship already exists and cannot be modified.');
      return;
    }
    const rating = e.target.rating.value;
    const comments = e.target.comments.value;
    const recommend = e.target.recommend.checked;
    const evaluation = {
      id: Date.now(),
      internshipId: selectedInternship.id,
      rating,
      comments,
      recommend,
    };

    if (!rating || !comments) {
      alert('Please fill in all required fields');
      return;
    }

    setEvaluations((prev) => [
      ...prev.filter((evaluation) => evaluation.internshipId !== selectedInternship.id),
      evaluation,
    ]);
    setSuccessMessage('Evaluation submitted successfully!');
    setSuccessMessageVisible(true);
    setTimeout(() => {
      setSuccessMessageVisible(false);
    }, 3000);
    setSelectedInternship(null);
  };

  const handleEvaluationDelete = (internshipId) => {
    setEvaluations((prev) => prev.filter((evaluation) => evaluation.internshipId !== internshipId));
    setSuccessMessage('Evaluation deleted successfully!');
    setSuccessMessageVisible(true);
    setTimeout(() => {
      setSuccessMessageVisible(false);
    }, 3000);
    setSelectedInternship(null);
  };

  const handleReportSubmit = (e, isFinalized = false) => {
    e.preventDefault();
    const formData = {
      title: e.target.title.value,
      introduction: e.target.introduction.value,
      body: e.target.body.value,
    };

    if (!formData.title || !formData.introduction || !formData.body) {
      alert('Please fill in all required fields');
      return;
    }

    const status = isFinalized
      ? Math.random() < 0.7
        ? 'Approved'
        : Math.random() < 0.5
        ? 'Flagged'
        : 'Rejected'
      : 'Draft';

    const report = {
      id: Date.now(),
      internshipId: selectedInternship.id,
      title: formData.title,
      introduction: formData.introduction,
      body: formData.body,
      selectedCourses,
      status,
      comments: status === 'Flagged' ? 'Needs more detail in body.' : status === 'Rejected' ? 'Incomplete submission.' : '',
    };

    setReports((prev) => [
      ...prev.filter((rep) => rep.internshipId !== selectedInternship.id),
      report,
    ]);

    if (isFinalized && status !== 'Approved') {
      setNotifications((prev) => [
        ...prev,
        {
          id: Date.now(),
          message: `Your report for ${selectedInternship.jobTitle} at ${selectedInternship.companyName} has been ${status.toLowerCase()}.`,
          date: new Date().toISOString().split('T')[0],
        },
      ]);
    }

    setSuccessMessage('Report submitted successfully!');
    setSuccessMessageVisible(true);
    setTimeout(() => {
      setSuccessMessageVisible(false);
    }, 3000);
    setSelectedInternship(null);
    setSelectedCourses([]);
  };

  const handleReportDelete = (internshipId) => {
    setReports((prev) => prev.filter((report) => report.internshipId !== internshipId));
    setSuccessMessage('Report deleted successfully!');
    setSuccessMessageVisible(true);
    setTimeout(() => {
      setSuccessMessageVisible(false);
    }, 3000);
    setSelectedInternship(null);
  };

  const handleAppealSubmit = (e) => {
    e.preventDefault();
    const message = e.target.appealMessage.value;
    setNotifications((prev) => [
      ...prev,
      {
        id: Date.now(),
        message: `Appeal submitted for report on ${selectedInternship.jobTitle} at ${selectedInternship.companyName}: "${message}"`,
        date: new Date().toISOString().split('T')[0],
      },
    ]);
    setSelectedInternship(null);
  };

  const generateReportPDF = (report) => {
    return `
\\documentclass{article}
\\usepackage[utf8]{inputenc}
\\usepackage{geometry}
\\geometry{a4paper, margin=1in}
\\usepackage{parskip}
\\begin{document}
\\textbf{Internship Report: ${report.title}}\\\\
\\textbf{Company:} ${internships.find((i) => i.id === report.internshipId)?.companyName || 'Unknown'}\\\\
\\textbf{Job Title:} ${internships.find((i) => i.id === report.internshipId)?.jobTitle || 'Unknown'}\\\\
\\textbf{Introduction:}\\\\
${report.introduction}\\\\
\\textbf{Body:}\\\\
${report.body}\\\\
\\textbf{Relevant Courses:}\\\\
${report.selectedCourses.length > 0 ? report.selectedCourses.join(', ') : 'None'}\\\\
\\textbf{Status:} ${report.status}\\\\
\\end{document}
    `;
  };

  const generateEvaluationPDF = (evaluation) => {
    return `
\\documentclass{article}
\\usepackage[utf8]{inputenc}
\\usepackage{geometry}
\\geometry{a4paper, margin=1in}
\\usepackage{parskip}
\\begin{document}
\\textbf{Internship Evaluation}\\\\
\\textbf{Company:} ${internships.find((i) => i.id === evaluation.internshipId)?.companyName || 'Unknown'}\\\\
\\textbf{Job Title:} ${internships.find((i) => i.id === evaluation.internshipId)?.jobTitle || 'Unknown'}\\\\
\\textbf{Rating:} ${evaluation.rating}/5\\\\
\\textbf{Comments:}\\\\
${evaluation.comments}\\\\
\\textbf{Recommendation:} ${evaluation.recommend ? 'Yes' : 'No'}\\\\
\\end{document}
    `;
  };

  return (
    <div className="min-h-screen w-full bg-gray-100 flex flex-col items-center">
      <div className="banner-section">
        <h1>My Internships</h1>
      </div>
      <main className="w-full max-w-[98%] mx-auto bg-white rounded-lg shadow-lg p-8 mt-8">
        <div className="mb-8">
          <div className="flex flex-col md:flex-row gap-4 mb-6">
            <div className="flex-1">
              <label className="block text-gray-700 font-body">Search</label>
              <input
                type="text"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Search by job title or company"
                className="w-full p-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
            <div className="flex-1">
              <label className="block text-gray-700 font-body">Status</label>
              <select
                name="status"
                value={filters.status}
                onChange={(e) => setFilters({ ...filters, status: e.target.value })}
                className="w-full p-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="">All Statuses</option>
                <option value="Current">Current Intern</option>
                <option value="Completed">Internship Complete</option>
              </select>
            </div>
            <div className="flex-1">
              <label className="block text-gray-700 font-body">Year</label>
              <select
                name="date"
                value={filters.date}
                onChange={(e) => setFilters({ ...filters, date: e.target.value })}
                className="w-full p-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="">All Years</option>
                <option value="2023">2023</option>
                <option value="2024">2024</option>
                <option value="2025">2025</option>
              </select>
            </div>
          </div>
          {filteredInternships.filter((internship) => internship.status === 'Current').length > 0 && (
            <div className="mb-8">
              <h3 className="text-xl font-heading text-gray-700 mb-4">Present Internships</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {filteredInternships
                  .filter((internship) => internship.status === 'Current')
                  .map((internship) => (
                    <div key={internship.id} className="internship-card">
                      <h3 className="font-body font-medium text-gray-800">{internship.jobTitle}</h3>
                      <p className="text-gray-600 font-body text-sm">{internship.companyName}</p>
                      <p className="text-gray-600 font-body text-sm">Duration: {internship.duration}</p>
                      <p className="text-gray-600 font-body text-sm">Start Date: {internship.startDate}</p>
                      <div className="status-label">
                        <strong>Status: </strong>
                        <span className="status-badge status-current">Current</span>
                      </div>
                    </div>
                  ))}
              </div>
            </div>
          )}
          {filteredInternships.filter((internship) => internship.status === 'Completed').length > 0 && (
            <div>
              <h3 className="text-xl font-heading text-gray-700 mb-4">Past Internships</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {filteredInternships
                  .filter((internship) => internship.status === 'Completed')
                  .map((internship) => (
                    <div key={internship.id} className="internship-card">
                      <h3 className="font-body font-medium text-gray-800">{internship.jobTitle}</h3>
                      <p className="text-gray-600 font-body text-sm">{internship.companyName}</p>
                      <p className="text-gray-600 font-body text-sm">Duration: {internship.duration}</p>
                      <p className="text-gray-600 font-body text-sm">Start Date: {internship.startDate}</p>
                      <div className="status-label">
                        <strong>Status: </strong>
                        <span className="status-badge status-completed">
                          Completed
                        </span>
                      </div>
                      <div className="internship-actions">
                        <button
                          onClick={() => setSelectedInternship({ ...internship, action: 'evaluate' })}
                          className={
                            evaluations.find((e) => e.internshipId === internship.id)
                              ? 'bg-gray-600 hover:bg-gray-700'
                              : 'bg-blue-600 hover:bg-blue-700'
                          }
                          aria-label={
                            evaluations.find((e) => e.internshipId === internship.id)
                              ? 'View'
                              : 'Create'
                          }
                        >
                          {evaluations.find((e) => e.internshipId === internship.id)
                            ? 'View Evaluation'
                            : 'Evaluate'}
                        </button>
                        <button
                          onClick={() => setSelectedInternship({ ...internship, action: 'report' })}
                          className={
                            reports.find((r) => r.internshipId === internship.id)
                              ? 'bg-gray-600 hover:bg-gray-700'
                              : 'bg-green-600 hover:bg-green-700'
                          }
                          aria-label={
                            reports.find((r) => r.internshipId === internship.id)
                              ? 'View'
                              : 'Create'
                          }
                        >
                          {reports.find((r) => r.internshipId === internship.id) ? 'View Report' : 'Report'}
                        </button>
                      </div>
                    </div>
                  ))}
              </div>
            </div>
          )}
          {filteredInternships.length === 0 && (
            <p className="text-gray-600 font-body text-center">No internships found.</p>
          )}
        </div>
        {selectedInternship && selectedInternship.action === 'evaluate' && selectedInternship.status === 'Completed' && (
          <div className="mb-8 bg-white rounded-lg p-6 border border-gray-200">
            <h3 className="text-xl font-heading text-gray-800 mb-4">
              {evaluations.find((evaluation) => evaluation.internshipId === selectedInternship.id)
                ? `Evaluation for ${selectedInternship.jobTitle} at ${selectedInternship.companyName}`
                : `Create Evaluation for ${selectedInternship.jobTitle} at ${selectedInternship.companyName}`}
            </h3>
            {evaluations.find((evaluation) => evaluation.internshipId === selectedInternship.id) ? (
              <div>
                <p className="text-gray-700 font-body mb-2">
                  <strong>Rating:</strong>{' '}
                  {evaluations.find((evaluation) => evaluation.internshipId === selectedInternship.id).rating}/5
                </p>
                <p className="text-gray-700 font-body mb-2">
                  <strong>Comments:</strong>{' '}
                  {evaluations.find((evaluation) => evaluation.internshipId === selectedInternship.id).comments}
                </p>
                <p className="text-gray-700 font-body mb-4">
                  <strong>Recommend:</strong>{' '}
                  {evaluations.find((evaluation) => evaluation.internshipId === selectedInternship.id).recommend
                    ? 'Yes'
                    : 'No'}
                </p>
                <div className="flex justify-end space-x-4">
                  <button
                    onClick={() => setSelectedInternship(null)}
                    className="px-6 py-2 bg-gray-500 text-white rounded-md font-body hover:bg-gray-600 hover:scale-105 transition-transform duration-200"
                    aria-label="Close evaluation"
                  >
                    Close
                  </button>
                  <button
                    onClick={() => handleEvaluationUpdate(selectedInternship.id)}
                    className="px-6 py-2 bg-red-600 text-white rounded-md font-body hover:bg-red-700 hover:scale-105 transition-transform duration-200"
                    aria-label="Update evaluation"
                  >
                    Update
                  </button>
                  <button
                    onClick={() => handleEvaluationDelete(selectedInternship.id)}
                    className="px-6 py-2 bg-red-600 text-white rounded-md font-body hover:bg-red-700 hover:scale-105 transition-transform duration-200"
                    aria-label="Delete evaluation"
                  >
                    Delete
                  </button>
                  <a
                    href={`data:application/x-tex;charset=utf-8,${encodeURIComponent(
                      generateEvaluationPDF(
                        evaluations.find((evaluation) => evaluation.internshipId === selectedInternship.id)
                      )
                    )}`}
                    download={`evaluation_${selectedInternship.jobTitle}.tex`}
                    className="px-6 py-2 bg-blue-600 text-white rounded-md font-body hover:bg-blue-700 hover:scale-105 transition-transform duration-200"
                    aria-label="Download evaluation as PDF"
                  >
                    Download PDF
                  </a>
                </div>
              </div>
            ) : (
              <form onSubmit={(e) => handleEvaluationSubmit(e, false)}>
                <div className="mb-4">
                  <label className="block text-gray-700 font-body">Rating (1-5)</label>
                  <input
                    type="number"
                    name="rating"
                    min="1"
                    max="5"
                    required
                    className="w-full p-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
                <div className="mb-4">
                  <label className="block text-gray-700 font-body">Comments</label>
                  <textarea
                    name="comments"
                    required
                    className="w-full p-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                    rows="4"
                  />
                </div>
                <div className="mb-4">
                  <label className="flex items-center justify-between font-body text-gray-700 p-2 hover:bg-gray-50 rounded">
                    <span>Recommend to other students</span>
                    <input
                      type="checkbox"
                      name="recommend"
                      className="ml-2 h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                    />
                  </label>
                </div>
                <div className="flex justify-end space-x-4">
                  <button
                    type="submit"
                    className="px-6 py-2 bg-blue-600 text-white rounded-md font-body hover:bg-blue-700 hover:scale-105 transition-transform duration-200"
                    aria-label="Submit evaluation"
                  >
                    Submit Evaluation
                  </button>
                  <button
                    type="button"
                    onClick={() => setSelectedInternship(null)}
                    className="px-6 py-2 bg-gray-500 text-white rounded-md font-body hover:bg-gray-600 hover:scale-105 transition-transform duration-200"
                    aria-label="Cancel evaluation"
                  >
                    Cancel
                  </button>

                </div>
              </form>
            )}
          </div>
        )}
        {selectedInternship && selectedInternship.action === 'report' && (
          <div className="mb-8 bg-white rounded-lg p-6 border border-gray-200">
            <h3 className="text-xl font-heading text-gray-800 mb-4">
              {reports.find((rep) => rep.internshipId === selectedInternship.id)
                ? `Report for ${selectedInternship.jobTitle} at ${selectedInternship.companyName}`
                : `Create Report for ${selectedInternship.jobTitle} at ${selectedInternship.companyName}`}
            </h3>
            {reports.find((rep) => rep.internshipId === selectedInternship.id) ? (
              <div>
                <p className="text-gray-700 font-body mb-2">
                  <strong>Title:</strong>{' '}
                  {reports.find((rep) => rep.internshipId === selectedInternship.id).title}
                </p>
                <p className="text-gray-700 font-body mb-2">
                  <strong>Introduction:</strong>{' '}
                  {reports.find((rep) => rep.internshipId === selectedInternship.id).introduction}
                </p>
                <p className="text-gray-700 font-body mb-2">
                  <strong>Body:</strong>{' '}
                  {reports.find((rep) => rep.internshipId === selectedInternship.id).body}
                </p>
                <p className="text-gray-700 font-body mb-2">
                  <strong>Relevant Courses:</strong>{' '}
                  {reports.find((rep) => rep.internshipId === selectedInternship.id).selectedCourses.length > 0
                    ? reports.find((rep) => rep.internshipId === selectedInternship.id).selectedCourses.join(', ')
                    : 'None'}
                </p>
                <p className="text-gray-700 font-body mb-4">
                  <strong>Status:</strong>{' '}
                  {reports.find((rep) => rep.internshipId === selectedInternship.id).status}
                </p>
                {(reports.find((rep) => rep.internshipId === selectedInternship.id).status === 'Flagged' ||
                  reports.find((rep) => rep.internshipId === selectedInternship.id).status === 'Rejected') && (
                  <div className="mb-4">
                    <p className="text-gray-700 font-body mb-2">
                      <strong>Comments:</strong>{' '}
                      {reports.find((rep) => rep.internshipId === selectedInternship.id).comments}
                    </p>
                    <form onSubmit={handleAppealSubmit}>
                      <div className="mb-4">
                        <label className="block text-gray-700 font-body">Appeal Message</label>
                        <textarea
                          name="appealMessage"
                          required
                          className="w-full p-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                          rows="4"
                        />
                      </div>
                      <div className="flex justify-end space-x-4">
                        <button
                          type="submit"
                          className="px-6 py-2 bg-blue-600 text-white rounded-md font-body hover:bg-blue-700 hover:scale-105 transition-transform duration-200"
                          aria-label="Submit appeal"
                        >
                          Submit Appeal
                        </button>
                        <button
                          type="button"
                          onClick={() => setSelectedInternship(null)}
                          className="px-6 py-2 bg-gray-500 text-white rounded-md font-body hover:bg-gray-600 hover:scale-105 transition-transform duration-200"
                          aria-label="Cancel appeal"
                        >
                          Cancel
                        </button>
                      </div>
                    </form>
                  </div>
                )}
                <div className="flex justify-end space-x-4">
                  <button
                    onClick={() => setSelectedInternship(null)}
                    className="px-6 py-2 bg-gray-500 text-white rounded-md font-body hover:bg-gray-600 hover:scale-105 transition-transform duration-200"
                    aria-label="Close report"
                  >
                    Close
                  </button>
                  <button
                    onClick={() => handleReportUpdate(selectedInternship.id)}
                    className="px-6 py-2 bg-red-600 text-white rounded-md font-body hover:bg-red-700 hover:scale-105 transition-transform duration-200"
                    aria-label="Update report"
                  >
                    Update
                  </button>
                  <button
                    onClick={() => handleReportDelete(selectedInternship.id)}
                    className="px-6 py-2 bg-red-600 text-white rounded-md font-body hover:bg-red-700 hover:scale-105 transition-transform duration-200"
                    aria-label="Delete report"
                  >
                    Delete
                  </button>
                  <a
                    href={`data:application/x-tex;charset=utf-8,${encodeURIComponent(
                      generateReportPDF(reports.find((rep) => rep.internshipId === selectedInternship.id))
                    )}`}
                    download={`report_${selectedInternship.jobTitle}.tex`}
                    className="px-6 py-2 bg-blue-600 text-white rounded-md font-body hover:bg-blue-700 hover:scale-105 transition-transform duration-200"
                    aria-label="Download report as PDF"
                  >
                    Download PDF
                  </a>
                </div>
              </div>
            ) : (
              <form onSubmit={(e) => handleReportSubmit(e, false)}>
                <div className="mb-4">
                  <label className="block text-gray-700 font-body">Title</label>
                  <input
                    type="text"
                    name="title"
                    required
                    className="w-full p-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
                <div className="mb-4">
                  <label className="block text-gray-700 font-body">Introduction</label>
                  <textarea
                    name="introduction"
                    required
                    className="w-full p-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                    rows="4"
                  />
                </div>
                <div className="mb-4">
                  <label className="block text-gray-700 font-body">Body</label>
                  <textarea
                    name="body"
                    required
                    className="w-full p-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                    rows="6"
                  />
                </div>
                <div className="mb-4">
                  <label className="block text-gray-700 font-body mb-2">Relevant Courses</label>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                    {courses.map((course, index) => (
                      <label
                        key={index}
                        className="flex items-center justify-between font-body text-gray-700 p-2 hover:bg-gray-50 rounded"
                      >
                        <span>{course}</span>
                        <input
                          type="checkbox"
                          checked={selectedCourses.includes(course)}
                          onChange={() => {
                            setSelectedCourses((prev) =>
                              prev.includes(course) ? prev.filter((c) => c !== course) : [...prev, course]
                            );
                          }}
                          className="ml-2 h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                        />
                      </label>
                    ))}
                  </div>
                </div>
                <div className="flex justify-end space-x-4">
                  <button
                    type="submit"
                    className="px-6 py-2 bg-blue-600 text-white rounded-md font-body hover:bg-blue-700 hover:scale-105 transition-transform duration-200"
                    aria-label="Submit report"
                  >
                    Submit Report
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setSelectedInternship(null);
                      setSelectedCourses([]);
                    }}
                    className="px-6 py-2 bg-gray-500 text-white rounded-md font-body hover:bg-gray-600 hover:scale-105 transition-transform duration-200"
                    aria-label="Cancel report"
                  >
                    Cancel
                  </button>
                </div>
              </form>
            )}
          </div>
        )}
        {successMessageVisible && (
          <div className="mb-8 text-center">
            <div className="inline-block bg-green-100 border border-green-400 px-4 py-3 rounded relative text-green-700">
              {successMessage}
            </div>
          </div>
        )}
        <div className="mb-8">
          <h2 className="text-2xl font-heading text-gray-800 mb-4">Notifications</h2>
          {notifications.length === 0 ? (
            <p className="text-gray-600 font-body text-center">No notifications.</p>
          ) : (
            <div className="space-y-4">
              {notifications.map((notif) => (
                <div key={notif.id} className="p-4 bg-gray-50 rounded-md border border-gray-200">
                  <p className="text-gray-700 font-body">{notif.message}</p>
                  <p className="text-gray-600 font-body text-sm">Date: {notif.date}</p>
                </div>
              ))}
            </div>
          )}
        </div>
        <div className="mb-8">
          <h2 className="text-2xl font-heading text-gray-800 mb-4">Internship Requirements for {major}</h2>
          <iframe
            width="100%"
            height="315"
            src={
              major === 'Computer Science'
                ? 'https://www.youtube.com/embed/tS9Qstl4iU4'
                : major === 'Mechanical Engineering'
                ? 'https://www.youtube.com/embed/WtD6g-2AzTs'
                : major === 'Business Administration'
                ? 'https://www.youtube.com/embed/HscRAJYvP3Y'
                : 'https://www.youtube.com/embed/3tmd-9bKUlV8iRHY'
            }
            title="Internship Requirements Video"
            frameBorder="0"
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
            allowFullScreen
          />
        </div>
      </main>
    </div>
  );
};

export default MyInternships;