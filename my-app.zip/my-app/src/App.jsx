import { BrowserRouter as Router, Routes, Route, Navigate, useLocation } from 'react-router-dom';
import { Box, CssBaseline, ThemeProvider as MuiThemeProvider, createTheme } from '@mui/material';
import Layout from './components/Layout';
import FacultyLayout from './components/FacultyLayout';
import Login from './pages/Login';
import Dashboard from './pages/Dashboard';
import Companies from './pages/Companies';
import Internships from './pages/Internships';
import Students from './pages/Students';
import Reports from './pages/Reports';
import FacultyReports from './pages/FacultyReports';
import Workshops from './pages/Workshops';
import StudentProprofile from './pages/StudentProprofile';
import Studentprofile from './pages/Studentprofile';
import InternshipListingapplying from './pages/InternshipListingapplying';
import MyInternships from './pages/MyInternships';

import Appointments from './pages/Appointments';
import Calling from './pages/Calling';
import CompanyRegistration from './pages/CompanyRegistration';
import FacultyDashboard from './pages/FacultyDashboard';
import FacultyStatistics from './pages/FacultyStatistics';
import Company1 from './components/company1';
import Company2 from './components/company2';
import Company3 from './components/company3';
import { ThemeProvider } from './contexts/ThemeContext';
import { useTheme } from './contexts/ThemeContext';
import { useMemo, useState, useEffect } from 'react';
import './App.css';

// Separate component to handle auth routing to prevent loops
function AuthRouter() {
  const location = useLocation();
  const [authState, setAuthState] = useState({
    isLoaded: false,
    isLoggedIn: false,
    userRole: null
  });
  
  // Only check auth once when component mounts
  useEffect(() => {
    const userStr = localStorage.getItem('user');
    const userRole = localStorage.getItem('userRole');
    
    console.log('AuthRouter - Raw user data from localStorage:', { userStr, userRole });
    
    let isLoggedIn = false;
    let parsedUserRole = null;
    
    try {
      // Try to parse the user object
      if (userStr) {
        const userObj = JSON.parse(userStr);
        isLoggedIn = true;
        
        // Use either the parsed role or the direct userRole value
        parsedUserRole = userObj.role || userRole;
        
        console.log('AuthRouter - Parsed user object:', userObj);
      }
    } catch (err) {
      console.error('AuthRouter - Error parsing user data:', err);
    }
    
    console.log('AuthRouter - Final auth state:', { isLoggedIn, userRole: parsedUserRole });
    
    setAuthState({
      isLoaded: true,
      isLoggedIn: isLoggedIn,
      userRole: parsedUserRole
    });
  }, []);
  
  // Log state changes for debugging
  useEffect(() => {
    if (authState.isLoaded) {
      console.log('AuthRouter - Auth state updated:', authState);
    }
  }, [authState]);
  
  // Don't render anything until auth state is loaded
  if (!authState.isLoaded) {
    console.log('AuthRouter - Auth state not loaded yet');
    return null;
  }

  // Public routes accessible without authentication
  if (location.pathname === '/login') {
    console.log('AuthRouter - Login path detected');
    return authState.isLoggedIn ? <Navigate to="/" replace /> : <Login />;
  }
  
  if (location.pathname === '/company-registration') {
    console.log('AuthRouter - Company registration path detected');
    return authState.isLoggedIn ? <Navigate to="/" replace /> : <CompanyRegistration />;
  }
  
  // Protected routes that require authentication
  if (!authState.isLoggedIn) {
    console.log('AuthRouter - User not logged in, redirecting to login');
    return <Navigate to="/login" replace />;
  }
  
  // SCAD-specific routes
  if (authState.userRole === 'scad') {
    console.log('AuthRouter - SCAD role detected, rendering SCAD portal');
    return (
      <Layout>
        <Routes>
          <Route path="/" element={<Dashboard />} />
          <Route path="/companies" element={<Companies />} />
          <Route path="/internships" element={<Internships />} />
          <Route path="/students" element={<Students />} />
          <Route path="/reports" element={<Reports />} />
          <Route path="/workshops" element={<Workshops />} />
          <Route path="/appointments" element={<Appointments />} />
          <Route path="/calling" element={<Calling />} />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </Layout>
    );
  }
  
  // Faculty-specific routes
  if (authState.userRole === 'faculty') {
    return (
      <FacultyLayout>
        <Routes>
          <Route path="/" element={<FacultyDashboard />} />
          <Route path="/reports" element={<FacultyReports />} />
          <Route path="/statistics" element={<FacultyStatistics />} />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </FacultyLayout>
    );
  }
  
  // Company-specific routes
  if (authState.userRole === 'company') {
    console.log('AuthRouter - Company role detected, rendering Company portal');
    return (
      <Routes>
        <Route path="/" element={<Navigate to="/company1" replace />} />
        <Route path="/company1" element={<Company1 />} />
        <Route path="/company2" element={<Company2 />} />
        <Route path="/company3" element={<Company3 />} />
        <Route path="*" element={<Navigate to="/company1" replace />} />
      </Routes>
    );
  }
  
  // Pro-specific routes
  if (authState.userRole === 'pro') {
    console.log('AuthRouter - Pro role detected, rendering Pro portal');
    return (
      <Routes>
        <Route path="/" element={<Navigate to="/student-pro-profile" replace />} />
        <Route path="/student-pro-profile" element={<StudentProprofile />} />
        <Route path="*" element={<Navigate to="/student-pro-profile" replace />} />
      </Routes>
    );
  }
  
  // Student-specific routes
  if (authState.userRole === 'student') {
    return (
      <Routes>
        <Route path="/" element={<Navigate to="/student-profile" replace />} />
        <Route path="/student-profile/*" element={<Studentprofile />} />
        <Route path="*" element={<Navigate to="/student-profile" replace />} />
      </Routes>
    );
  }
  
  // Default routes for other roles

  return (
    <Layout>
      <Routes>
        <Route path="/" element={<Dashboard />} />
        <Route path="/companies" element={<Companies />} />
        <Route path="/internships" element={<Internships />} />
        <Route path="/students" element={<Students />} />
        <Route path="/reports" element={<Reports />} />
        <Route path="/workshops" element={<Workshops />} />
        <Route path="/appointments" element={<Appointments />} />
        <Route path="/calling" element={<Calling />} />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </Layout>
  );
}

function AppContent() {
  const { darkMode } = useTheme();

  // Create the theme using useMemo to prevent unnecessary re-renders
  const theme = useMemo(() => createTheme({
    palette: {
      mode: darkMode ? 'dark' : 'light',
      primary: {
        main: '#FFB800',
        light: '#FFD54F',
        dark: '#FFA000',
      },
      secondary: {
        main: '#dc004e',
      },
      background: {
        default: darkMode ? '#121212' : '#f5f7fa',
        paper: darkMode ? '#1e1e1e' : '#ffffff',
      },
      text: {
        primary: darkMode ? '#ffffff' : '#000000',
        secondary: darkMode ? '#b0b0b0' : '#666666',
      },
      divider: darkMode ? 'rgba(255, 255, 255, 0.12)' : 'rgba(0, 0, 0, 0.12)',
    },
    transitions: {
      duration: {
        shortest: 150,
        shorter: 200,
        short: 250,
        standard: 300,
        complex: 375,
        enteringScreen: 225,
        leavingScreen: 195,
      },
      easing: {
        easeInOut: 'cubic-bezier(0.4, 0, 0.2, 1)',
        easeOut: 'cubic-bezier(0.0, 0, 0.2, 1)',
        easeIn: 'cubic-bezier(0.4, 0, 1, 1)',
        sharp: 'cubic-bezier(0.4, 0, 0.6, 1)',
      },
    },
    components: {
      MuiCssBaseline: {
        styleOverrides: {
          body: {
            transition: 'background-color 0.3s cubic-bezier(0.0, 0, 0.2, 1), color 0.3s cubic-bezier(0.0, 0, 0.2, 1)',
            minHeight: '100vh',
            margin: 0,
            padding: 0,
          },
          '*': {
            boxSizing: 'border-box',
          }
        },
      },
      MuiPaper: {
        styleOverrides: {
          root: {
            transition: 'background-color 0.3s cubic-bezier(0.0, 0, 0.2, 1), color 0.3s cubic-bezier(0.0, 0, 0.2, 1), box-shadow 0.3s cubic-bezier(0.0, 0, 0.2, 1)',
            backgroundImage: 'none',
          },
        },
        defaultProps: {
          elevation: 0, 
          variant: 'outlined',
        },
      },
      MuiAppBar: {
        styleOverrides: {
          root: {
            transition: 'background-color 0.3s cubic-bezier(0.0, 0, 0.2, 1), color 0.3s cubic-bezier(0.0, 0, 0.2, 1), box-shadow 0.3s cubic-bezier(0.0, 0, 0.2, 1)',
            backgroundImage: 'none',
            boxShadow: darkMode ? '0px 2px 4px -1px rgba(0,0,0,0.5)' : undefined
          },
        },
      },
      MuiDrawer: {
        styleOverrides: {
          paper: {
            transition: 'background-color 0.3s cubic-bezier(0.0, 0, 0.2, 1), color 0.3s cubic-bezier(0.0, 0, 0.2, 1)',
            backgroundImage: 'none',
          },
        },
      },
      MuiButton: {
        styleOverrides: {
          root: {
            transition: 'all 0.3s cubic-bezier(0.0, 0, 0.2, 1)',
            '&.MuiButton-contained': {
              color: '#000000',
            },
          },
        },
      },
      MuiTypography: {
        styleOverrides: {
          root: {
            transition: 'color 0.3s cubic-bezier(0.0, 0, 0.2, 1)',
          },
        },
      },
      MuiTextField: {
        styleOverrides: {
          root: {
            transition: 'all 0.3s cubic-bezier(0.0, 0, 0.2, 1)',
          },
        },
      },
    },
  }), [darkMode]);

  return (
    <MuiThemeProvider theme={theme}>
      <CssBaseline />
      <Router>
        <Routes>
          <Route path="*" element={<AuthRouter />} />
        </Routes>
      </Router>
    </MuiThemeProvider>
  );
}

function App() {
  return (
    <ThemeProvider>
      <AppContent />
    </ThemeProvider>
  );
}

export default App;
