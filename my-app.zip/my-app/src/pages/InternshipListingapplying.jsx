import React, { useState, useEffect } from 'react';
import './InternshipListingapplying.css';

const InternshipListingapplying = () => {
  const [search, setSearch] = useState('');
  const [filters, setFilters] = useState({
    industry: '',
    duration: '',
    paid: '',
  });
  const [selectedInternship, setSelectedInternship] = useState(null);
  const [applied, setApplied] = useState(false);
  const [appliedInternships, setAppliedInternships] = useState([]);
  // const [pastPresentInternships, setPastPresentInternships] = useState([
  //   {
  //     id: 101,
  //     companyName: 'OldTech',
  //     jobTitle: 'Junior Developer',
  //     duration: '6 months',
  //     status: 'Completed',
  //   },
  //   {
  //     id: 102,
  //     companyName: 'GrowEasy',
  //     jobTitle: 'Marketing Assistant',
  //     duration: '3 months',
  //     status: 'Ongoing',
  //   },
  // ]);
  const [uploadedFiles, setUploadedFiles] = useState([]);

  // Dummy data for internships
  const internships = [
    {
      id: 1,
      companyName: 'TechCorp',
      jobTitle: 'Software Engineer Intern',
      duration: '3 months',
      industry: 'Technology',
      paid: 'Paid',
      salary: '$2000/month',
      skills: 'JavaScript, React, Node.js',
      description: 'Develop web applications using modern technologies.',
    },
    {
      id: 2,
      companyName: 'FinanceInc',
      jobTitle: 'Marketing Intern',
      duration: '6 months',
      industry: 'Finance',
      paid: 'Unpaid',
      salary: 'N/A',
      skills: 'Social Media, Content Creation',
      description: 'Assist in marketing campaigns and social media strategy.',
    },
    {
      id: 3,
      companyName: 'Health Solutions',
      jobTitle: 'Data Analyst Intern',
      duration: '4 months',
      industry: 'Healthcare',
      paid: 'Paid',
      salary: '$1800/month',
      skills: 'Python, SQL, Data Visualization',
      description: 'Analyze healthcare data to support decision-making.',
    },
  ];

  const industries = ['Technology', 'Finance', 'Healthcare'];
  const durations = ['3 months', '4 months', '6 months'];
  const paidOptions = ['Paid', 'Unpaid'];

  // Load applied internships from localStorage
  useEffect(() => {
    const savedApplications = localStorage.getItem('appliedInternships');
    if (savedApplications) {
      setAppliedInternships(JSON.parse(savedApplications));
    }
  }, []);

  // Save applied internships to localStorage
  useEffect(() => {
    localStorage.setItem('appliedInternships', JSON.stringify(appliedInternships));
  }, [appliedInternships]);

  // Filter and search logic
  const filteredInternships = internships.filter((internship) => {
    const matchesSearch =
      internship.jobTitle.toLowerCase().includes(search.toLowerCase()) ||
      internship.companyName.toLowerCase().includes(search.toLowerCase());
    const matchesIndustry = filters.industry ? internship.industry === filters.industry : true;
    const matchesDuration = filters.duration ? internship.duration === filters.duration : true;
    const matchesPaid = filters.paid ? internship.paid === filters.paid : true;
    return matchesSearch && matchesIndustry && matchesDuration && matchesPaid;
  });

  const handleFilterChange = (e) => {
    const { name, value } = e.target;
    setFilters({ ...filters, [name]: value });
  };

  const handleFileChange = (e) => {
    const files = Array.from(e.target.files);
    setUploadedFiles((prev) => [...prev, ...files.map((file) => file.name)]);
  };

  const removeFile = (fileName) => {
    setUploadedFiles((prev) => prev.filter((name) => name !== fileName));
  };

  const handleApply = () => {
    if (!selectedInternship) return;

    const statuses = ['Pending', 'Finalized', 'Accepted', 'Rejected'];
    const randomStatus = statuses[Math.floor(Math.random() * statuses.length)];

    const newApplication = {
      id: selectedInternship.id,
      companyName: selectedInternship.companyName,
      jobTitle: selectedInternship.jobTitle,
      applicationDate: new Date().toISOString().split('T')[0],
      status: randomStatus,
      documents: uploadedFiles,
    };
    setAppliedInternships((prev) => [...prev, newApplication]);

    if (randomStatus === 'Accepted') {
      // setPastPresentInternships((prev) => [
      //   ...prev,
      //   {
      //     id: selectedInternship.id,
      //     companyName: selectedInternship.companyName,
      //     jobTitle: selectedInternship.jobTitle,
      //     duration: selectedInternship.duration,
      //     status: 'Ongoing',
      //   },
      // ]);
    }

    setApplied(true);
    setUploadedFiles([]);
    setTimeout(() => {
      setApplied(false);
      setSelectedInternship(null);
    }, 3000);
  };

  return (
    <div className="min-h-screen w-full bg-gray-100 flex flex-col items-center">
      <div className="banner-section">
        <h1>Internship Listing</h1>
      </div>
      <main className="w-full max-w-[98%] mx-auto bg-white rounded-lg shadow-lg p-8 mt-8">
        <div className="mb-8">
          <h2 className="text-2xl font-heading text-gray-800 mb-4">My Applications</h2>
          {appliedInternships.length === 0 ? (
            <p className="text-gray-600 font-body text-center">No applications submitted yet.</p>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4">
              {appliedInternships.map((app) => (
                <div
                  key={app.id}
                  className="internship-card"
                  onClick={() =>
                    setSelectedInternship({
                      ...internships.find((i) => i.id === app.id),
                      applicationStatus: app.status,
                      documents: app.documents,
                    })
                  }
                >
                  <h3 className="font-body font-medium text-gray-800">{app.jobTitle}</h3>
                  <p className="text-gray-600 font-body text-sm">{app.companyName}</p>
                  <p className="text-gray-600 font-body text-sm">Applied: {app.applicationDate}</p>
                  <div className="status-label">
                    <strong>Status: </strong>
                    <span
                      className={`status-badge ${
                        app.status === 'Accepted'
                          ? 'status-accepted'
                          : app.status === 'Rejected'
                          ? 'status-rejected'
                          : app.status === 'Finalized'
                          ? 'status-finalized'
                          : 'status-pending'
                      }`}
                    >
                      {app.status}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* <div className="mb-8">
          <h2 className="text-2xl font-heading text-gray-800 mb-4">Past & Present Internships</h2>
          {pastPresentInternships.length === 0 ? (
            <p className="text-gray-600 font-body text-center">No past or present internships.</p>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4">
              {pastPresentInternships.map((internship) => (
                <div key={internship.id} className="p-4 bg-gray-50 rounded-md border border-gray-200">
                  <h3 className="font-body font-medium text-gray-800">{internship.jobTitle}</h3>
                  <p className="text-gray-600 font-body text-sm">{internship.companyName}</p>
                  <p className="text-gray-600 font-body text-sm">Duration: {internship.duration}</p>
                  <p className="text-sm font-body mt-2">
                    <strong>Status: </strong>
                    <span className={internship.status === 'Completed' ? 'text-green-600' : 'text-blue-600'}>
                      {internship.status}
                    </span>
                  </p>
                </div>
              ))}
            </div>
          )}
        </div> */}

        <h2 className="text-2xl font-heading text-gray-800 mb-6">Available Internships</h2>
        <div className="mb-6">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1">
              <label className="block text-gray-700 font-body">Search</label>
              <input
                type="text"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Search by job title or company"
                className="w-full p-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
            <div className="flex-1">
              <label className="block text-gray-700 font-body">Industry</label>
              <select
                name="industry"
                value={filters.industry}
                onChange={handleFilterChange}
                className="w-full p-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="">All Industries</option>
                {industries.map((industry) => (
                  <option key={industry} value={industry}>
                    {industry}
                  </option>
                ))}
              </select>
            </div>
            <div className="flex-1">
              <label className="block text-gray-700 font-body">Duration</label>
              <select
                name="duration"
                value={filters.duration}
                onChange={handleFilterChange}
                className="w-full p-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="">All Durations</option>
                {durations.map((duration) => (
                  <option key={duration} value={duration}>
                    {duration}
                  </option>
                ))}
              </select>
            </div>
            <div className="flex-1">
              <label className="block text-gray-700 font-body">Paid/Unpaid</label>
              <select
                name="paid"
                value={filters.paid}
                onChange={handleFilterChange}
                className="w-full p-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="">All</option>
                {paidOptions.map((option) => (
                  <option key={option} value={option}>
                    {option}
                  </option>
                ))}
              </select>
            </div>
          </div>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4">
          {filteredInternships.map((internship) => (
            <div
              key={internship.id}
              className="internship-card"
              onClick={() => setSelectedInternship(internship)}
            >
              <h3 className="font-body font-medium text-gray-800">{internship.jobTitle}</h3>
              <p className="text-gray-600 font-body text-sm">{internship.companyName}</p>
              <p className="text-gray-600 font-body text-sm">Duration: {internship.duration}</p>
              <div className="status-label">
                <strong>Type: </strong>
                <span className="status-badge status-type">{internship.paid}</span>
              </div>
            </div>
          ))}
          {filteredInternships.length === 0 && (
            <p className="text-gray-600 font-body col-span-full text-center">
              No internships match your criteria.
            </p>
          )}
        </div>
        {selectedInternship && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4">
            <div className="bg-white rounded-lg p-6 max-w-lg w-full">
              <h3 className="text-xl font-heading text-gray-800 mb-4">{selectedInternship.jobTitle}</h3>
              <p className="text-gray-700 font-body mb-2">
                <strong>Company:</strong> {selectedInternship.companyName}
              </p>
              <p className="text-gray-700 font-body mb-2">
                <strong>Duration:</strong> {selectedInternship.duration}
              </p>
              <p className="text-gray-700 font-body mb-2">
                <strong>Paid:</strong> {selectedInternship.paid}
              </p>
              <p className="text-gray-700 font-body mb-2">
                <strong>Salary:</strong> {selectedInternship.salary}
              </p>
              <p className="text-gray-700 font-body mb-2">
                <strong>Skills Required:</strong> {selectedInternship.skills}
              </p>
              <p className="text-gray-700 font-body mb-4">
                <strong>Description:</strong> {selectedInternship.description}
              </p>
              {selectedInternship.applicationStatus && (
                <p className="text-gray-700 font-body mb-4">
                  <strong>Application Status:</strong>{' '}
                  <span
                    className={
                      selectedInternship.applicationStatus === 'Accepted'
                        ? 'text-green-600'
                        : selectedInternship.applicationStatus === 'Rejected'
                        ? 'text-red-600'
                        : selectedInternship.applicationStatus === 'Finalized'
                        ? 'text-blue-600'
                        : 'text-yellow-600'
                    }
                  >
                    {selectedInternship.applicationStatus}
                  </span>
                </p>
              )}
              {selectedInternship.documents && selectedInternship.documents.length > 0 && (
                <div className="mb-4">
                  <p className="text-gray-700 font-body">
                    <strong>Uploaded Documents:</strong>
                  </p>
                  <ul className="list-disc pl-5">
                    {selectedInternship.documents.map((doc, index) => (
                      <li key={index} className="text-gray-700 font-body text-sm">
                        {doc}
                      </li>
                    ))}
                  </ul>
                </div>
              )}
              {!selectedInternship.applicationStatus && (
                <div className="mb-4">
                  <label className="block text-gray-700 font-body mb-2">
                    Upload Documents (e.g., CV, Cover Letter, Certificates)
                  </label>
                  <input
                    type="file"
                    multiple
                    onChange={handleFileChange}
                    className="w-full p-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                    aria-label="Upload documents"
                  />
                  {uploadedFiles.length > 0 && (
                    <div className="mt-2">
                      <p className="text-gray-700 font-body">Selected Files:</p>
                      <ul className="list-disc pl-5">
                        {uploadedFiles.map((file, index) => (
                          <li key={index} className="text-gray-700 font-body text-sm flex items-center">
                            {file}
                            <button
                              onClick={() => removeFile(file)}
                              className="ml-2 text-red-600 hover:text-red-800 font-body text-sm"
                              aria-label={`Remove ${file}`}
                            >
                              Remove
                            </button>
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}
                </div>
              )}
              {applied && <p className="text-green-600 font-body mb-4">Application submitted successfully!</p>}
              <div className="flex justify-end space-x-4">
                {!selectedInternship.applicationStatus && (
                  <button
                    onClick={handleApply}
                    className="px-6 py-2 bg-blue-600 text-white rounded-md font-body hover:bg-blue-700 hover:scale-105 transition-transform duration-200"
                    aria-label="Apply for internship"
                  >
                    Apply
                  </button>
                )}
                <button
                  onClick={() => {
                    setSelectedInternship(null);
                    setUploadedFiles([]);
                  }}
                  className="px-6 py-2 bg-gray-500 text-white rounded-md font-body hover:bg-gray-600 hover:scale-105 transition-transform duration-200"
                  aria-label="Close details"
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        )}
      </main>
    </div>
  );
};

export default InternshipListingapplying;