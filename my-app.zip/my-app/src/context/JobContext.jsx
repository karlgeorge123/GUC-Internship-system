import React, { createContext, useState, useContext } from 'react';

const JobContext = createContext();

export const JobProvider = ({ children }) => {
  // Company 1 state
  const [company1LeftCards, setCompany1LeftCards] = useState([
    {
      title: "John Doe",
      name: "John Doe",
      age: "22",
      gender: "Male",
      internshipPost: "Frontend Developer",
      status: "Accepted",
      internshipStatus: "Current Intern"
    },
    {
      title: "Jane Smith",
      name: "Jane Smith",
      age: "24",
      gender: "Female",
      internshipPost: "Backend Developer",
      status: "Finalized",
      internshipStatus: "Internship Complete"
    },
    {
      title: "karl",
      name: "karl",
      age: "20",
      gender: "Male",
      internshipPost: "Web developer",
      status: "Accepted",
      internshipStatus: "Current Intern",
    }
  ]);

  const [company1RightCards, setCompany1RightCards] = useState([
    {
      title: "Frontend Developer Internship",
      description: "Looking for a passionate frontend developer intern to work on web applications",
      duration: "3 months",
      paid: "Yes",
      skills: "HTML, CSS, JavaScript, React",
      salary: "$1000/month",
      applications: 5
    },
    {
      title: "Backend Developer Internship",
      description: "Backend development position focusing on server-side applications",
      duration: "2 months",
      paid: "Yes",
      skills: "Python, Node.js, SQL",
      salary: "$1200/month",
      applications: 3
    }
  ]);

  // Company 2 state
  const [company2LeftCards, setCompany2LeftCards] = useState([
    {
      title: "Mike Johnson",
      name: "Mike Johnson",
      age: "23",
      gender: "Male",
      internshipPost: "UI/UX Designer",
      status: "Accepted",
      internshipStatus: "Current Intern"
    },
    {
      title: "Sarah Wilson",
      name: "Sarah Wilson",
      age: "21",
      gender: "Female",
      internshipPost: "Frontend Developer",
      status: "Finalized",
      internshipStatus: "Internship Complete"
    },
    {
      title: "Emily Chen",
      name: "Emily Chen",
      age: "22",
      gender: "Female",
      internshipPost: "Data Science Intern",
      status: "Accepted",
      internshipStatus: "Current Intern"
    },
    {
      title: "David Kim",
      name: "David Kim",
      age: "24",
      gender: "Male",
      internshipPost: "Cloud Engineering Intern",
      status: "Finalized",
      internshipStatus: "Internship Complete"
    },
    {
      title: "Alex Rodriguez",
      name: "Alex Rodriguez",
      age: "23",
      gender: "Male",
      internshipPost: "Game Developer Intern",
      status: "Accepted",
      internshipStatus: "Current Intern"
    },
    {
      title: "Lisa Patel",
      name: "Lisa Patel",
      age: "22",
      gender: "Female",
      internshipPost: "AI Research Intern",
      status: "Finalized",
      internshipStatus: "Internship Complete"
    },
    {
      title: "James Thompson",
      name: "James Thompson",
      age: "25",
      gender: "Male",
      internshipPost: "Product Management Intern",
      status: "Accepted",
      internshipStatus: "Current Intern"
    }
  ]);

  const [company2RightCards, setCompany2RightCards] = useState([
    {
      title: "UI/UX Designer Internship",
      companyName: "Google",
      industry: "Technology",
      description: "Design user interfaces and improve user experience for web applications",
      duration: "6 months",
      paid: "Yes",
      skills: "Figma, Adobe XD, UI/UX principles",
      salary: "$1500/month",
      applications: 7
    },
    {
      title: "Full Stack Developer Internship",
      companyName: "Microsoft",
      industry: "Software Development",
      description: "Full stack development position working on both frontend and backend",
      duration: "4 months",
      paid: "Yes",
      skills: "React, Node.js, MongoDB",
      salary: "$1300/month",
      applications: 4
    },
    {
      title: "Data Science Intern",
      companyName: "Amazon",
      industry: "E-commerce",
      description: "Work on machine learning models and data analysis for e-commerce platform",
      duration: "3 months",
      paid: "Yes",
      skills: "Python, SQL, Machine Learning",
      salary: "$2000/month",
      applications: 6
    },
    {
      title: "Content Writing Intern",
      companyName: "Medium",
      industry: "Digital Media",
      description: "Create engaging content for our digital platform and blog",
      duration: "3 months",
      paid: "No",
      skills: "Content Writing, SEO, Editing",
      salary: "$0",
      applications: 12
    },
    {
      title: "Cloud Engineering Intern",
      companyName: "AWS",
      industry: "Cloud Computing",
      description: "Work with cloud infrastructure and DevOps practices",
      duration: "4 months",
      paid: "Yes",
      skills: "AWS, Docker, Kubernetes",
      salary: "$1700/month",
      applications: 3
    },
    {
      title: "Digital Marketing Intern",
      companyName: "Meta",
      industry: "Social Media",
      description: "Create and manage social media marketing campaigns",
      duration: "3 months",
      paid: "Yes",
      skills: "Social Media Marketing, Analytics, Content Creation",
      salary: "$1200/month",
      applications: 8
    },
    {
      title: "Non-Profit Management Intern",
      companyName: "United Way",
      industry: "Non-Profit",
      description: "Assist in managing non-profit programs and community outreach",
      duration: "4 months",
      paid: "No",
      skills: "Project Management, Communication, Fundraising",
      salary: "$0",
      applications: 5
    },
    {
      title: "Game Developer Intern",
      companyName: "Electronic Arts",
      industry: "Gaming",
      description: "Develop and test video game features using Unreal Engine",
      duration: "6 months",
      paid: "Yes",
      skills: "C++, Unreal Engine, Game Design",
      salary: "$1600/month",
      applications: 9
    },
    {
      title: "Environmental Research Intern",
      companyName: "GreenPeace",
      industry: "Environmental",
      description: "Conduct environmental research and assist in conservation projects",
      duration: "3 months",
      paid: "No",
      skills: "Research, Data Analysis, Environmental Science",
      salary: "$0",
      applications: 7
    },
    {
      title: "Cybersecurity Intern",
      companyName: "IBM",
      industry: "Technology",
      description: "Assist in implementing security measures and conducting security audits",
      duration: "4 months",
      paid: "Yes",
      skills: "Network Security, Penetration Testing, Security Tools",
      salary: "$1900/month",
      applications: 4
    },
    {
      title: "Museum Curator Assistant",
      companyName: "National Gallery",
      industry: "Arts & Culture",
      description: "Assist in curating exhibitions and managing art collections",
      duration: "6 months",
      paid: "No",
      skills: "Art History, Collection Management, Exhibition Design",
      salary: "$0",
      applications: 6
    },
    {
      title: "AI Research Intern",
      companyName: "NVIDIA",
      industry: "Artificial Intelligence",
      description: "Research and develop AI models for computer vision applications",
      duration: "6 months",
      paid: "Yes",
      skills: "Python, Deep Learning, Computer Vision",
      salary: "$2200/month",
      applications: 5
    },
    {
      title: "Event Planning Intern",
      companyName: "EventBrite",
      industry: "Events Management",
      description: "Assist in planning and coordinating virtual and physical events",
      duration: "3 months",
      paid: "No",
      skills: "Event Planning, Coordination, Customer Service",
      salary: "$0",
      applications: 8
    },
    {
      title: "Product Management Intern",
      companyName: "Salesforce",
      industry: "Software",
      description: "Work with product teams to define and launch new features",
      duration: "3 months",
      paid: "Yes",
      skills: "Product Management, Agile, Market Research",
      salary: "$1400/month",
      applications: 7
    }
  ]);

  return (
    <JobContext.Provider value={{
      company1LeftCards,
      setCompany1LeftCards,
      company1RightCards,
      setCompany1RightCards,
      company2LeftCards,
      setCompany2LeftCards,
      company2RightCards,
      setCompany2RightCards
    }}>
      {children}
    </JobContext.Provider>
  );
};

export const useJob = () => {
  const context = useContext(JobContext);
  if (!context) {
    throw new Error('useJob must be used within a JobProvider');
  }
  return context;
}; 