import { useState, useEffect } from 'react';
import {
  Box,
  Typography,
  Paper,
  Grid,
  Button,
  IconButton,
  Stack,
  Card,
  CardContent,
} from '@mui/material';
import {
  Videocam as VideocamIcon,
  VideocamOff as VideocamOffIcon,
  Mic as MicIcon,
  MicOff as MicOffIcon,
  ScreenShare as ScreenShareIcon,
  StopScreenShare as StopScreenShareIcon,
  CallEnd as CallEndIcon,
  Person as PersonIcon,
} from '@mui/icons-material';
import { useNavigate, useLocation } from 'react-router-dom';

function Calling() {
  const navigate = useNavigate();
  const location = useLocation();
  const [isVideoEnabled, setIsVideoEnabled] = useState(true);
  const [isMicEnabled, setIsMicEnabled] = useState(true);
  const [isScreenSharing, setIsScreenSharing] = useState(false);
  const [callDuration, setCallDuration] = useState(0);
  
  // Get appointment data from location state (would be passed when navigating to this page)
  const appointmentData = location.state?.appointmentData || {
    studentName: 'Sarah Ahmed',
    studentId: '2020-12346',
    reason: 'Report clarification - Need to discuss feedback on latest report',
  };

  // Timer for call duration
  useEffect(() => {
    const timer = setInterval(() => {
      setCallDuration(prev => prev + 1);
    }, 1000);
    
    return () => clearInterval(timer);
  }, []);

  // Format duration as mm:ss
  const formatDuration = (seconds) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  // Handle ending the call
  const handleEndCall = () => {
    navigate('/appointments');
  };

  return (
    <Box sx={{ height: '100%', display: 'flex', flexDirection: 'column' }}>
      {/* Header with call information */}
      <Box 
        sx={{ 
          p: 2, 
          background: 'linear-gradient(90deg, #FFC107, #FFD54F)',
          color: 'rgba(0, 0, 0, 0.87)',
          borderRadius: '12px',
          mb: 3,
          boxShadow: '0 4px 6px rgba(0, 0, 0, 0.08)',
        }}
      >
        <Stack direction="row" justifyContent="space-between" alignItems="center">
          <Typography variant="h5" fontWeight="500">
            Call with {appointmentData.studentName}
          </Typography>
          <Typography variant="body1">
            Duration: {formatDuration(callDuration)}
          </Typography>
        </Stack>
      </Box>

      {/* Main call area */}
      <Grid container spacing={3} sx={{ 
        flexGrow: 1,
        justifyContent: 'center',
        alignItems: 'flex-start'
      }}>
        {/* Video display area */}
        <Grid item xs={12} md={6} lg={5} sx={{ 
          display: 'flex',
          justifyContent: 'center',
          alignItems: 'center' 
        }}>
          <Card 
            variant="outlined"
            sx={{ 
              width: '500px',
              height: '300px',
              display: 'flex',
              flexDirection: 'column',
              justifyContent: 'center',
              alignItems: 'center',
              borderRadius: '4px',
              bgcolor: 'grey.800',
              color: 'white'
            }}
          >
            <CardContent sx={{
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              height: '100%',
              width: '100%'
            }}>
              {isVideoEnabled ? (
                <Typography variant="h6">
                  Video Feed
                </Typography>
              ) : (
                <Box sx={{ 
                  textAlign: 'center',
                  display: 'flex',
                  flexDirection: 'column',
                  alignItems: 'center',
                  gap: 2
                }}>
                  <PersonIcon sx={{ fontSize: 100, opacity: 0.5 }} />
                  <Typography variant="h6">
                    Video is disabled
                  </Typography>
                </Box>
              )}
            </CardContent>
          </Card>
        </Grid>

        {/* Side panel with call information */}
        <Grid item xs={12} md={6} lg={5} sx={{
          display: 'flex',
          justifyContent: 'center',
          alignItems: 'center'
        }}>
          <Card 
            variant="outlined"
            sx={{ 
              width: '500px',
              height: '300px',
              display: 'flex', 
              flexDirection: 'column',
              borderRadius: '4px',
            }}
          >
            <CardContent sx={{ 
              display: 'flex',
              flexDirection: 'column',
              p: 3,
              '&:last-child': { pb: 3 },
              flexGrow: 1,
              height: '100%',
              overflow: 'auto'
            }}>
              <Typography variant="h6" gutterBottom>
                Call Details
              </Typography>
              
              <Stack spacing={3} sx={{ mb: 3 }}>
                <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                  <PersonIcon color="action" fontSize="small" />
                  <Typography variant="body1">
                    Student ID: {appointmentData.studentId}
                  </Typography>
                </Box>

                <Box>
                  <Typography variant="subtitle2" gutterBottom>
                    Reason for Appointment:
                  </Typography>
                  <Typography variant="body2" color="text.secondary">
                    {appointmentData.reason}
                  </Typography>
                </Box>

                {isScreenSharing && (
                  <Box sx={{ mt: 2 }}>
                    <Typography variant="subtitle2" gutterBottom sx={{ color: '#FFC107' }}>
                      Currently sharing your screen
                    </Typography>
                  </Box>
                )}
              </Stack>

              <Typography variant="subtitle2" gutterBottom sx={{ mt: 'auto' }}>
                Call Status: Active
              </Typography>
            </CardContent>
          </Card>
        </Grid>
      </Grid>

      {/* Controls */}
      <Paper 
        sx={{ 
          p: 2, 
          mt: 3, 
          display: 'flex', 
          justifyContent: 'center',
          alignItems: 'center',
          gap: 2,
          borderRadius: '12px',
          boxShadow: '0 6px 12px rgba(0, 0, 0, 0.08)',
        }}
      >
        <IconButton 
          size="large" 
          onClick={() => setIsVideoEnabled(!isVideoEnabled)}
          sx={{ 
            bgcolor: isVideoEnabled ? '#FFC107' : 'grey.400',
            color: 'white',
            '&:hover': {
              bgcolor: isVideoEnabled ? '#FFD54F' : 'grey.500',
            },
            transition: 'all 0.2s ease-in-out',
          }}
        >
          {isVideoEnabled ? <VideocamIcon /> : <VideocamOffIcon />}
        </IconButton>
        
        <IconButton 
          size="large" 
          onClick={() => setIsMicEnabled(!isMicEnabled)}
          sx={{ 
            bgcolor: isMicEnabled ? '#FFC107' : 'grey.400',
            color: 'white',
            '&:hover': {
              bgcolor: isMicEnabled ? '#FFD54F' : 'grey.500',
            },
            transition: 'all 0.2s ease-in-out',
          }}
        >
          {isMicEnabled ? <MicIcon /> : <MicOffIcon />}
        </IconButton>
        
        <IconButton 
          size="large" 
          onClick={() => setIsScreenSharing(!isScreenSharing)}
          sx={{ 
            bgcolor: isScreenSharing ? '#FFC107' : 'grey.400',
            color: 'white',
            '&:hover': {
              bgcolor: isScreenSharing ? '#FFD54F' : 'grey.500',
            },
            transition: 'all 0.2s ease-in-out',
          }}
        >
          {isScreenSharing ? <StopScreenShareIcon /> : <ScreenShareIcon />}
        </IconButton>
        
        <Button
          variant="contained"
          startIcon={<CallEndIcon />}
          onClick={handleEndCall}
          sx={{ 
            bgcolor: '#f44336',
            color: 'white',
            '&:hover': {
              bgcolor: '#d32f2f',
              transform: 'scale(1.05)',
            },
            ml: 2,
            transition: 'all 0.2s ease-in-out',
          }}
        >
          End Call
        </Button>
      </Paper>
    </Box>
  );
}

export default Calling; 