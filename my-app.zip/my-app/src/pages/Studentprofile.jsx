import React, { useState, useEffect } from 'react';
import './Studentprofile.css';
import { NavLink, Routes, Route, Navigate } from 'react-router-dom';
import InternshipListingapplying from './InternshipListingapplying';
import MyInternships from './MyInternships';

function SuggestedCompanies() {
  // This would typically come from an API/backend
  const mockSuggestedCompanies = [
    {
      name: "TechCorp",
      industry: "Technology",
      rating: 4.5,
      pastInternCount: 15,
      matchReason: "Matches your interest in software development",
    },
    {
      name: "FinanceHub",
      industry: "Finance",
      rating: 4.8,
      pastInternCount: 8,
      matchReason: "Popular among computer science students",
    },
    {
      name: "InnovateAI",
      industry: "Artificial Intelligence",
      rating: 4.6,
      pastInternCount: 12,
      matchReason: "Aligns with your machine learning interests",
    }
  ];

  return (
    <div className="suggested-companies-section">
      <div className="section-header">
        <h2>Suggested Companies</h2>
        <p className="suggestion-subtitle">Based on your interests and past intern recommendations</p>
      </div>
      <div className="companies-grid">
        {mockSuggestedCompanies.map((company, index) => (
          <div key={index} className="company-card">
            <div className="company-header">
              <h3>{company.name}</h3>
              <span className="industry-tag">{company.industry}</span>
            </div>
            <div className="company-stats">
              <div className="stat">
                <span className="stat-value">★ {company.rating}</span>
                <span className="stat-label">Rating</span>
              </div>
              <div className="stat">
                <span className="stat-value">{company.pastInternCount}</span>
                <span className="stat-label">Past Interns</span>
              </div>
            </div>
            <p className="match-reason">{company.matchReason}</p>
          </div>
        ))}
      </div>
    </div>
  );
}

function ProfileMainContent({ isEditing, setIsEditing, formData, handleSubmit, handleCancel, handleChange, errors }) {
  return (
    <>
      <div className="banner-section">
        <h1>Profile</h1>
      </div>
      <div className="profile-card">
        <div className="profile-header">
          <h2>Student Profile</h2>
          {!isEditing && (
            <button 
              className="edit-profile-btn"
              onClick={() => setIsEditing(true)}
            >
              Edit Profile
            </button>
          )}
        </div>
        
        {isEditing ? (
          <form onSubmit={handleSubmit} className="profile-form">
            <div className="form-group">
              <label htmlFor="major">Major</label>
              <select
                id="major"
                name="major"
                value={formData.major}
                onChange={handleChange}
                className={errors.major ? 'error' : ''}
              >
                <option value="">Select Major</option>
                <option value="Computer Science">Computer Science</option>
                <option value="Mechanical Engineering">Mechanical Engineering</option>
                <option value="Business Administration">Business Administration</option>
                <option value="Electrical Engineering">Electrical Engineering</option>
              </select>
              {errors.major && <span className="error-message">{errors.major}</span>}
            </div>

            <div className="form-group">
              <label htmlFor="semester">Semester</label>
              <select
                id="semester"
                name="semester"
                value={formData.semester}
                onChange={handleChange}
                className={errors.semester ? 'error' : ''}
              >
                <option value="">Select Semester</option>
                {[1, 2, 3, 4, 5, 6, 7, 8].map(sem => (
                  <option key={sem} value={sem}>{sem}</option>
                ))}
              </select>
              {errors.semester && <span className="error-message">{errors.semester}</span>}
            </div>

            <div className="form-group">
              <label htmlFor="jobInterests">Job Interests</label>
              <textarea
                id="jobInterests"
                name="jobInterests"
                value={formData.jobInterests}
                onChange={handleChange}
                placeholder="Describe your job interests..."
                className={errors.jobInterests ? 'error' : ''}
              />
              {errors.jobInterests && <span className="error-message">{errors.jobInterests}</span>}
            </div>

            <div className="form-group">
              <label htmlFor="collegeActivities">College Activities</label>
              <textarea
                id="collegeActivities"
                name="collegeActivities"
                value={formData.collegeActivities}
                onChange={handleChange}
                placeholder="Describe your college activities..."
              />
            </div>

            <div className="form-group">
              <label>Previous Internships and Part-time Jobs (Optional)</label>
              <div className="form-subgroup">
                <label htmlFor="companyName">Company Name</label>
                <input
                  type="text"
                  id="companyName"
                  name="companyName"
                  value={formData.companyName}
                  onChange={handleChange}
                  placeholder="Enter company name..."
                />
              </div>
              <div className="form-subgroup">
                <label htmlFor="duration">Duration</label>
                <input
                  type="text"
                  id="duration"
                  name="duration"
                  value={formData.duration}
                  onChange={handleChange}
                  placeholder="e.g., 3 months, Jun 2023 - Aug 2023"
                />
              </div>
              <div className="form-subgroup">
                <label htmlFor="responsibility">Responsibilities</label>
                <textarea
                  id="responsibility"
                  name="responsibility"
                  value={formData.responsibility}
                  onChange={handleChange}
                  placeholder="Describe your main responsibilities..."
                />
              </div>
            </div>

            <div className="form-actions">
              <button type="submit" className="save-btn">Save Changes</button>
              <button type="button" className="cancel-btn" onClick={handleCancel}>Cancel</button>
            </div>
          </form>
        ) : (
          <div className="profile-info">
            <div className="info-group">
              <h3>Major</h3>
              <p>{formData.major || 'Not specified'}</p>
            </div>
            <div className="info-group">
              <h3>Semester</h3>
              <p>{formData.semester || 'Not specified'}</p>
            </div>
            <div className="info-group">
              <h3>Job Interests</h3>
              <p>{formData.jobInterests || 'Not specified'}</p>
            </div>
            <div className="info-group">
              <h3>College Activities</h3>
              <p>{formData.collegeActivities || 'Not specified'}</p>
            </div>
            {(formData.companyName || formData.duration || formData.responsibility) && (
              <div className="info-group">
                <h3>Previous Internships and Part-time Jobs</h3>
                {formData.companyName && <p><strong>Company:</strong> {formData.companyName}</p>}
                {formData.duration && <p><strong>Duration:</strong> {formData.duration}</p>}
                {formData.responsibility && <p><strong>Responsibilities:</strong> {formData.responsibility}</p>}
              </div>
            )}
          </div>
        )}
      </div>
      {!isEditing && <SuggestedCompanies />}
    </>
  );
}

const Studentprofile = () => {
  const [isEditing, setIsEditing] = useState(false);
  const [notificationCount, setNotificationCount] = useState(3); // Example notification count
  const [showNotifications, setShowNotifications] = useState(false);
  const [formData, setFormData] = useState({
    jobInterests: '',
    companyName: '',
    duration: '',
    responsibility: '',
    collegeActivities: '',
    major: '',
    semester: '',
  });
  const [errors, setErrors] = useState({});

  // Load profile data from localStorage on mount
  useEffect(() => {
    const savedProfile = localStorage.getItem('studentProfile');
    if (savedProfile) {
      setFormData(JSON.parse(savedProfile));
    }
  }, []);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });
  };

  const validateForm = () => {
    const newErrors = {};
    if (!formData.jobInterests) newErrors.jobInterests = 'Job interests are required';
    if (!formData.major) newErrors.major = 'Major is required';
    if (!formData.semester) newErrors.semester = 'Semester is required';
    return newErrors;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const validationErrors = validateForm();
    if (Object.keys(validationErrors).length > 0) {
      setErrors(validationErrors);
      return;
    }
    setErrors({});
    localStorage.setItem('studentProfile', JSON.stringify(formData));
    setIsEditing(false);
  };

  const handleCancel = () => {
    const savedProfile = localStorage.getItem('studentProfile');
    if (savedProfile) {
      setFormData(JSON.parse(savedProfile));
    } else {
      setFormData({
        jobInterests: '',
        companyName: '',
        duration: '',
        responsibility: '',
        collegeActivities: '',
        major: '',
        semester: '',
      });
    }
    setErrors({});
    setIsEditing(false);
  };

  const handleLogout = () => {
    // Clear all auth-related data
    localStorage.removeItem('user');
    localStorage.removeItem('userRole');
    localStorage.removeItem('studentProfile');
    // Force redirect to login page
    window.location.href = '/login';
  };

  const handleNotificationClick = () => {
    setShowNotifications(!showNotifications);
  };

  return (
    <div className="student-dashboard">
      <div className="top-buttons">
        <div className="notification-container">
          <button 
            className="notification-btn" 
            onClick={handleNotificationClick}
            aria-label="Notifications"
          >
            <span role="img" aria-label="notification">🔔</span>
            {notificationCount > 0 && (
              <span className="notification-badge">{notificationCount}</span>
            )}
          </button>
          {showNotifications && (
            <div className="notification-dropdown">
              <div className="notification-header">
                <h3>Notifications</h3>
                <button 
                  className="mark-all-read"
                  onClick={() => setNotificationCount(0)}
                >
                  Mark all as read
                </button>
              </div>
              <div className="notification-list">
                <div className="notification-item unread">
                  <p>New internship opportunity at TechCorp</p>
                  <span className="notification-time">2 hours ago</span>
                </div>
                <div className="notification-item unread">
                  <p>Your application for FinanceInc was viewed</p>
                  <span className="notification-time">5 hours ago</span>
                </div>
                <div className="notification-item unread">
                  <p>New message from Health Solutions</p>
                  <span className="notification-time">1 day ago</span>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
      <main className="student-main-content">
        <Routes>
          <Route path="/" element={
            <ProfileMainContent 
              isEditing={isEditing}
              setIsEditing={setIsEditing}
              formData={formData}
              handleSubmit={handleSubmit}
              handleCancel={handleCancel}
              handleChange={handleChange}
              errors={errors}
            />
          } />
          <Route path="internships" element={<InternshipListingapplying />} />
          <Route path="my-internships" element={<MyInternships />} />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </main>
      <aside className="student-sidebar">
        <ul>
          <li>
            <NavLink to="/student-profile" end className={({ isActive }) => 
              isActive ? "sidebar-link active" : "sidebar-link"
            }>
              <span role="img" aria-label="profile">👤</span> Profile
            </NavLink>
          </li>
          <li>
            <NavLink to="/student-profile/internships" className={({ isActive }) => 
              isActive ? "sidebar-link active" : "sidebar-link"
            }>
              <span role="img" aria-label="internships">💼</span> Find Internships
            </NavLink>
          </li>
          <li>
            <NavLink to="/student-profile/my-internships" className={({ isActive }) => 
              isActive ? "sidebar-link active" : "sidebar-link"
            }>
              <span role="img" aria-label="my-internships">📄</span> My Internships
            </NavLink>
          </li>
        </ul>
        <button className="logout-btn-sidebar" onClick={handleLogout}>
          <span role="img" aria-label="logout">🚪</span> Logout
        </button>
      </aside>
    </div>
  );
};

export default Studentprofile;