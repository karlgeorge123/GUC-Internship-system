import React, { useState, useEffect } from 'react';
import {
  Box,
  Container,
  Grid,
  Paper,
  Typography,
  Card,
  CardContent,
  Button,
  TextField,
  Select,
  MenuItem,
  FormControl,
  InputLabel,
  Snackbar,
  Alert,
} from '@mui/material';
import { useTheme } from '@mui/material/styles';
import {
  Assessment,
  Flag,
  CheckCircle,
  Cancel,
  Download,
} from '@mui/icons-material';

const FacultyDashboard = () => {
  const theme = useTheme();
  const [reports, setReports] = useState([]);
  const [filterMajor, setFilterMajor] = useState('all');
  const [filterStatus, setFilterStatus] = useState('all');
  const [snackbar, setSnackbar] = useState({ open: false, message: '', severity: 'success' });
  const [statistics, setStatistics] = useState({
    totalReports: 0,
    accepted: 0,
    rejected: 0,
    flagged: 0,
  });

  // Initial data load
  useEffect(() => {
    loadDummyData();
  }, []);

  // Update statistics whenever reports change
  useEffect(() => {
    updateStatistics();
  }, [reports]);

  const loadDummyData = () => {
    const dummyReports = [
      {
        id: 1,
        studentName: 'John Doe',
        studentId: '2020-12345',
        major: 'Computer Science',
        status: 'pending',
        submissionDate: '2024-03-20',
        content: 'Completed full-stack development internship at Tech Solutions Inc. Worked on React and Node.js projects, implemented new features, and participated in agile development processes.',
        companyName: 'Tech Solutions Inc.',
        supervisorName: 'Dr. Sarah Johnson',
        startDate: '2024-01-15',
        endDate: '2024-03-15',
        rating: 4.8,
        feedback: '',
        department: 'Software Development',
        technologies: ['React', 'Node.js', 'MongoDB', 'AWS'],
        projectHighlights: [
          'Developed new user authentication system',
          'Optimized database queries improving performance by 40%',
          'Implemented responsive design patterns'
        ]
      },
      {
        id: 2,
        studentName: 'Jane Smith',
        studentId: '2020-12346',
        major: 'Engineering',
        status: 'accepted',
        submissionDate: '2024-03-19',
        content: 'Mechanical engineering internship focused on automotive design. Participated in CAD modeling, prototype testing, and quality assurance procedures.',
        companyName: 'AutoTech Engineering',
        supervisorName: 'Prof. Michael Chen',
        startDate: '2024-01-10',
        endDate: '2024-03-10',
        rating: 4.6,
        feedback: 'Excellent work on the prototype designs. Shows great potential in mechanical engineering.',
        department: 'Mechanical Design',
        technologies: ['AutoCAD', 'SolidWorks', '3D Printing', 'Simulation Software'],
        projectHighlights: [
          'Designed new brake system components',
          'Reduced manufacturing costs by 25%',
          'Improved assembly efficiency'
        ]
      },
      {
        id: 3,
        studentName: 'Alex Johnson',
        studentId: '2020-12347',
        major: 'Business',
        status: 'pending',
        submissionDate: '2024-03-18',
        content: 'Marketing internship at Global Marketing Group. Worked on digital marketing campaigns, social media management, and market research.',
        companyName: 'Global Marketing Group',
        supervisorName: 'Dr. Emily Brown',
        startDate: '2024-01-20',
        endDate: '2024-03-20',
        rating: 4.5,
        feedback: '',
        department: 'Digital Marketing',
        technologies: ['Google Analytics', 'Social Media Tools', 'Adobe Creative Suite'],
        projectHighlights: [
          'Managed social media campaigns reaching 1M+ users',
          'Increased engagement rates by 60%',
          'Developed new marketing strategy'
        ]
      },
      {
        id: 4,
        studentName: 'Maria Garcia',
        studentId: '2020-12348',
        major: 'Computer Science',
        status: 'flagged',
        submissionDate: '2024-03-17',
        content: 'Data science internship focusing on AI and machine learning applications. Worked on predictive modeling and data analysis.',
        companyName: 'AI Research Lab',
        supervisorName: 'Dr. David Lee',
        startDate: '2024-01-05',
        endDate: '2024-03-05',
        rating: 4.3,
        feedback: 'Report needs more detailed documentation of the machine learning models used.',
        department: 'AI Research',
        technologies: ['Python', 'TensorFlow', 'PyTorch', 'SQL'],
        projectHighlights: [
          'Developed ML model with 95% accuracy',
          'Processed and analyzed 1TB of data',
          'Implemented real-time prediction system'
        ]
      },
      {
        id: 5,
        studentName: 'Mohammed Ahmed',
        studentId: '2020-12349',
        major: 'Engineering',
        status: 'rejected',
        submissionDate: '2024-03-16',
        content: 'Civil engineering internship at Construction Solutions. Worked on infrastructure projects and structural analysis.',
        companyName: 'Construction Solutions',
        supervisorName: 'Prof. Robert Wilson',
        startDate: '2024-01-01',
        endDate: '2024-03-01',
        rating: 3.5,
        feedback: 'Report lacks sufficient technical details and proper documentation of project involvement.',
        department: 'Civil Engineering',
        technologies: ['AutoCAD Civil 3D', 'Revit', 'GIS Software'],
        projectHighlights: [
          'Assisted in bridge design project',
          'Conducted site surveys',
          'Performed structural calculations'
        ]
      },
      {
        id: 6,
        studentName: 'Sarah Thompson',
        studentId: '2020-12350',
        major: 'Business',
        status: 'accepted',
        submissionDate: '2024-03-15',
        content: 'Financial analysis internship at FinTech Solutions. Worked on investment analysis and financial modeling.',
        companyName: 'FinTech Solutions',
        supervisorName: 'Dr. James Anderson',
        startDate: '2024-01-10',
        endDate: '2024-03-10',
        rating: 4.7,
        feedback: 'Outstanding work on financial models and market analysis.',
        department: 'Financial Analysis',
        technologies: ['Bloomberg Terminal', 'Excel', 'Python', 'R'],
        projectHighlights: [
          'Developed automated trading strategies',
          'Analyzed market trends for Q1 2024',
          'Created risk assessment models'
        ]
      },
      {
        id: 7,
        studentName: 'David Wilson',
        studentId: '2020-12351',
        major: 'Computer Science',
        status: 'pending',
        submissionDate: '2024-03-14',
        content: 'Cybersecurity internship focusing on network security and penetration testing.',
        companyName: 'SecureNet Solutions',
        supervisorName: 'Dr. Lisa Chen',
        startDate: '2024-01-15',
        endDate: '2024-03-15',
        rating: 4.4,
        feedback: '',
        department: 'Cybersecurity',
        technologies: ['Wireshark', 'Metasploit', 'Nmap', 'Burp Suite'],
        projectHighlights: [
          'Conducted security audits',
          'Identified and patched vulnerabilities',
          'Implemented new security protocols'
        ]
      },
      {
        id: 8,
        studentName: 'Emily Brown',
        studentId: '2020-12352',
        major: 'Engineering',
        status: 'accepted',
        submissionDate: '2024-03-13',
        content: 'Electrical engineering internship at Power Systems Inc. Worked on renewable energy projects.',
        companyName: 'Power Systems Inc.',
        supervisorName: 'Prof. Thomas White',
        startDate: '2024-01-05',
        endDate: '2024-03-05',
        rating: 4.9,
        feedback: 'Exceptional work on solar panel efficiency optimization.',
        department: 'Renewable Energy',
        technologies: ['MATLAB', 'PLC Programming', 'AutoCAD Electrical'],
        projectHighlights: [
          'Designed solar panel control system',
          'Improved energy efficiency by 30%',
          'Developed monitoring dashboard'
        ]
      }
    ];
    setReports(dummyReports);
  };

  const updateStatistics = () => {
    const stats = reports.reduce((acc, report) => {
      acc.totalReports++;
      if (report.status === 'accepted') acc.accepted++;
      if (report.status === 'rejected') acc.rejected++;
      if (report.status === 'flagged') acc.flagged++;
      return acc;
    }, {
      totalReports: 0,
      accepted: 0,
      rejected: 0,
      flagged: 0
    });
    setStatistics(stats);
  };

  const handleStatusChange = async (reportId, newStatus) => {
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 500));
      
      setReports(reports.map(report => 
        report.id === reportId ? { ...report, status: newStatus } : report
      ));

      // Show success message
      setSnackbar({
        open: true,
        message: `Report ${newStatus} successfully`,
        severity: 'success'
      });
    } catch (error) {
      setSnackbar({
        open: true,
        message: `Error updating report status: ${error.message}`,
        severity: 'error'
      });
    }
  };

  const downloadReport = async (reportId) => {
    try {
      // Simulate API call and file download
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      const report = reports.find(r => r.id === reportId);
      if (!report) throw new Error('Report not found');

      // In a real application, this would be an actual file download
      // For demonstration, we'll just show a success message
      setSnackbar({
        open: true,
        message: `Downloading report for ${report.studentName}...`,
        severity: 'info'
      });
    } catch (error) {
      setSnackbar({
        open: true,
        message: `Error downloading report: ${error.message}`,
        severity: 'error'
      });
    }
  };

  const handleCloseSnackbar = () => {
    setSnackbar({ ...snackbar, open: false });
  };

  const filteredReports = reports.filter(report => {
    const matchesMajor = filterMajor === 'all' || report.major.toLowerCase().includes(filterMajor.toLowerCase());
    const matchesStatus = filterStatus === 'all' || report.status === filterStatus;
    return matchesMajor && matchesStatus;
  });

  return (
    <Container maxWidth="lg" sx={{ mt: 4, mb: 4 }}>
      <Grid container spacing={3}>
        {/* Statistics Overview */}
        <Grid item xs={12}>
          <Paper 
            elevation={3}
            sx={{ 
              p: 4,
              bgcolor: 'background.paper',
              borderRadius: 2,
              transition: 'all 0.3s ease-in-out',
              backgroundImage: 'none',
              '&:hover': {
                boxShadow: '0 8px 24px rgba(0,0,0,0.12)'
              }
            }}
          >
            <Typography 
              variant="h5" 
              gutterBottom 
              sx={{ 
                color: 'text.primary', 
                fontWeight: 600,
                mb: 4,
                fontSize: '1.8rem',
                position: 'relative',
                '&:after': {
                  content: '""',
                  position: 'absolute',
                  bottom: -8,
                  left: 0,
                  width: '60px',
                  height: '4px',
                  backgroundColor: '#FFB800',
                  borderRadius: '2px'
                }
              }}
            >
              Reports Overview
            </Typography>
            <Box sx={{ 
              display: 'flex', 
              justifyContent: 'space-between',
              alignItems: 'stretch',
              p: 2,
              gap: 3
            }}>
              <Paper 
                elevation={0}
                sx={{ 
                  flex: 1,
                  p: 3,
                  textAlign: 'center',
                  borderRadius: 2,
                  bgcolor: 'background.paper',
                  backgroundImage: 'none',
                  border: '1px solid',
                  borderColor: 'divider',
                  transition: 'all 0.3s ease',
                  '&:hover': {
                    transform: 'translateY(-5px)',
                    boxShadow: theme => theme.palette.mode === 'dark' ? '0 4px 20px rgba(0,0,0,0.5)' : '0 4px 20px rgba(0,0,0,0.1)'
                  }
                }}
              >
                <Typography 
                  variant="h3" 
                  sx={{ 
                    fontWeight: 600,
                    mb: 1,
                    color: 'text.primary',
                    fontSize: '2.5rem'
                  }}
                >
                  {statistics.totalReports}
                </Typography>
                <Typography 
                  sx={{ 
                    color: 'text.secondary',
                    fontWeight: 500,
                    fontSize: '1rem',
                    textTransform: 'uppercase',
                    letterSpacing: '0.5px'
                  }}
                >
                  Total Reports
                </Typography>
              </Paper>

              <Paper 
                elevation={0}
                sx={{ 
                  flex: 1,
                  p: 3,
                  textAlign: 'center',
                  borderRadius: 2,
                  bgcolor: 'background.paper',
                  backgroundImage: 'none',
                  border: '1px solid',
                  borderColor: 'divider',
                  transition: 'all 0.3s ease',
                  '&:hover': {
                    transform: 'translateY(-5px)',
                    boxShadow: theme => theme.palette.mode === 'dark' ? '0 4px 20px rgba(0,0,0,0.5)' : '0 4px 20px rgba(0,0,0,0.1)'
                  }
                }}
              >
                <Typography 
                  variant="h3" 
                  sx={{ 
                    fontWeight: 600,
                    mb: 1,
                    color: theme => theme.palette.mode === 'dark' ? '#81c784' : '#4CAF50',
                    fontSize: '2.5rem'
                  }}
                >
                  {statistics.accepted}
                </Typography>
                <Typography 
                  sx={{ 
                    color: 'text.secondary',
                    fontWeight: 500,
                    fontSize: '1rem',
                    textTransform: 'uppercase',
                    letterSpacing: '0.5px'
                  }}
                >
                  Accepted
                </Typography>
              </Paper>

              <Paper 
                elevation={0}
                sx={{ 
                  flex: 1,
                  p: 3,
                  textAlign: 'center',
                  borderRadius: 2,
                  bgcolor: 'background.paper',
                  backgroundImage: 'none',
                  border: '1px solid',
                  borderColor: 'divider',
                  transition: 'all 0.3s ease',
                  '&:hover': {
                    transform: 'translateY(-5px)',
                    boxShadow: theme => theme.palette.mode === 'dark' ? '0 4px 20px rgba(0,0,0,0.5)' : '0 4px 20px rgba(0,0,0,0.1)'
                  }
                }}
              >
                <Typography 
                  variant="h3" 
                  sx={{ 
                    fontWeight: 600,
                    mb: 1,
                    color: theme => theme.palette.mode === 'dark' ? '#e57373' : '#f44336',
                    fontSize: '2.5rem'
                  }}
                >
                  {statistics.rejected}
                </Typography>
                <Typography 
                  sx={{ 
                    color: 'text.secondary',
                    fontWeight: 500,
                    fontSize: '1rem',
                    textTransform: 'uppercase',
                    letterSpacing: '0.5px'
                  }}
                >
                  Rejected
                </Typography>
              </Paper>

              <Paper 
                elevation={0}
                sx={{ 
                  flex: 1,
                  p: 3,
                  textAlign: 'center',
                  borderRadius: 2,
                  bgcolor: 'background.paper',
                  backgroundImage: 'none',
                  border: '1px solid',
                  borderColor: 'divider',
                  transition: 'all 0.3s ease',
                  '&:hover': {
                    transform: 'translateY(-5px)',
                    boxShadow: theme => theme.palette.mode === 'dark' ? '0 4px 20px rgba(0,0,0,0.5)' : '0 4px 20px rgba(0,0,0,0.1)'
                  }
                }}
              >
                <Typography 
                  variant="h3" 
                  sx={{ 
                    fontWeight: 600,
                    mb: 1,
                    color: theme => theme.palette.mode === 'dark' ? '#FFD54F' : '#FFB800',
                    fontSize: '2.5rem'
                  }}
                >
                  {statistics.flagged}
                </Typography>
                <Typography 
                  sx={{ 
                    color: 'text.secondary',
                    fontWeight: 500,
                    fontSize: '1rem',
                    textTransform: 'uppercase',
                    letterSpacing: '0.5px'
                  }}
                >
                  Flagged
                </Typography>
              </Paper>
            </Box>
          </Paper>
        </Grid>

        {/* Filters */}
        <Grid item xs={12}>
          <Paper 
            elevation={1} 
            sx={{ 
              bgcolor: 'background.paper',
              backgroundImage: 'none',
              boxShadow: '0px 2px 1px -1px rgba(0,0,0,0.2),0px 1px 1px 0px rgba(0,0,0,0.14),0px 1px 3px 0px rgba(0,0,0,0.12)',
              transition: 'all 0.3s ease-in-out',
              '&:hover': {
                transform: 'translateY(-4px)',
                boxShadow: '0 8px 24px rgba(0,0,0,0.12)'
              }
            }}
          >
            <Box 
              sx={{ 
                p: 2,
                display: 'flex',
                flexDirection: { xs: 'column', sm: 'row' },
                gap: 2,
                '& .MuiFormControl-root': {
                  flex: 1,
                  minWidth: { xs: '100%', sm: '200px' }
                }
              }}
            >
              <FormControl>
                <InputLabel 
                  shrink 
                  sx={{
                    bgcolor: 'background.paper',
                    px: 0.5,
                    '&.Mui-focused': {
                      color: 'primary.main'
                    }
                  }}
                >
                  Major
                </InputLabel>
                <Select
                  value={filterMajor}
                  onChange={(e) => setFilterMajor(e.target.value)}
                  size="small"
                  displayEmpty
                  sx={{
                    '& .MuiOutlinedInput-notchedOutline': {
                      borderColor: 'primary.main'
                    },
                    '&:hover .MuiOutlinedInput-notchedOutline': {
                      borderColor: 'primary.dark'
                    },
                    '&.Mui-focused .MuiOutlinedInput-notchedOutline': {
                      borderColor: 'primary.main'
                    },
                    '& .MuiSelect-select': {
                      bgcolor: 'background.paper'
                    }
                  }}
                >
                  <MenuItem value="all">All Majors</MenuItem>
                  <MenuItem value="computer science">Computer Science</MenuItem>
                  <MenuItem value="engineering">Engineering</MenuItem>
                  <MenuItem value="business">Business</MenuItem>
                </Select>
              </FormControl>
              <FormControl>
                <InputLabel 
                  shrink
                  sx={{
                    bgcolor: 'background.paper',
                    px: 0.5,
                    '&.Mui-focused': {
                      color: 'primary.main'
                    }
                  }}
                >
                  Status
                </InputLabel>
                <Select
                  value={filterStatus}
                  onChange={(e) => setFilterStatus(e.target.value)}
                  size="small"
                  displayEmpty
                  sx={{
                    '& .MuiOutlinedInput-notchedOutline': {
                      borderColor: 'primary.main'
                    },
                    '&:hover .MuiOutlinedInput-notchedOutline': {
                      borderColor: 'primary.dark'
                    },
                    '&.Mui-focused .MuiOutlinedInput-notchedOutline': {
                      borderColor: 'primary.main'
                    },
                    '& .MuiSelect-select': {
                      bgcolor: 'background.paper'
                    }
                  }}
                >
                  <MenuItem value="all">All Status</MenuItem>
                  <MenuItem value="pending">Pending</MenuItem>
                  <MenuItem value="accepted">Accepted</MenuItem>
                  <MenuItem value="rejected">Rejected</MenuItem>
                  <MenuItem value="flagged">Flagged</MenuItem>
                </Select>
              </FormControl>
            </Box>
          </Paper>
        </Grid>

        {/* Reports List */}
        <Grid item xs={12}>
          <Paper 
            sx={{ 
              p: 2,
              bgcolor: 'background.paper',
              backgroundImage: 'none'
            }}
          >
            <Box sx={{ 
              display: 'flex', 
              justifyContent: 'space-between', 
              alignItems: 'center',
              mb: 3
            }}>
              <Typography variant="h6" gutterBottom sx={{ mb: 0 }}>
                Internship Reports ({filteredReports.length})
              </Typography>
            </Box>
            {filteredReports.length === 0 ? (
              <Typography variant="body1" sx={{ textAlign: 'center', py: 3, color: 'text.secondary' }}>
                No reports found matching the current filters
              </Typography>
            ) : (
              filteredReports.map((report) => (
                <Box
                  key={report.id}
                  sx={{
                    border: 1,
                    borderColor: 'divider',
                    borderRadius: 1,
                    p: 2,
                    mb: 2,
                    backgroundColor: theme => {
                      if (theme.palette.mode === 'dark') {
                        // Dark mode colors
                        return report.status === 'pending' ? 'inherit' : 
                               report.status === 'accepted' ? 'rgba(76, 175, 80, 0.15)' :
                               report.status === 'rejected' ? 'rgba(244, 67, 54, 0.15)' :
                               'rgba(255, 184, 0, 0.15)';
                      } else {
                        // Light mode colors
                        return report.status === 'pending' ? 'inherit' : 
                               report.status === 'accepted' ? '#f0f7f0' :
                               report.status === 'rejected' ? '#fff0f0' :
                               '#fff7e6';
                      }
                    },
                    transition: 'all 0.3s ease-in-out',
                    '&:hover': {
                      transform: 'translateY(-4px)',
                      boxShadow: '0 8px 24px rgba(0,0,0,0.12)'
                    }
                  }}
                >
                  <Grid container spacing={2}>
                    <Grid item xs={12} sm={6}>
                      <Typography variant="subtitle1">
                        Student: {report.studentName}
                      </Typography>
                      <Typography variant="body2">
                        Major: {report.major}
                      </Typography>
                      <Typography variant="body2">
                        Submitted: {report.submissionDate}
                      </Typography>
                      <Typography variant="body2" sx={{ 
                        color: theme => {
                          if (theme.palette.mode === 'dark') {
                            return report.status === 'accepted' ? '#81c784' :
                                   report.status === 'rejected' ? '#e57373' :
                                   report.status === 'flagged' ? '#FFD54F' : 'text.secondary';
                          } else {
                            return report.status === 'accepted' ? '#4CAF50' :
                                   report.status === 'rejected' ? '#f44336' :
                                   report.status === 'flagged' ? '#FFB800' : 'text.secondary';
                          }
                        },
                        fontWeight: 'medium',
                        mt: 1
                      }}>
                        Status: {report.status.charAt(0).toUpperCase() + report.status.slice(1)}
                      </Typography>
                    </Grid>
                    <Grid item xs={12} sm={6}>
                      <Box sx={{ display: 'flex', gap: 1, justifyContent: 'flex-end' }}>
                        {report.status === 'pending' && (
                          <>
                            <Button
                              startIcon={<CheckCircle />}
                              variant="contained"
                              sx={{ 
                                bgcolor: theme => theme.palette.mode === 'dark' ? '#2e7d32' : '#4CAF50', 
                                '&:hover': { 
                                  bgcolor: theme => theme.palette.mode === 'dark' ? '#1b5e20' : '#388E3C' 
                                } 
                              }}
                              onClick={() => handleStatusChange(report.id, 'accepted')}
                            >
                              Accept
                            </Button>
                            <Button
                              startIcon={<Flag />}
                              variant="contained"
                              sx={{ 
                                bgcolor: theme => theme.palette.mode === 'dark' ? '#f9a825' : '#FFB800', 
                                color: 'black', 
                                '&:hover': { 
                                  bgcolor: theme => theme.palette.mode === 'dark' ? '#f57f17' : '#FFA000' 
                                } 
                              }}
                              onClick={() => handleStatusChange(report.id, 'flagged')}
                            >
                              Flag
                            </Button>
                            <Button
                              startIcon={<Cancel />}
                              variant="contained"
                              sx={{ 
                                bgcolor: theme => theme.palette.mode === 'dark' ? '#c62828' : '#f44336', 
                                '&:hover': { 
                                  bgcolor: theme => theme.palette.mode === 'dark' ? '#b71c1c' : '#d32f2f' 
                                } 
                              }}
                              onClick={() => handleStatusChange(report.id, 'rejected')}
                            >
                              Reject
                            </Button>
                          </>
                        )}
                        <Button
                          startIcon={<Download />}
                          variant="outlined"
                          onClick={() => downloadReport(report.id)}
                          sx={{
                            borderColor: 'primary.main',
                            color: theme => theme.palette.mode === 'dark' ? 'primary.main' : 'black',
                            '&:hover': {
                              borderColor: 'primary.dark',
                              bgcolor: 'action.hover'
                            }
                          }}
                        >
                          Download PDF
                        </Button>
                      </Box>
                    </Grid>
                  </Grid>
                </Box>
              ))
            )}
          </Paper>
        </Grid>
      </Grid>

      <Snackbar 
        open={snackbar.open} 
        autoHideDuration={6000} 
        onClose={handleCloseSnackbar}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}
      >
        <Alert onClose={handleCloseSnackbar} severity={snackbar.severity} sx={{ width: '100%' }}>
          {snackbar.message}
        </Alert>
      </Snackbar>
    </Container>
  );
};

export default FacultyDashboard; 