import { useState, useEffect } from 'react';
import './studentdesign1.css';
import LogoutButton from '../components/LogoutButton';
import { useNavigate } from 'react-router-dom';
import { Eye, Menu, X, User, Building2, History, ClipboardList, Briefcase, Calendar, Bell, Video, Play, Pause, FileText, Clock, Moon, Sun } from 'lucide-react';

const StudentProfile = () => {
  const [isProStudent] = useState(true);
  const [isEditing, setIsEditing] = useState(false);
  const [formData, setFormData] = useState({
    jobInterests: '',
    companyName: '',
    duration: '',
    responsibility: '',
    partTimeJobs: '',
    collegeActivities: '',
    major: '',
    semester: '',
  });
  const [errors, setErrors] = useState({});
  const [submitted, setSubmitted] = useState(false);
  const [showCompaniesModal, setShowCompaniesModal] = useState(false);
  const [showAssessmentModal, setShowAssessmentModal] = useState(false);
  const [currentAssessment, setCurrentAssessment] = useState(null);
  const [assessmentAnswers, setAssessmentAnswers] = useState({});
  const [assessmentCompleted, setAssessmentCompleted] = useState(false);
  const [assessmentScores, setAssessmentScores] = useState([
    {
      id: 1,
      title: "Technical Skills Assessment",
      score: 85,
      date: "2024-03-15",
      totalQuestions: 10,
      correctAnswers: 8,
      isPublic: false
    },
    {
      id: 2,
      title: "Problem Solving Assessment",
      score: 90,
      date: "2024-03-10",
      totalQuestions: 8,
      correctAnswers: 7,
      isPublic: false
    },
    {
      id: 3,
      title: "Communication Skills Assessment",
      score: 78,
      date: "2024-03-18",
      totalQuestions: 12,
      correctAnswers: 9,
      isPublic: true
    },
    {
      id: 4,
      title: "Teamwork Assessment",
      score: 92,
      date: "2024-03-22",
      totalQuestions: 10,
      correctAnswers: 10,
      isPublic: true
    },
    {
      id: 5,
      title: "Leadership Assessment",
      score: 60,
      date: "2024-03-25",
      totalQuestions: 8,
      correctAnswers: 5,
      isPublic: false
    }
  ]);
  const [showScoreModal, setShowScoreModal] = useState(false);
  const [selectedScore, setSelectedScore] = useState(null);
  const [draggedIndex, setDraggedIndex] = useState(null);
  const [companyViewersList, setCompanyViewersList] = useState([
    'TechCorp',
    'FinanceInc',
  ]);
  const navigate = useNavigate();
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [activeSection, setActiveSection] = useState('profile');
  const [showNotifications, setShowNotifications] = useState(false);
  const [notifications] = useState([
    {
      id: 1,
      type: 'workshop',
      title: "Resume Building Workshop",
      message: "Your workshop starts in 30 minutes",
      time: "13:30",
      date: "2024-03-25",
      isRead: false
    },
    {
      id: 2,
      type: 'reminder',
      title: "Interview Preparation",
      message: "Don't forget to prepare your questions",
      time: "15:30",
      date: "2024-03-28",
      isRead: false
    }
  ]);
  const [chatMessages, setChatMessages] = useState([
    { sender: 'Alice', message: 'Hi everyone!', time: '14:01' },
    { sender: 'You', message: 'Hello Alice!', time: '14:02' }
  ]);
  const [chatInput, setChatInput] = useState("");
  const [toast, setToast] = useState(null);
  const [completedInternships, setCompletedInternships] = useState([]);
  const [showPartTimeDetails, setShowPartTimeDetails] = useState(false);
  const [tempPartTimeDetails, setTempPartTimeDetails] = useState({
    companyName: '',
    duration: '',
    responsibility: ''
  });
  const [search, setSearch] = useState('');
  const [filters, setFilters] = useState({
    industry: '',
    duration: '',
    paid: '',
  });
  const [selectedInternship, setSelectedInternship] = useState(null);
  const [applied, setApplied] = useState(false);
  const [appliedInternships, setAppliedInternships] = useState([]);
  const [pastPresentInternships, setPastPresentInternships] = useState([
    {
      id: 101,
      companyName: 'OldTech',
      jobTitle: 'Junior Developer',
      duration: '6 months',
      status: 'Completed',
    },
    {
      id: 102,
      companyName: 'GrowEasy',
      jobTitle: 'Marketing Assistant',
      duration: '3 months',
      status: 'Ongoing',
    },
    {
      id: 103,
      companyName: 'FinServe',
      jobTitle: 'Finance Analyst Intern',
      duration: '2 months',
      status: 'Completed',
    },
    {
      id: 104,
      companyName: 'EduWorld',
      jobTitle: 'Education Content Creator',
      duration: '4 months',
      status: 'Completed',
    },
    {
      id: 105,
      companyName: 'GreenEnergy',
      jobTitle: 'Sustainability Intern',
      duration: '5 months',
      status: 'Ongoing',
    },
    {
      id: 106,
      companyName: 'Health Solutions',
      jobTitle: 'Healthcare Data Intern',
      duration: '1 month',
      status: 'Completed',
    },
  ]);
  const [uploadedFiles, setUploadedFiles] = useState([]);
  const [expandedInternshipId, setExpandedInternshipId] = useState(null);
  const [expandedEvaluationId, setExpandedEvaluationId] = useState(null);
  const [evaluations, setEvaluations] = useState(() => {
    return JSON.parse(localStorage.getItem('internshipEvaluations') || '{}');
  });
  const [evalDraft, setEvalDraft] = useState({ rating: 0, feedback: '', recommend: false });
  const [expandedReportId, setExpandedReportId] = useState(null);
  const [reports, setReports] = useState(() => {
    return JSON.parse(localStorage.getItem('internshipReports') || '{}');
  });
  const [reportDraft, setReportDraft] = useState({ title: '', introduction: '', body: '', courses: [] });
  const [reportComments, setReportComments] = useState(() => JSON.parse(localStorage.getItem('reportComments') || '{}'));
  const [appealDraft, setAppealDraft] = useState('');
  const [appealStatus, setAppealStatus] = useState(() => JSON.parse(localStorage.getItem('appealStatus') || '{}'));
  const [showAppealFormId, setShowAppealFormId] = useState(null);
  const [appointments, setAppointments] = useState(() => JSON.parse(localStorage.getItem('appointments') || '[]'));
  const [appointmentDraft, setAppointmentDraft] = useState({ date: '', time: '', reason: '' });
  const [appointmentNotifications, setAppointmentNotifications] = useState([]);
  const [onlineUsers, setOnlineUsers] = useState({ student: true, scad: true });
  const [incomingCall, setIncomingCall] = useState(null);
  const [activeCall, setActiveCall] = useState(null);
  const [callState, setCallState] = useState({ video: true, mic: true, screen: false });
  const [callNotifications, setCallNotifications] = useState([]);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [timeRemaining, setTimeRemaining] = useState(null);
  const [timerInterval, setTimerInterval] = useState(null);
  const [showWorkshopModal, setShowWorkshopModal] = useState(false);
  const [selectedWorkshop, setSelectedWorkshop] = useState(null);
  const [isDarkMode, setIsDarkMode] = useState(() => localStorage.getItem('darkMode') === 'true');
  // Add state for workshop ratings
  const [workshopRatings, setWorkshopRatings] = useState(() => {
    // Try to load from localStorage
    const saved = localStorage.getItem('workshopRatings');
    return saved ? JSON.parse(saved) : {};
  });

  useEffect(() => {
    localStorage.setItem('workshopRatings', JSON.stringify(workshopRatings));
  }, [workshopRatings]);

  const majors = [
    'Computer Science',
    'Mechanical Engineering',
    'Business Administration',
    'Electrical Engineering',
  ];
  const semesters = ['1', '2', '3', '4', '5', '6', '7', '8'];
  const suggestedCompaniesRaw = [
    { name: 'TechCorp', industry: 'Technology', recommendedByPastInterns: true },
    { name: 'FinanceInc', industry: 'Finance', recommendedByPastInterns: false },
    { name: 'Health Solutions', industry: 'Healthcare', recommendedByPastInterns: true },
    { name: 'EduWorld', industry: 'Education', recommendedByPastInterns: false },
    { name: 'GreenEnergy', industry: 'Energy', recommendedByPastInterns: true },
  ];

  // Dynamic filtering based on job interests, major, and recommendations
  const getSuggestedCompanies = () => {
    const interests = formData.jobInterests?.toLowerCase() || '';
    const major = formData.major?.toLowerCase() || '';
    return suggestedCompaniesRaw
      .filter(company =>
        (!interests || company.industry.toLowerCase().includes(interests) || company.name.toLowerCase().includes(interests)) ||
        (!major || company.industry.toLowerCase().includes(major)) ||
        company.recommendedByPastInterns
      )
      .sort((a, b) => {
        // Recommended first, then by industry match, then by name
        if (a.recommendedByPastInterns && !b.recommendedByPastInterns) return -1;
        if (!a.recommendedByPastInterns && b.recommendedByPastInterns) return 1;
        if (formData.major && a.industry === formData.major && b.industry !== formData.major) return -1;
        if (formData.major && b.industry === formData.major && a.industry !== formData.major) return 1;
        return a.name.localeCompare(b.name);
      });
  };
  const suggestedCompanies = getSuggestedCompanies();

  // Sample assessment data
  const availableAssessments = [
    {
      id: 1,
      title: "Technical Skills Assessment",
      duration: "30 minutes",
      questions: [
        {
          id: 1,
          question: "What is the time complexity of binary search?",
          options: ["O(1)", "O(log n)", "O(n)", "O(n log n)"],
          correctAnswer: "O(log n)"
        },
        {
          id: 2,
          question: "Which data structure follows LIFO principle?",
          options: ["Queue", "Stack", "Tree", "Graph"],
          correctAnswer: "Stack"
        }
      ]
    },
    {
      id: 2,
      title: "Problem Solving Assessment",
      duration: "45 minutes",
      questions: [
        {
          id: 1,
          question: "How would you approach debugging a complex system?",
          options: [
            "Start with the most recent changes",
            "Check the entire system at once",
            "Ignore the problem and restart",
            "Ask someone else to fix it"
          ],
          correctAnswer: "Start with the most recent changes"
        }
      ]
    }
  ];

  const [upcomingWorkshops] = useState([
    {
      id: 1,
      title: "Resume Building Workshop",
      date: "2024-03-25",
      time: "14:00",
      duration: "1 hour",
      speaker: "Sarah Johnson",
      company: "Career Development Center",
      description: "Learn how to create a compelling resume that stands out to employers."
    },
    {
      id: 2,
      title: "Interview Preparation",
      date: "2024-03-28",
      time: "15:30",
      duration: "1.5 hours",
      speaker: "Michael Chen",
      company: "Tech Recruiters Inc",
      description: "Master the art of technical interviews and behavioral questions."
    },
    {
      id: 3,
      title: "Networking Strategies",
      date: "2024-04-02",
      time: "13:00",
      duration: "1 hour",
      speaker: "Emily Rodriguez",
      company: "Professional Network",
      description: "Build your professional network and leverage LinkedIn effectively."
    }
  ]);

  const [registeredWorkshops] = useState([
    {
      id: 1,
      title: "Resume Building Workshop",
      date: "2024-03-25",
      time: "14:00",
      duration: "1 hour",
      type: "live",
      status: "upcoming",
      recordingUrl: null
    },
    {
      id: 2,
      title: "Interview Preparation",
      date: "2024-03-20",
      time: "15:30",
      duration: "1.5 hours",
      type: "recorded",
      status: "completed",
      recordingUrl: "https://example.com/recording1",
      notes: "Key points:\n- Research company\n- Prepare questions\n- Dress professionally"
    },
    {
      id: 3,
      title: "Networking Strategies",
      date: "2024-04-02",
      time: "13:00",
      duration: "1 hour",
      type: "live",
      status: "completed",
      recordingUrl: null,
      notes: "Great session on building LinkedIn profile."
    },
    {
      id: 4,
      title: "Personal Branding",
      date: "2024-04-10",
      time: "10:00",
      duration: "2 hours",
      type: "recorded",
      status: "completed",
      recordingUrl: "https://example.com/recording2",
      notes: "Tips on personal branding and online presence."
    },
    {
      id: 5,
      title: "Time Management",
      date: "2024-04-15",
      time: "11:00",
      duration: "1 hour",
      type: "live",
      status: "upcoming",
      recordingUrl: null
    }
  ]);

  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [notes, setNotes] = useState("");

  // Add course lists for each major
  const majorCourses = {
    'Computer Science': [
      'Data Structures', 'Algorithms', 'Operating Systems', 'Databases', 'Web Development', 'Software Engineering', 'Machine Learning'
    ],
    'Mechanical Engineering': [
      'Thermodynamics', 'Fluid Mechanics', 'Materials Science', 'Dynamics', 'Control Systems', 'Manufacturing Processes'
    ],
    'Business Administration': [
      'Accounting', 'Marketing', 'Finance', 'Organizational Behavior', 'Business Law', 'Operations Management'
    ],
    'Electrical Engineering': [
      'Circuits', 'Electromagnetics', 'Digital Logic', 'Signals and Systems', 'Power Systems', 'Control Systems'
    ]
  };

  // Add state for final report view and submission
  const [viewFinalReportId, setViewFinalReportId] = useState(null);
  const [submittedReports, setSubmittedReports] = useState(() => {
    return JSON.parse(localStorage.getItem('submittedReports') || '{}');
  });

  useEffect(() => {
    localStorage.setItem('submittedReports', JSON.stringify(submittedReports));
  }, [submittedReports]);

  useEffect(() => {
    const savedProfile = localStorage.getItem('studentProfile');
    if (savedProfile) {
      const parsedProfile = JSON.parse(savedProfile);
      setFormData(parsedProfile);
      setTempPartTimeDetails({
        companyName: parsedProfile.companyName || '',
        duration: parsedProfile.duration || '',
        responsibility: parsedProfile.responsibility || ''
      });
    }
  }, []);

  useEffect(() => {
    const applied = JSON.parse(localStorage.getItem('appliedInternships') || '[]');
    const completed = applied.filter((item) => item.status === 'Accepted' || item.status === 'Completed');
    setCompletedInternships(completed);
  }, []);

  useEffect(() => {
    localStorage.setItem('darkMode', isDarkMode);
  }, [isDarkMode]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const validateForm = () => {
    const newErrors = {};
    if (!formData.jobInterests) newErrors.jobInterests = 'Job interests are required';
    if (!formData.major) newErrors.major = 'Major is required';
    if (!formData.semester) newErrors.semester = 'Semester is required';
    return newErrors;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const validationErrors = validateForm();
    if (Object.keys(validationErrors).length > 0) {
      setErrors(validationErrors);
      return;
    }
    setErrors({});
    setSubmitted(true);
    localStorage.setItem('studentProfile', JSON.stringify(formData));
    setIsEditing(false);
    setTimeout(() => setSubmitted(false), 3000);
  };

  const handleCancel = () => {
    const savedProfile = localStorage.getItem('studentProfile');
    setFormData(
      savedProfile
        ? JSON.parse(savedProfile)
        : {
            jobInterests: '',
            companyName: '',
            duration: '',
            responsibility: '',
            partTimeJobs: '',
            collegeActivities: '',
            major: '',
            semester: '',
          }
    );
    setErrors({});
    setIsEditing(false);
  };

  // Drag and drop handlers
  const handleDragStart = (index) => setDraggedIndex(index);
  const handleDragOver = (e) => e.preventDefault();
  const handleDrop = (index) => {
    if (draggedIndex === null || draggedIndex === index) return;
    const updated = [...companyViewersList];
    const [removed] = updated.splice(draggedIndex, 1);
    updated.splice(index, 0, removed);
    setCompanyViewersList(updated);
    setDraggedIndex(null);
  };

  const handleStartAssessment = (assessment) => {
    setCurrentAssessment(assessment);
    setAssessmentAnswers({});
    setAssessmentCompleted(false);
    setCurrentQuestionIndex(0);
    setShowAssessmentModal(true);
    
    // Set timer based on assessment duration
    const durationInMinutes = parseInt(assessment.duration);
    setTimeRemaining(durationInMinutes * 60);
    
    // Start timer
    const interval = setInterval(() => {
      setTimeRemaining(prev => {
        if (prev <= 1) {
          clearInterval(interval);
          handleSubmitAssessment();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
    
    setTimerInterval(interval);
  };

  const handleAnswerSelect = (questionId, answer) => {
    setAssessmentAnswers(prev => ({
      ...prev,
      [questionId]: answer
    }));
  };

  const handleNextQuestion = () => {
    if (currentQuestionIndex < currentAssessment.questions.length - 1) {
      setCurrentQuestionIndex(prev => prev + 1);
    }
  };

  const handlePreviousQuestion = () => {
    if (currentQuestionIndex > 0) {
      setCurrentQuestionIndex(prev => prev - 1);
    }
  };

  const handleSubmitAssessment = () => {
    // Clear timer
    if (timerInterval) {
      clearInterval(timerInterval);
    }
    
    // Calculate score
    const totalQuestions = currentAssessment.questions.length;
    const correctAnswers = currentAssessment.questions.filter(
      (q) => assessmentAnswers[q.id] === q.correctAnswer
    ).length;
    const score = Math.round((correctAnswers / totalQuestions) * 100);

    // Add to scores
    const newScore = {
      id: Date.now(),
      title: currentAssessment.title,
      score,
      date: new Date().toISOString().split('T')[0],
      totalQuestions,
      correctAnswers
    };
    setAssessmentScores(prev => [newScore, ...prev]);
    setSelectedScore(newScore);
    setAssessmentCompleted(true);
    setShowScoreModal(true);
    setShowAssessmentModal(false);
  };

  const handleViewScore = (score) => {
    setSelectedScore(score);
    setShowScoreModal(true);
  };

  const handleToggleScoreVisibility = (scoreId) => {
    setAssessmentScores(prev => prev.map(score => 
      score.id === scoreId ? { ...score, isPublic: !score.isPublic } : score
    ));
  };

  // Show toast for 2 seconds when a new notification is added
  const showToast = (notification) => {
    setToast(notification);
    setTimeout(() => setToast(null), 2000);
  };

  // Update handleSendChat to show toast
  const handleSendChat = () => {
    if (chatInput.trim() === "") return;
    const newMsg = { sender: 'You', message: chatInput, time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) };
    setChatMessages([...chatMessages, newMsg]);
    setChatInput("");
    // Simulate notification for new chat message
    const newNotification = {
      id: Date.now(),
      type: 'chat',
      title: 'New Chat Message',
      message: `You: ${newMsg.message}`,
      time: newMsg.time,
      date: new Date().toISOString().split('T')[0],
      isRead: false
    };
    notifications.unshift(newNotification);
    showToast(newNotification);
  };

  // Add this function to handle part-time details changes
  const handlePartTimeDetailsChange = (e) => {
    const { name, value } = e.target;
    setTempPartTimeDetails(prev => ({
      ...prev,
      [name]: value
    }));
  };

  // Update the handleSavePartTimeDetails function
  const handleSavePartTimeDetails = () => {
    // Combine the details into a single formatted string
    const combinedDetails = `Company: ${tempPartTimeDetails.companyName} | Duration: ${tempPartTimeDetails.duration} | Responsibilities: ${tempPartTimeDetails.responsibility}`;
    
    setFormData(prev => ({
      ...prev,
      partTimeJobs: combinedDetails
    }));
    
    // Close popup and reset temp data
    setShowPartTimeDetails(false);
    setTempPartTimeDetails({
      companyName: '',
      duration: '',
      responsibility: ''
    });
  };

  // Update the clearPartTimeDetails function
  const clearPartTimeDetails = () => {
    setShowPartTimeDetails(false);
    setTempPartTimeDetails({
      companyName: '',
      duration: '',
      responsibility: ''
    });
  };

  // Update the input field to handle focus
  const handlePartTimeJobsFocus = () => {
    // Initialize tempPartTimeDetails with existing values if any
    const existingDetails = formData.partTimeJobs || '';
    const parts = existingDetails.split(' | ');
    
    let company = '', duration = '', responsibility = '';
    
    parts.forEach(part => {
      if (part.startsWith('Company:')) company = part.replace('Company:', '').trim();
      if (part.startsWith('Duration:')) duration = part.replace('Duration:', '').trim();
      if (part.startsWith('Responsibilities:')) responsibility = part.replace('Responsibilities:', '').trim();
    });

    setTempPartTimeDetails({
      companyName: company,
      duration: duration,
      responsibility: responsibility
    });
    setShowPartTimeDetails(true);
  };

  // Dummy data for internships
  const internships = [
    {
      id: 1,
      companyName: 'TechCorp',
      jobTitle: 'Software Engineer Intern',
      duration: '3 months',
      industry: 'Technology',
      paid: 'Paid',
      salary: '$2000/month',
      skills: 'JavaScript, React, Node.js',
      description: 'Develop web applications using modern technologies.',
    },
    {
      id: 2,
      companyName: 'FinanceInc',
      jobTitle: 'Marketing Intern',
      duration: '6 months',
      industry: 'Finance',
      paid: 'Unpaid',
      salary: 'N/A',
      skills: 'Social Media, Content Creation',
      description: 'Assist in marketing campaigns and social media strategy.',
    },
    {
      id: 3,
      companyName: 'Health Solutions',
      jobTitle: 'Data Analyst Intern',
      duration: '4 months',
      industry: 'Healthcare',
      paid: 'Paid',
      salary: '$1800/month',
      skills: 'Python, SQL, Data Visualization',
      description: 'Analyze healthcare data to support decision-making.',
    },
    {
      id: 4,
      companyName: 'EduWorld',
      jobTitle: 'Education Content Intern',
      duration: '2 months',
      industry: 'Education',
      paid: 'Paid',
      salary: '$1200/month',
      skills: 'Writing, Research, Communication',
      description: 'Create and curate educational content for online platforms.',
    },
    {
      id: 5,
      companyName: 'GreenEnergy',
      jobTitle: 'Sustainability Intern',
      duration: '5 months',
      industry: 'Energy',
      paid: 'Paid',
      salary: '$1500/month',
      skills: 'Environmental Science, Data Analysis',
      description: 'Support sustainability projects and data collection.',
    },
    {
      id: 6,
      companyName: 'BizConsult',
      jobTitle: 'Business Analyst Intern',
      duration: '3 months',
      industry: 'Business',
      paid: 'Unpaid',
      salary: 'N/A',
      skills: 'Excel, PowerPoint, Analysis',
      description: 'Assist in business process analysis and reporting.',
    },
    {
      id: 7,
      companyName: 'AutoMakers',
      jobTitle: 'Mechanical Engineering Intern',
      duration: '4 months',
      industry: 'Automotive',
      paid: 'Paid',
      salary: '$1700/month',
      skills: 'CAD, Manufacturing, Teamwork',
      description: 'Work on automotive design and manufacturing projects.',
    },
    {
      id: 8,
      companyName: 'MediTech',
      jobTitle: 'Biomedical Intern',
      duration: '6 months',
      industry: 'Healthcare',
      paid: 'Paid',
      salary: '$2000/month',
      skills: 'Biology, Lab Work, Research',
      description: 'Participate in biomedical research and product testing.',
    },
    {
      id: 9,
      companyName: 'CloudNet',
      jobTitle: 'Cloud Computing Intern',
      duration: '3 months',
      industry: 'Technology',
      paid: 'Paid',
      salary: '$2100/month',
      skills: 'AWS, Azure, Networking',
      description: 'Support cloud infrastructure and deployment tasks.',
    },
    {
      id: 10,
      companyName: 'MarketGurus',
      jobTitle: 'Market Research Intern',
      duration: '2 months',
      industry: 'Business',
      paid: 'Unpaid',
      salary: 'N/A',
      skills: 'Research, Data Entry, Analysis',
      description: 'Conduct market research and competitor analysis.',
    },
  ];

  const industries = ['Technology', 'Finance', 'Healthcare'];
  const durations = ['3 months', '4 months', '6 months'];
  const paidOptions = ['Paid', 'Unpaid'];

  // Load applied internships from localStorage
  useEffect(() => {
    const savedApplications = localStorage.getItem('appliedInternships');
    if (savedApplications) {
      setAppliedInternships(JSON.parse(savedApplications));
    }
  }, []);

  // Save applied internships to localStorage
  useEffect(() => {
    localStorage.setItem('appliedInternships', JSON.stringify(appliedInternships));
  }, [appliedInternships]);

  // Filter and search logic
  const filteredInternships = internships.filter((internship) => {
    const matchesSearch =
      internship.jobTitle.toLowerCase().includes(search.toLowerCase()) ||
      internship.companyName.toLowerCase().includes(search.toLowerCase());
    const matchesIndustry = filters.industry ? internship.industry === filters.industry : true;
    const matchesDuration = filters.duration ? internship.duration === filters.duration : true;
    const matchesPaid = filters.paid ? internship.paid === filters.paid : true;
    return matchesSearch && matchesIndustry && matchesDuration && matchesPaid;
  });

  const handleFilterChange = (e) => {
    const { name, value } = e.target;
    setFilters({ ...filters, [name]: value });
  };

  const handleFileChange = (e) => {
    const files = Array.from(e.target.files);
    setUploadedFiles((prev) => [...prev, ...files.map((file) => file.name)]);
  };

  const removeFile = (fileName) => {
    setUploadedFiles((prev) => prev.filter((name) => name !== fileName));
  };

  const handleApply = () => {
    if (!selectedInternship) return;

    // Simulate application status
    const statuses = ['Pending', 'Finalized', 'Accepted', 'Rejected'];
    const randomStatus = statuses[Math.floor(Math.random() * statuses.length)];

    // Add to applied internships
    const newApplication = {
      id: selectedInternship.id,
      companyName: selectedInternship.companyName,
      jobTitle: selectedInternship.jobTitle,
      applicationDate: new Date().toISOString().split('T')[0],
      status: randomStatus,
      documents: uploadedFiles,
    };
    setAppliedInternships((prev) => [...prev, newApplication]);

    // If accepted, add to past/present internships as Ongoing
    if (randomStatus === 'Accepted') {
      setPastPresentInternships((prev) => [
        ...prev,
        {
          id: selectedInternship.id,
          companyName: selectedInternship.companyName,
          jobTitle: selectedInternship.jobTitle,
          duration: selectedInternship.duration,
          status: 'Ongoing',
        },
      ]);
    }

    // Reset modal state
    setApplied(true);
    setUploadedFiles([]);
    setTimeout(() => {
      setApplied(false);
      setSelectedInternship(null);
    }, 3000);
  };

  // Add resetFilters function
  const resetFilters = () => {
    setSearch('');
    setFilters({ industry: '', duration: '', paid: '' });
  };

  // Save evaluations to localStorage
  useEffect(() => {
    localStorage.setItem('internshipEvaluations', JSON.stringify(evaluations));
  }, [evaluations]);

  const handleEvalChange = (field, value) => {
    setEvalDraft(prev => ({ ...prev, [field]: value }));
  };

  const handleSaveEvaluation = (internshipId) => {
    setEvaluations(prev => ({ ...prev, [internshipId]: evalDraft }));
    setExpandedEvaluationId(null);
  };

  const handleEditEvaluation = (internshipId) => {
    setEvalDraft(evaluations[internshipId]);
    setExpandedEvaluationId(internshipId);
  };

  const handleDeleteEvaluation = (internshipId) => {
    const newEvals = { ...evaluations };
    delete newEvals[internshipId];
    setEvaluations(newEvals);
    setExpandedEvaluationId(null);
  };

  // Save reports to localStorage
  useEffect(() => {
    localStorage.setItem('internshipReports', JSON.stringify(reports));
  }, [reports]);

  const handleReportChange = (field, value) => {
    setReportDraft(prev => ({ ...prev, [field]: value }));
  };

  const handleCourseToggle = (course) => {
    setReportDraft(prev => {
      const courses = prev.courses.includes(course)
        ? prev.courses.filter(c => c !== course)
        : [...prev.courses, course];
      return { ...prev, courses };
    });
  };

  const handleSaveReport = (internshipId) => {
    setReports(prev => ({ ...prev, [internshipId]: reportDraft }));
    setExpandedReportId(null);
  };

  const handleSubmitFinalReport = (internshipId) => {
    setSubmittedReports(prev => ({ ...prev, [internshipId]: true }));
    setViewFinalReportId(null);
  };

  const handleEditReport = (internshipId) => {
    setReportDraft(reports[internshipId]);
    setExpandedReportId(internshipId);
  };

  const handleDeleteReport = (internshipId) => {
    const newReports = { ...reports };
    delete newReports[internshipId];
    setReports(newReports);
    setExpandedReportId(null);
  };

  // Save comments and appeals to localStorage
  useEffect(() => {
    localStorage.setItem('reportComments', JSON.stringify(reportComments));
    localStorage.setItem('appealStatus', JSON.stringify(appealStatus));
  }, [reportComments, appealStatus]);

  const handleAppealSubmit = (internshipId) => {
    setAppealStatus(prev => ({ ...prev, [internshipId]: { message: appealDraft, status: 'pending' } }));
    setShowAppealFormId(null);
    setAppealDraft('');
  };

  // Add video URLs or placeholders for each major
  const majorVideos = {
    'Computer Science': 'https://www.youtube.com/embed/8mAITcNt710',
    'Mechanical Engineering': 'https://www.youtube.com/embed/2ePf9rue1Ao',
    'Business Administration': 'https://www.youtube.com/embed/5MgBikgcWnY',
    'Electrical Engineering': 'https://www.youtube.com/embed/1I5ZMmrOfnA',
  };

  // Save appointments to localStorage
  useEffect(() => {
    localStorage.setItem('appointments', JSON.stringify(appointments));
  }, [appointments]);

  // Appointment request handler
  const handleRequestAppointment = () => {
    const newAppointment = {
      id: Date.now(),
      ...appointmentDraft,
      status: 'pending',
      studentOnline: onlineUsers.student,
      scadOnline: onlineUsers.scad,
      messages: [],
    };
    setAppointments(prev => [newAppointment, ...prev]);
    setAppointmentDraft({ date: '', time: '', reason: '' });
    setAppointmentNotifications(prev => [
      { id: Date.now(), type: 'appointment', message: 'Appointment requested', status: 'pending' },
      ...prev
    ]);
  };

  // Accept/reject appointment
  const handleAppointmentAction = (id, action) => {
    setAppointments(prev => prev.map(app =>
      app.id === id ? { ...app, status: action } : app
    ));
    setAppointmentNotifications(prev => [
      { id: Date.now(), type: 'appointment', message: `Appointment ${action}`, status: action },
      ...prev
    ]);
  };

  // Simulate online status
  const toggleOnline = (user) => {
    setOnlineUsers(prev => ({ ...prev, [user]: !prev[user] }));
  };

  // Simulate incoming call
  const handleStartCall = (appointment) => {
    setIncomingCall({ from: 'SCAD Officer', appointment });
  };
  const handleAcceptCall = () => {
    setActiveCall({ with: incomingCall.from, appointment: incomingCall.appointment });
    setIncomingCall(null);
  };
  const handleRejectCall = () => {
    setCallNotifications(prev => [
      { id: Date.now(), type: 'call', message: 'Call rejected' },
      ...prev
    ]);
    setIncomingCall(null);
  };
  const handleLeaveCall = () => {
    setCallNotifications(prev => [
      { id: Date.now(), type: 'call', message: 'You left the call' },
      ...prev
    ]);
    setActiveCall(null);
  };
  const handleOtherLeaves = () => {
    setCallNotifications(prev => [
      { id: Date.now(), type: 'call', message: 'The other user left the call' },
      ...prev
    ]);
    setActiveCall(null);
  };

  // Video/mic/screen controls
  const toggleCallState = (key) => {
    setCallState(prev => ({ ...prev, [key]: !prev[key] }));
  };

  const [workshops] = useState([
    {
      id: 1,
      title: "Resume Building Workshop",
      date: "2024-03-25",
      time: "13:30",
      speaker: "John Smith",
      description: "Learn how to create an effective resume that stands out to employers.",
      status: "upcoming"
    },
    {
      id: 2,
      title: "Interview Preparation",
      date: "2024-03-28",
      time: "15:30",
      speaker: "Sarah Johnson",
      description: "Master the art of interviewing and learn how to present yourself professionally.",
      status: "upcoming"
    }
  ]);

  const handleWorkshopRegister = (workshop) => {
    setSelectedWorkshop(workshop);
    setShowWorkshopModal(true);
  };

  // Define sidebar/quick action items in one place
  const sidebarItems = [
    { key: 'dashboard', label: 'Dashboard', icon: ClipboardList },
    { key: 'profile', label: 'Edit Profile', icon: User },
    { key: 'internships', label: 'Internships', icon: Briefcase },
    { key: 'assessments', label: 'Assessments', icon: ClipboardList },
    { key: 'workshops', label: 'Workshops', icon: Calendar },
    { key: 'appointments', label: 'Appointments', icon: Video },
  ];

  const renderSection = () => {
    switch (activeSection) {
      case 'profile':
        return (
          <div className="profile-section">
            <h3 style={{ fontSize: '1.5rem', fontWeight: 700, color: '#1e293b', marginBottom: '1.5rem' }}>Edit Your Profile</h3>
            {!isEditing ? (
              <>
                <div className="profile-grid" style={{ gap: '1.5rem' }}>
                  <div className="profile-card" style={{ padding: '1.5rem', backgroundColor: '#ffffff', boxShadow: '0 1px 3px rgba(0,0,0,0.1)' }}>
                    <strong style={{ fontSize: '1.1rem', color: '#1e293b' }}>Major</strong>
                    <p style={{ margin: '0.5rem 0 0', color: '#64748b' }}>{formData.major || 'Not specified'}</p>
                  </div>
                  <div className="profile-card" style={{ padding: '1.5rem', backgroundColor: '#ffffff', boxShadow: '0 1px 3px rgba(0,0,0,0.1)' }}>
                    <strong style={{ fontSize: '1.1rem', color: '#1e293b' }}>Semester</strong>
                    <p style={{ margin: '0.5rem 0 0', color: '#64748b' }}>{formData.semester || 'Not specified'}</p>
                  </div>
                  <div className="profile-card" style={{ padding: '1.5rem', backgroundColor: '#ffffff', boxShadow: '0 1px 3px rgba(0,0,0,0.1)' }}>
                    <strong style={{ fontSize: '1.1rem', color: '#1e293b' }}>Job Interests</strong>
                    <p style={{ margin: '0.5rem 0 0', color: '#64748b' }}>{formData.jobInterests || 'Not specified'}</p>
                  </div>
                  <div className="profile-card" style={{ padding: '1.5rem', backgroundColor: '#ffffff', boxShadow: '0 1px 3px rgba(0,0,0,0.1)' }}>
                    <strong style={{ fontSize: '1.1rem', color: '#1e293b' }}>Previous Internships / Part-time Jobs</strong>
                    <p style={{ margin: '0.5rem 0 0', color: '#64748b' }}>{formData.partTimeJobs || 'Not specified'}</p>
                  </div>
                  <div className="profile-card" style={{ padding: '1.5rem', backgroundColor: '#ffffff', boxShadow: '0 1px 3px rgba(0,0,0,0.1)' }}>
                    <strong style={{ fontSize: '1.1rem', color: '#1e293b' }}>College Activities</strong>
                    <p style={{ margin: '0.5rem 0 0', color: '#64748b' }}>{formData.collegeActivities || 'Not specified'}</p>
                  </div>
                </div>
                <div className="button-group" style={{ marginTop: '1.5rem' }}>
                  <button onClick={() => setIsEditing(true)} className="btn btn-primary" style={{ padding: '0.75rem 1.5rem', fontSize: '1rem' }}>Edit Profile</button>
                </div>

                {/* Completed Achievements Section */}
                <div className="profile-section" style={{marginTop: '2rem'}}>
                  <h4 style={{marginBottom: '1.5rem', fontSize: '1.25rem', color: '#1e293b'}}>Completed Achievements</h4>
                  <div style={{display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))', gap: '1.5rem'}}>
                    {/* Completed Internships Card */}
                    <div className="profile-card" style={{padding: '1.5rem', backgroundColor: '#ffffff', boxShadow: '0 1px 3px rgba(0,0,0,0.1)'}}>
                      <div style={{display: 'flex', alignItems: 'center', marginBottom: '1rem'}}>
                        <Briefcase size={20} style={{marginRight: '0.75rem', color: '#2563eb'}} />
                        <strong style={{fontSize: '1.1rem', color: '#1e293b'}}>Completed Internships</strong>
                      </div>
                      {pastPresentInternships.filter(i => i.status === 'Completed').length === 0 ? (
                        <p style={{margin: 0, color: '#64748b', fontSize: '0.95rem'}}>No completed internships yet</p>
                      ) : (
                        <ul style={{margin: 0, paddingLeft: '1.2rem', listStyleType: 'none'}}>
                          {pastPresentInternships.filter(i => i.status === 'Completed').map(i => (
                            <li key={i.id} style={{marginBottom: '0.75rem', padding: '0.75rem', backgroundColor: '#f8fafc', borderRadius: '4px'}}>
                              <div style={{fontWeight: 500, color: '#1e293b'}}>{i.jobTitle}</div>
                              <div style={{color: '#64748b', fontSize: '0.9rem'}}>{i.companyName}</div>
                              <div style={{color: '#94a3b8', fontSize: '0.85rem'}}>{i.duration}</div>
                            </li>
                          ))}
                        </ul>
                      )}
                  </div>

                    {/* Completed Workshops Card */}
                    <div className="profile-card" style={{padding: '1.5rem', backgroundColor: '#ffffff', boxShadow: '0 1px 3px rgba(0,0,0,0.1)'}}>
                      <div style={{display: 'flex', alignItems: 'center', marginBottom: '1rem'}}>
                        <Calendar size={20} style={{marginRight: '0.75rem', color: '#059669'}} />
                        <strong style={{fontSize: '1.1rem', color: '#1e293b'}}>Completed Workshops</strong>
                      </div>
                      {registeredWorkshops.filter(w => w.status === 'completed').length === 0 ? (
                        <p style={{margin: 0, color: '#64748b', fontSize: '0.95rem'}}>No completed workshops yet</p>
                      ) : (
                        <ul style={{margin: 0, paddingLeft: '1.2rem', listStyleType: 'none'}}>
                          {registeredWorkshops.filter(w => w.status === 'completed').map(w => (
                            <li key={w.id} style={{marginBottom: '0.75rem', padding: '0.75rem', backgroundColor: '#f8fafc', borderRadius: '4px'}}>
                              <div style={{fontWeight: 500, color: '#1e293b'}}>{w.title}</div>
                              <div style={{color: '#64748b', fontSize: '0.9rem'}}>{w.date}</div>
                              <div style={{display: 'flex', gap: '0.5rem', marginTop: '0.5rem'}}>
                                {w.notes && (
                                  <span style={{color: '#2563eb', cursor: 'pointer'}} title="View Notes">
                                    <FileText size={16} />
                                  </span>
                                )}
                                {w.recordingUrl && (
                                  <a href={w.recordingUrl} target="_blank" rel="noopener noreferrer" style={{color: '#059669'}} title="Watch Recording">
                                    <Play size={16} />
                                  </a>
                                )}
                              </div>
                            </li>
                          ))}
                        </ul>
                      )}
              </div>

                    {/* Public Assessments Card */}
                    <div className="profile-card" style={{padding: '1.5rem', backgroundColor: '#ffffff', boxShadow: '0 1px 3px rgba(0,0,0,0.1)'}}>
                      <div style={{display: 'flex', alignItems: 'center', marginBottom: '1rem'}}>
                        <ClipboardList size={20} style={{marginRight: '0.75rem', color: '#7c3aed'}} />
                        <strong style={{fontSize: '1.1rem', color: '#1e293b'}}>Public Assessments</strong>
                      </div>
                      {assessmentScores.filter(a => a.isPublic).length === 0 ? (
                        <p style={{margin: 0, color: '#64748b', fontSize: '0.95rem'}}>No public assessments yet</p>
                      ) : (
                        <ul style={{margin: 0, paddingLeft: '1.2rem', listStyleType: 'none'}}>
                          {assessmentScores.filter(a => a.isPublic).map(a => (
                            <li key={a.id} style={{marginBottom: '0.75rem', padding: '0.75rem', backgroundColor: '#f8fafc', borderRadius: '4px'}}>
                              <div style={{fontWeight: 500, color: '#1e293b'}}>{a.title}</div>
                              <div style={{display: 'flex', justifyContent: 'space-between', alignItems: 'center'}}>
                                <div style={{color: '#64748b', fontSize: '0.9rem'}}>{a.date}</div>
                                <div style={{
                                  padding: '0.25rem 0.5rem',
                                  backgroundColor: a.score >= 80 ? '#dcfce7' : a.score >= 60 ? '#fef9c3' : '#fee2e2',
                                  color: a.score >= 80 ? '#059669' : a.score >= 60 ? '#b45309' : '#dc2626',
                                  borderRadius: '4px',
                                  fontSize: '0.9rem',
                                  fontWeight: 500
                                }}>
                                  {a.score}%
                                </div>
                              </div>
                            </li>
                          ))}
                        </ul>
                      )}
                    </div>
                  </div>
                </div>
              </>
            ) : (
              <form onSubmit={handleSubmit} className="profile-form" style={{ maxWidth: '600px', margin: '0 auto' }}>
                <div className="form-group" style={{ marginBottom: '1.5rem' }}>
                  <label htmlFor="major" style={{ display: 'block', marginBottom: '0.5rem', fontWeight: 500, color: '#1e293b' }}>Major</label>
                  <select id="major" name="major" value={formData.major} onChange={handleChange} className={`form-control ${errors.major ? 'error' : ''}`} style={{ width: '100%', padding: '0.75rem', borderRadius: '0.375rem', border: '1px solid #e2e8f0' }}>
                    <option value="">Select Major</option>
                    {majors.map((major) => (
                      <option key={major} value={major}>{major}</option>
                    ))}
                  </select>
                  {errors.major && <span className="error-message" style={{ color: '#dc2626', fontSize: '0.875rem', marginTop: '0.25rem' }}>{errors.major}</span>}
                    </div>
                <div className="form-group" style={{ marginBottom: '1.5rem' }}>
                  <label htmlFor="semester" style={{ display: 'block', marginBottom: '0.5rem', fontWeight: 500, color: '#1e293b' }}>Semester</label>
                  <select id="semester" name="semester" value={formData.semester} onChange={handleChange} className={`form-control ${errors.semester ? 'error' : ''}`} style={{ width: '100%', padding: '0.75rem', borderRadius: '0.375rem', border: '1px solid #e2e8f0' }}>
                    <option value="">Select Semester</option>
                    {semesters.map((sem) => (
                      <option key={sem} value={sem}>{sem}</option>
                    ))}
                  </select>
                  {errors.semester && <span className="error-message" style={{ color: '#dc2626', fontSize: '0.875rem', marginTop: '0.25rem' }}>{errors.semester}</span>}
                </div>
                <div className="form-group" style={{ marginBottom: '1.5rem' }}>
                  <label htmlFor="jobInterests" style={{ display: 'block', marginBottom: '0.5rem', fontWeight: 500, color: '#1e293b' }}>Job Interests</label>
                  <textarea id="jobInterests" name="jobInterests" value={formData.jobInterests} onChange={handleChange} placeholder="Describe your job interests..." className={`form-control ${errors.jobInterests ? 'error' : ''}`} style={{ width: '100%', padding: '0.75rem', borderRadius: '0.375rem', border: '1px solid #e2e8f0', minHeight: '100px' }} />
                  {errors.jobInterests && <span className="error-message" style={{ color: '#dc2626', fontSize: '0.875rem', marginTop: '0.25rem' }}>{errors.jobInterests}</span>}
            </div>
                <div className="form-group" style={{ marginBottom: '1.5rem' }}>
                  <label htmlFor="partTimeJobs" style={{ display: 'block', marginBottom: '0.5rem', fontWeight: 500, color: '#1e293b' }}>Previous Internships / Part-time Jobs</label>
                  <textarea id="partTimeJobs" name="partTimeJobs" value={formData.partTimeJobs} onChange={handleChange} placeholder="Company, Duration, Responsibilities..." className="form-control" style={{ width: '100%', padding: '0.75rem', borderRadius: '0.375rem', border: '1px solid #e2e8f0', minHeight: '100px' }} />
            </div>
                <div className="form-group" style={{ marginBottom: '1.5rem' }}>
                  <label htmlFor="collegeActivities" style={{ display: 'block', marginBottom: '0.5rem', fontWeight: 500, color: '#1e293b' }}>College Activities</label>
                  <textarea id="collegeActivities" name="collegeActivities" value={formData.collegeActivities} onChange={handleChange} placeholder="Describe your college activities..." className="form-control" style={{ width: '100%', padding: '0.75rem', borderRadius: '0.375rem', border: '1px solid #e2e8f0', minHeight: '100px' }} />
                </div>
                <div className="form-actions" style={{ display: 'flex', gap: '1rem' }}>
                  <button type="submit" className="btn btn-primary" style={{ padding: '0.75rem 1.5rem', fontSize: '1rem' }}>Save Changes</button>
                  <button type="button" className="btn btn-secondary" onClick={handleCancel} style={{ padding: '0.75rem 1.5rem', fontSize: '1rem' }}>Cancel</button>
                </div>
              </form>
            )}
          </div>
        );
      case 'suggested-companies':
        return (
          <div className="profile-section">
            <h3>Suggested Companies</h3>
            <div className="profile-grid">
              {suggestedCompanies.map(({ name, industry, recommendedByPastInterns }, i) => (
                <div key={i} className="profile-card">
                  <strong>{name}</strong>
                  <p>Industry: {industry}</p>
                  {recommendedByPastInterns && (
                    <span className="recommended-badge">Recommended by past interns</span>
                  )}
                </div>
              ))}
            </div>
          </div>
        );
      case 'assessments':
        return (
          <div className="profile-section">
            <h3>Available Assessments</h3>
            <div className="assessment-grid">
              {availableAssessments.map((assessment) => (
                <div key={assessment.id} className="assessment-card">
                  <h4>{assessment.title}</h4>
                  <p>Duration: {assessment.duration}</p>
                  <button className="btn btn-yellow mt-4" onClick={() => handleStartAssessment(assessment)}>
                    Start Assessment
                  </button>
                </div>
              ))}
            </div>
            <h3 style={{ marginTop: '2.5rem' }}>Assessment History</h3>
            <div className="assessment-grid">
              {assessmentScores.map((score) => (
                <div key={score.id} className="assessment-card">
                  <div className="flex justify-between items-start mb-4">
                    <div>
                      <h4>{score.title}</h4>
                      <p className="text-gray-600">Taken on: {score.date}</p>
                    </div>
                    <div className="text-right">
                      <div className="text-2xl font-bold text-yellow-600">{score.score}%</div>
                      <div className="text-sm text-gray-500">
                        {score.correctAnswers}/{score.totalQuestions} correct
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center justify-between mt-4">
                    <button className="btn btn-yellow flex-1 mr-2" onClick={() => handleViewScore(score)}>
                      View Details
                    </button>
                    <label className="flex items-center cursor-pointer">
                      <div className="relative">
                        <input
                          type="checkbox"
                          className="sr-only"
                          checked={score.isPublic}
                          onChange={() => handleToggleScoreVisibility(score.id)}
                        />
                        <div className={`block w-14 h-8 rounded-full transition-colors duration-200 ease-in-out ${score.isPublic ? 'bg-yellow-500' : 'bg-gray-300'}`}></div>
                        <div className={`dot absolute left-1 top-1 bg-white w-6 h-6 rounded-full transition-transform duration-200 ease-in-out ${score.isPublic ? 'transform translate-x-6' : ''}`}></div>
                      </div>
                      <span className="ml-3 text-sm text-gray-600">Public</span>
                    </label>
                  </div>
                </div>
              ))}
            </div>
          </div>
        );
      case 'workshops':
        return (
          <div className="profile-section">
            <h3>Career Workshops</h3>
            <div className="workshop-grid">
              {workshops.map((workshop) => (
                <div key={workshop.id} className="workshop-card">
                  <div className="workshop-header">
                    <h4>{workshop.title}</h4>
                    <span className={`workshop-status ${workshop.status}`}>{workshop.status}</span>
                  </div>
                  <div className="workshop-details">
                    <div className="workshop-time">
                      <Clock size={16} />
                      <span>{workshop.time}</span>
                    </div>
                    <p className="workshop-speaker">Speaker: {workshop.speaker}</p>
                    <p className="workshop-description">{workshop.description}</p>
                  </div>
                  <button className="workshop-register" onClick={() => handleWorkshopRegister(workshop)}>
                    Register Now
                  </button>
                </div>
              ))}
            </div>
            <h3 style={{ marginTop: '2.5rem' }}>Registered Workshops</h3>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem', marginTop: '1rem' }}>
              {registeredWorkshops.map((workshop) => (
                <div key={workshop.id} className="workshop-card">
                  <div className="workshop-header">
                    <h4>{workshop.title}</h4>
                    <span className={`workshop-status ${workshop.status}`}>{workshop.status}</span>
                  </div>
                  <div className="workshop-details">
                    <p className="workshop-time">
                      <Calendar size={16} />
                      {new Date(workshop.date).toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' })} at {workshop.time}
                    </p>
                    <p className="workshop-duration">Duration: {workshop.duration}</p>
                  </div>
                  {workshop.type === 'live' && workshop.status === 'upcoming' ? (
                    <>
                      <button className="btn btn-yellow workshop-join">
                        <Video size={20} />
                        Join Live Workshop
                      </button>
                      <div className="workshop-chat-panel">
                        <h5>Live Chat</h5>
                        <div className="chat-messages">
                          {chatMessages.map((msg, idx) => (
                            <div key={idx} className={`chat-message ${msg.sender === 'You' ? 'self' : ''}`}>
                              <span className="chat-sender">{msg.sender}:</span> <span>{msg.message}</span>
                              <span className="chat-time">{msg.time}</span>
                            </div>
                          ))}
                        </div>
                        <div className="chat-input-row">
                          <input
                            type="text"
                            className="chat-input"
                            placeholder="Type a message..."
                            value={chatInput}
                            onChange={e => setChatInput(e.target.value)}
                            onKeyDown={e => { if (e.key === 'Enter') handleSendChat(); }}
                          />
                          <button className="btn btn-yellow chat-send" onClick={handleSendChat}>Send</button>
                        </div>
                      </div>
                    </>
                  ) : workshop.type === 'recorded' ? (
                    <div className="workshop-recording">
                      <div className="recording-controls">
                        <button 
                          className="btn btn-yellow"
                          onClick={() => setIsPlaying(!isPlaying)}
                        >
                          {isPlaying ? <Pause size={20} /> : <Play size={20} />}
                          {isPlaying ? 'Pause' : 'Play'} Recording
                        </button>
                        <div className="recording-progress">
                          <div 
                            className="progress-bar" 
                            style={{ width: `${(currentTime / 3600) * 100}%` }}
                          ></div>
                        </div>
                      </div>
                      <div className="workshop-notes">
                        <h5>Workshop Notes</h5>
                        <textarea
                          value={workshop.notes || notes}
                          onChange={(e) => setNotes(e.target.value)}
                          placeholder="Take notes during the workshop..."
                          className="notes-textarea"
                        />
                        <button className="btn btn-secondary save-notes">
                          Save Notes
                        </button>
                      </div>
                      <div className="workshop-certificate-feedback" style={{ display: 'flex', flexDirection: 'row', alignItems: 'flex-start', justifyContent: 'space-between', marginTop: '1rem', marginBottom: '0.5rem', gap: '1rem' }}>
                        <div className="workshop-rating-feedback" style={{ flex: 1 }}>
                          <div className="workshop-rating">
                            <span style={{marginRight: 8}}>Rate this workshop: </span>
                            <div
                              style={{
                                display: 'flex',
                                flexWrap: 'wrap',
                                gap: '0.3rem',
                                alignItems: 'center',
                                minHeight: 32,
                              }}
                            >
                              {[1, 2, 3, 4, 5].map((star) => (
                                <span
                                  key={star}
                                  className={`star ${workshopRatings[workshop.id] >= star ? 'filled' : ''}`}
                                  style={{
                                    cursor: 'pointer',
                                    fontSize: 'clamp(1.2rem, 4vw, 2rem)',
                                    color: workshopRatings[workshop.id] >= star ? '#f6ad55' : '#e2e8f0',
                                    padding: '0.2em 0.4em',
                                    borderRadius: 8,
                                    transition: 'background 0.15s',
                                    display: 'inline-block',
                                    minWidth: 28,
                                    textAlign: 'center',
                                  }}
                                  tabIndex={0}
                                  role="button"
                                  aria-label={`Rate ${star} star${star > 1 ? 's' : ''}`}
                                  onClick={() => setWorkshopRatings(r => ({ ...r, [workshop.id]: star }))}
                                  onKeyDown={e => { if (e.key === 'Enter' || e.key === ' ') setWorkshopRatings(r => ({ ...r, [workshop.id]: star })); }}
                                >
                                  ★
                                </span>
                              ))}
                            </div>
                          </div>
                          <textarea
                            className="notes-textarea"
                            placeholder="Leave your feedback..."
                            // value and onChange for feedback (implement state as needed)
                            style={{ marginTop: '0.5rem' }}
                          />
                          <button className="btn btn-secondary save-notes" style={{ marginTop: '0.5rem' }}>
                            Submit Feedback
                          </button>
                        </div>
                      </div>
                      <a
                        href="/certificate.pdf"
                        download
                        className="btn btn-yellow certificate-btn"
                        style={{ alignSelf: 'flex-start', whiteSpace: 'nowrap' }}
                      >
                        🎓 Download Certificate
                      </a>
                    </div>
                  ) : null}
                </div>
              ))}
            </div>
          </div>
        );
      case 'internships':
        return (
          <div className="profile-section">
            {/* Guidance Video Section */}
            <section className="profile-section" style={{ marginBottom: '2rem' }}>
              <h2 style={{ fontWeight: 700, fontSize: '1.3rem', color: '#1e293b', marginBottom: '1rem' }}>What Counts as an Internship?</h2>
              {formData.major && majorVideos[formData.major] ? (
                <div style={{ maxWidth: 480, margin: '0 auto', background: '#f9fafb', borderRadius: '0.7rem', boxShadow: '0 2px 8px #0001', padding: '1rem' }}>
                  <iframe
                    width="100%"
                    height="270"
                    src={majorVideos[formData.major]}
                    title={`What counts as an internship for ${formData.major}`}
                    frameBorder="0"
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                    allowFullScreen
                    style={{ borderRadius: '0.7rem' }}
                  ></iframe>
                  <div style={{ marginTop: '0.7rem', color: '#334155', fontSize: '1rem' }}>
                    This video explains what types of internships are accepted for your major.
                  </div>
          </div>
        ) : (
                <div style={{ color: '#b45309', fontStyle: 'italic' }}>Select your major in your profile to see a guidance video.</div>
              )}
            </section>
            <header className="profile-header internship-header-pro">
              <div className="flex justify-between items-center w-full gap-6">
                <h1>Internships</h1>
                <div className="internship-searchbar-pro">
                  <input
                    type="text"
                    value={search}
                    onChange={(e) => setSearch(e.target.value)}
                    placeholder="Search by job title or company"
                    className="form-control internship-search-input"
                  />
                  <select
                    name="industry"
                    value={filters.industry}
                    onChange={handleFilterChange}
                    className="form-control internship-filter-select"
                  >
                    <option value="">All Industries</option>
                    {industries.map((industry) => (
                      <option key={industry} value={industry}>
                        {industry}
                      </option>
                    ))}
                  </select>
                <select
                    name="duration"
                    value={filters.duration}
                    onChange={handleFilterChange}
                    className="form-control internship-filter-select"
                  >
                    <option value="">All Durations</option>
                    {durations.map((duration) => (
                      <option key={duration} value={duration}>
                        {duration}
                    </option>
                  ))}
                </select>
                <select
                    name="paid"
                    value={filters.paid}
                    onChange={handleFilterChange}
                    className="form-control internship-filter-select"
                  >
                    <option value="">All Types</option>
                    {paidOptions.map((option) => (
                      <option key={option} value={option}>
                        {option}
                    </option>
                  ))}
                </select>
                  <button className="btn reset-filters-btn" onClick={resetFilters} type="button">
                    Reset Filters
                  </button>
                </div>
              </div>
            </header>

            {/* Available Internships Section */}
            <section className="profile-section">
              <h3>Available Internships</h3>
              <div className="available-internships-vertical">
                {filteredInternships.map((internship) => {
                  // Check if already applied
                  const isApplied = appliedInternships.some(app => app.id === internship.id);
                  if (isApplied) return null;
                  return (
                    <div key={internship.id} className="big-internship-card">
                      <div
                        className="big-internship-summary"
                        onClick={() => setExpandedInternshipId(expandedInternshipId === internship.id ? null : internship.id)}
                        style={{ cursor: 'pointer', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}
                      >
                        <div>
                          <strong style={{ fontSize: '1.3rem' }}>{internship.jobTitle}</strong>
                          <p style={{ fontSize: '1.1rem', margin: 0 }}>{internship.companyName}</p>
                        </div>
                        <span style={{ fontSize: '2rem', color: '#f6ad55' }}>{expandedInternshipId === internship.id ? '▲' : '▼'}</span>
                      </div>
                      {expandedInternshipId === internship.id && (
                        <div className="big-internship-details" style={{ marginTop: '1rem', background: '#f9fafb', borderRadius: '0.5rem', padding: '1rem', boxShadow: '0 2px 8px #0001' }}>
                          <p><strong>Duration:</strong> {internship.duration}</p>
                          <p><strong>Industry:</strong> {internship.industry}</p>
                          <p><strong>Type:</strong> {internship.paid}</p>
                          <p><strong>Salary:</strong> {internship.salary}</p>
                          <p><strong>Skills Required:</strong> {internship.skills}</p>
                          <p><strong>Description:</strong> {internship.description}</p>
                          <div style={{ margin: '1rem 0' }}>
                            <label htmlFor={`cv-upload-${internship.id}`} style={{ fontWeight: 500 }}>Upload CV:</label>
                            <input
                              id={`cv-upload-${internship.id}`}
                              type="file"
                              accept=".pdf,.doc,.docx"
                              onChange={e => {
                                const file = e.target.files[0];
                                if (file) {
                                  setUploadedFiles([file.name]);
                                }
                              }}
                              style={{ display: 'block', marginTop: '0.5rem' }}
                            />
                            {uploadedFiles.length > 0 && (
                              <div style={{ marginTop: '0.5rem', color: '#2563eb', fontWeight: 500 }}>
                                Selected: {uploadedFiles[0]}
                              </div>
                )}
              </div>
                          <button
                            className="btn btn-yellow"
                            style={{ marginTop: '1rem' }}
                            onClick={e => {
                              e.stopPropagation();
                              setSelectedInternship(internship);
                              handleApply();
                              setExpandedInternshipId(null);
                            }}
                            disabled={uploadedFiles.length === 0}
                          >
                            Apply
                          </button>
            </div>
                      )}
                    </div>
                  );
                })}
                {filteredInternships.filter(internship => !appliedInternships.some(app => app.id === internship.id)).length === 0 && (
                  <p className="text-center text-gray-600 col-span-full">
                    No internships match your criteria.
                  </p>
                )}
              </div>
            </section>

            {/* My Applications */}
            <section className="profile-section">
              <h3>My Applications</h3>
              {appliedInternships.length === 0 ? (
                <p className="text-center text-gray-600">No applications submitted yet.</p>
              ) : (
                <div className="profile-grid">
                  {appliedInternships.map((app) => (
                    <div
                      key={app.id}
                      className="profile-card cursor-pointer"
                      onClick={() =>
                        setSelectedInternship({
                          ...internships.find((i) => i.id === app.id),
                          applicationStatus: app.status,
                          documents: app.documents,
                        })
                      }
                    >
                      <strong>{app.jobTitle}</strong>
                      <p>{app.companyName}</p>
                      <p>Applied: {app.applicationDate}</p>
                      <p>
                        <strong>Status: </strong>
                        <span className={`status ${app.status.toLowerCase()}`}>{app.status}</span>
                      </p>
                    </div>
                  ))}
                </div>
              )}
            </section>

            {/* My Internships */}
            <section className="profile-section">
              <h3>My Internships</h3>
              {pastPresentInternships.length === 0 ? (
                <p className="text-center text-gray-600">No past or present internships.</p>
              ) : (
                <div className="profile-grid">
                  {pastPresentInternships.map((internship) => (
                    <div key={internship.id} className="profile-card">
                      <strong>{internship.jobTitle}</strong>
                      <p>{internship.companyName}</p>
                      <p>Duration: {internship.duration}</p>
                      <p>
                        <strong>Status: </strong>
                        <span className={`status ${internship.status.toLowerCase()}`}>{internship.status}</span>
                      </p>
                      {internship.status === 'Completed' && (
                        <div style={{ marginTop: '1rem' }}>
                          {evaluations[internship.id] ? (
                            <div className="evaluation-display" style={{ background: '#f9fafb', borderRadius: '0.5rem', padding: '1rem', marginTop: '0.5rem' }}>
                              <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                                {[1,2,3,4,5].map(star => (
                                  <span key={star} style={{ color: star <= evaluations[internship.id].rating ? '#f6ad55' : '#e2e8f0', fontSize: '1.5rem' }}>★</span>
                                ))}
                                <span style={{ marginLeft: '1rem', fontWeight: 500 }}>{evaluations[internship.id].recommend ? '🌟 Recommended' : '⚠️ Not Recommended'}</span>
                              </div>
                              <div style={{ margin: '0.5rem 0', fontStyle: 'italic', color: '#334155' }}>
                                "{evaluations[internship.id].feedback}"
                              </div>
                              <button className="btn btn-yellow" style={{ marginRight: '0.5rem' }} onClick={() => handleEditEvaluation(internship.id)}>Edit</button>
                              <button className="btn btn-secondary" onClick={() => handleDeleteEvaluation(internship.id)}>Delete</button>
                            </div>
                          ) : (
                            <button className="btn btn-yellow" onClick={() => {
                              setEvalDraft({ rating: 0, feedback: '', recommend: false });
                              setExpandedEvaluationId(internship.id);
                            }}>Evaluate Company</button>
                          )}
                          {expandedEvaluationId === internship.id && (
                            <div className="evaluation-form" style={{ background: '#fffbe8', borderRadius: '0.5rem', padding: '1rem', marginTop: '0.5rem', boxShadow: '0 2px 8px #0001' }}>
                              <div style={{ marginBottom: '0.7rem' }}>
                                <span style={{ fontWeight: 500 }}>Your Rating: </span>
                                {[1,2,3,4,5].map(star => (
                                  <span
                                    key={star}
                                    style={{ cursor: 'pointer', color: star <= evalDraft.rating ? '#f6ad55' : '#e2e8f0', fontSize: '2rem' }}
                                    onClick={() => handleEvalChange('rating', star)}
                                  >★</span>
                                ))}
                              </div>
                              <textarea
                                className="form-control"
                                placeholder="Share your experience with this company..."
                                value={evalDraft.feedback}
                                onChange={e => handleEvalChange('feedback', e.target.value)}
                                style={{ width: '100%', minHeight: '60px', marginBottom: '0.7rem' }}
                              />
                              <div style={{ marginBottom: '0.7rem' }}>
                                <label style={{ fontWeight: 500, marginRight: '1rem' }}>Recommend to other students?</label>
                                <input
                                  type="checkbox"
                                  checked={evalDraft.recommend}
                                  onChange={e => handleEvalChange('recommend', e.target.checked)}
                                  id={`recommend-toggle-${internship.id}`}
                                />
                                <label htmlFor={`recommend-toggle-${internship.id}`} style={{ marginLeft: '0.5rem' }}>{evalDraft.recommend ? 'Yes' : 'No'}</label>
                              </div>
                              <button className="btn btn-yellow" style={{ marginRight: '0.5rem' }} onClick={() => handleSaveEvaluation(internship.id)}>Save</button>
                              <button className="btn btn-secondary" onClick={() => setExpandedEvaluationId(null)}>Cancel</button>
                            </div>
                          )}
                          {/* Report UI */}
                          <div style={{ marginTop: '1.5rem' }}>
                            {reports[internship.id] ? (
                              <div className="report-display" style={{ background: '#f1f5f9', borderRadius: '0.5rem', padding: '1rem', marginTop: '0.5rem' }}>
                                <div style={{ fontWeight: 700, fontSize: '1.1rem', color: '#1e293b' }}>{reports[internship.id].title}</div>
                                <div style={{ fontStyle: 'italic', color: '#475569', margin: '0.5rem 0' }}>{reports[internship.id].introduction}</div>
                                <div style={{ color: '#334155', marginBottom: '0.7rem' }}>{reports[internship.id].body}</div>
                                {reports[internship.id].courses && reports[internship.id].courses.length > 0 && (
                                  <div style={{ margin: '0.5rem 0', color: '#2563eb' }}>
                                    <strong>Courses that helped you:</strong> {reports[internship.id].courses.join(', ')}
                                  </div>
                                )}
                                {/* Comments and Appeal Section */}
                                {['flagged', 'rejected'].includes(reports[internship.id].status) && (
                                  <div style={{ background: '#fffbe8', borderRadius: '0.5rem', padding: '1rem', margin: '1rem 0', border: '1px solid #f6ad55' }}>
                                    <h4 style={{ color: '#b45309', marginBottom: '0.5rem' }}>Report Comments</h4>
                                    <ul style={{ color: '#b45309', marginBottom: '0.7rem' }}>
                                      {(reportComments[internship.id] || ['This report needs clarification. Please review the feedback.']).map((comment, idx) => (
                                        <li key={idx}>{comment}</li>
                                      ))}
                                    </ul>
                                    {appealStatus[internship.id] ? (
                                      <div style={{ color: '#2563eb', fontWeight: 500 }}>
                                        Appeal submitted: "{appealStatus[internship.id].message}"<br/>
                                        Status: {appealStatus[internship.id].status}
                                      </div>
                                    ) : showAppealFormId === internship.id ? (
                                      <div style={{ marginTop: '0.7rem' }}>
                                        <textarea
                                          className="form-control"
                                          placeholder="Write your appeal message..."
                                          value={appealDraft}
                                          onChange={e => setAppealDraft(e.target.value)}
                                          style={{ width: '100%', minHeight: '60px', marginBottom: '0.7rem' }}
                                        />
                                        <button className="btn btn-yellow" style={{ marginRight: '0.5rem' }} onClick={() => handleAppealSubmit(internship.id)}>Submit Appeal</button>
                                        <button className="btn btn-secondary" onClick={() => setShowAppealFormId(null)}>Cancel</button>
                                      </div>
                                    ) : (
                                      <button className="btn btn-primary" onClick={() => setShowAppealFormId(internship.id)}>Appeal</button>
                                    )}
                                  </div>
                                )}
                                <button className="btn btn-yellow" style={{ marginRight: '0.5rem' }} onClick={() => handleEditReport(internship.id)}>Edit Report</button>
                                <button className="btn btn-secondary" onClick={() => handleDeleteReport(internship.id)}>Delete Report</button>
                                <button className="btn btn-primary" style={{ marginLeft: '0.5rem' }} onClick={() => setViewFinalReportId(internship.id)}>View Final Report</button>
                                {submittedReports[internship.id] && <span style={{ marginLeft: '1rem', color: '#059669', fontWeight: 600 }}>Submitted</span>}
                              </div>
                            ) : (
                              <button className="btn btn-yellow" onClick={() => {
                                setReportDraft({ title: '', introduction: '', body: '', courses: [] });
                                setExpandedReportId(internship.id);
                              }}>Create Report</button>
                            )}
                            {expandedReportId === internship.id && (
                              <div className="report-form" style={{ background: '#fffbe8', borderRadius: '0.5rem', padding: '1rem', marginTop: '0.5rem', boxShadow: '0 2px 8px #0001' }}>
                                <input
                                  className="form-control"
                                  placeholder="Report Title"
                                  value={reportDraft.title}
                                  onChange={e => handleReportChange('title', e.target.value)}
                                  style={{ width: '100%', marginBottom: '0.7rem', fontWeight: 600 }}
                                />
                                <textarea
                                  className="form-control"
                                  placeholder="Introduction"
                                  value={reportDraft.introduction}
                                  onChange={e => handleReportChange('introduction', e.target.value)}
                                  style={{ width: '100%', minHeight: '40px', marginBottom: '0.7rem' }}
                                />
                                <textarea
                                  className="form-control"
                                  placeholder="Body"
                                  value={reportDraft.body}
                                  onChange={e => handleReportChange('body', e.target.value)}
                                  style={{ width: '100%', minHeight: '80px', marginBottom: '0.7rem' }}
                                />
                                <div style={{ marginBottom: '0.7rem' }}>
                                  <label style={{ fontWeight: 500 }}>Courses that helped you:</label>
                                  <div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.7rem', marginTop: '0.5rem' }}>
                                    {(formData.major && majorCourses[formData.major] ? majorCourses[formData.major] : []).map(course => (
                                      <label key={course} style={{ display: 'flex', alignItems: 'center', gap: '0.3rem', background: '#f1f5f9', borderRadius: '0.4rem', padding: '0.2rem 0.7rem' }}>
                                        <input
                                          type="checkbox"
                                          checked={reportDraft.courses.includes(course)}
                                          onChange={() => handleCourseToggle(course)}
                                        />
                                        {course}
                                      </label>
                                    ))}
                                  </div>
                                </div>
                                <button className="btn btn-yellow" style={{ marginRight: '0.5rem' }} onClick={() => handleSaveReport(internship.id)}>Save</button>
                                <button className="btn btn-secondary" onClick={() => setExpandedReportId(null)}>Cancel</button>
                              </div>
                            )}
                          </div>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </section>
          </div>
        );
      case 'appointments':
        return (
          <div className="profile-section">
            <h2>Appointments & Video Calls</h2>
            <div style={{ marginBottom: '1.5rem', background: '#f9fafb', borderRadius: '0.7rem', padding: '1rem', boxShadow: '0 2px 8px #0001' }}>
              <h4>Request an Appointment</h4>
              <input
                type="date"
                value={appointmentDraft.date}
                onChange={e => setAppointmentDraft(d => ({ ...d, date: e.target.value }))}
                className="form-control"
                style={{ marginBottom: '0.5rem' }}
              />
              <input
                type="time"
                value={appointmentDraft.time}
                onChange={e => setAppointmentDraft(d => ({ ...d, time: e.target.value }))}
                className="form-control"
                style={{ marginBottom: '0.5rem' }}
              />
              <input
                type="text"
                placeholder="Reason for appointment"
                value={appointmentDraft.reason}
                onChange={e => setAppointmentDraft(d => ({ ...d, reason: e.target.value }))}
                className="form-control"
                style={{ marginBottom: '0.5rem' }}
              />
              <button className="btn btn-yellow" onClick={handleRequestAppointment}>Request Appointment</button>
            </div>
            <div style={{ marginBottom: '1.5rem' }}>
              <h4>My Appointments</h4>
              {appointments.length === 0 ? (
                <div style={{ color: '#b45309' }}>No appointments yet.</div>
              ) : (
                <ul style={{ listStyle: 'none', padding: 0 }}>
                  {appointments.map(app => (
                    <li key={app.id} style={{ background: '#fff', borderRadius: '0.5rem', marginBottom: '1rem', padding: '1rem', boxShadow: '0 2px 8px #0001' }}>
                      <div><strong>Date:</strong> {app.date} <strong>Time:</strong> {app.time}</div>
                      <div><strong>Reason:</strong> {app.reason}</div>
                      <div><strong>Status:</strong> <span style={{ color: app.status === 'accepted' ? '#059669' : app.status === 'rejected' ? '#dc2626' : '#b45309' }}>{app.status}</span></div>
                      <div><strong>SCAD Officer:</strong> <span style={{ color: app.scadOnline ? '#059669' : '#b45309' }}>{app.scadOnline ? 'Online' : 'Offline'}</span></div>
                      <div><strong>You:</strong> <span style={{ color: app.studentOnline ? '#059669' : '#b45309' }}>{app.studentOnline ? 'Online' : 'Offline'}</span></div>
                      {app.status === 'pending' && (
                        <>
                          <button className="btn btn-yellow" style={{ marginRight: '0.5rem' }} onClick={() => handleAppointmentAction(app.id, 'accepted')}>Accept</button>
                          <button className="btn btn-secondary" onClick={() => handleAppointmentAction(app.id, 'rejected')}>Reject</button>
                        </>
                      )}
                      {app.status === 'accepted' && !activeCall && (
                        <button className="btn btn-primary" onClick={() => handleStartCall(app)}>Start Call</button>
                      )}
                    </li>
                  ))}
                </ul>
              )}
            </div>
            <div style={{ marginBottom: '1.5rem' }}>
              <h4>Appointment Notifications</h4>
              <ul style={{ color: '#2563eb', listStyle: 'none', padding: 0 }}>
                {appointmentNotifications.map(n => (
                  <li key={n.id}>{n.message} ({n.status})</li>
                ))}
              </ul>
            </div>
            <div style={{ marginBottom: '1.5rem' }}>
              <h4>Online Status</h4>
              <button className="btn btn-secondary" style={{ marginRight: '0.5rem' }} onClick={() => toggleOnline('student')}>Toggle My Online</button>
              <button className="btn btn-secondary" onClick={() => toggleOnline('scad')}>Toggle SCAD Online</button>
            </div>
            {/* Incoming Call Notification */}
            {incomingCall && (
              <div className="fixed inset-0 bg-black bg-opacity-40 flex items-center justify-center z-50">
                <div className="bg-white rounded-xl shadow-2xl p-6 max-w-md w-full text-center">
                  <h3 style={{ fontWeight: 700, fontSize: '1.2rem', marginBottom: '1rem' }}>Incoming Call from {incomingCall.from}</h3>
                  <button className="btn btn-primary" style={{ marginRight: '0.5rem' }} onClick={handleAcceptCall}>Accept</button>
                  <button className="btn btn-secondary" onClick={handleRejectCall}>Reject</button>
                </div>
              </div>
            )}
            {/* Active Call UI */}
            {activeCall && (
              <div className="fixed inset-0 bg-black bg-opacity-40 flex items-center justify-center z-50">
                <div className="bg-white rounded-xl shadow-2xl p-6 max-w-2xl w-full text-center">
                  <h3 style={{ fontWeight: 700, fontSize: '1.2rem', marginBottom: '1rem' }}>Video Call with {activeCall.with}</h3>
                  <div style={{ display: 'flex', justifyContent: 'center', gap: '2rem', marginBottom: '1.5rem' }}>
                    <div style={{ width: 200, height: 120, background: callState.video ? '#dbeafe' : '#f1f5f9', borderRadius: '0.5rem', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#334155' }}>
                      {callState.video ? 'Your Video Stream' : 'Video Off'}
                    </div>
                    <div style={{ width: 200, height: 120, background: '#f1f5f9', borderRadius: '0.5rem', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#334155' }}>
                      Other User Video
                    </div>
                  </div>
                  <div style={{ display: 'flex', justifyContent: 'center', gap: '1rem', marginBottom: '1.5rem' }}>
                    <button className="btn btn-secondary" onClick={() => toggleCallState('video')}>{callState.video ? 'Disable Video' : 'Enable Video'}</button>
                    <button className="btn btn-secondary" onClick={() => toggleCallState('mic')}>{callState.mic ? 'Mute Mic' : 'Unmute Mic'}</button>
                    <button className="btn btn-secondary" onClick={() => toggleCallState('screen')}>{callState.screen ? 'Stop Sharing' : 'Share Screen'}</button>
                  </div>
                  <button className="btn btn-yellow" style={{ marginRight: '0.5rem' }} onClick={handleLeaveCall}>Leave Call</button>
                  <button className="btn btn-secondary" onClick={handleOtherLeaves}>Simulate Other User Leaves</button>
                </div>
              </div>
            )}
            {/* Call Notifications */}
            {callNotifications.length > 0 && (
              <div className="call-notification-list" style={{ position: 'fixed', bottom: 20, right: 20, zIndex: 1000 }}>
                {callNotifications.map(n => (
                  <div key={n.id} style={{ background: '#fef9c3', color: '#b45309', borderRadius: '0.5rem', padding: '0.7rem 1.2rem', marginBottom: '0.5rem', boxShadow: '0 2px 8px #0001' }}>{n.message}</div>
                ))}
              </div>
            )}
          </div>
        );
      case 'dashboard':
        return (
          <div className="dashboard-content">
            <div className="welcome-section" style={{marginBottom: '2rem'}}>
              <h2 style={{fontSize: '1.5rem', color: '#1e293b', marginBottom: '1rem'}}>Welcome back, {formData.name || 'Student'}!</h2>
              <p style={{color: '#64748b', fontSize: '1.1rem'}}>Here's an overview of your internship portal activity.</p>
            </div>

            {/* Stats Grid */}
            <div style={{
              display: 'grid',
              gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))',
              gap: '1rem',
              marginBottom: '2rem'
            }}>
              <div className="profile-card" style={{padding: '1.5rem', backgroundColor: '#ffffff', boxShadow: '0 1px 3px rgba(0,0,0,0.1)'}}>
                <div style={{display: 'flex', alignItems: 'center', marginBottom: '0.5rem'}}>
                  <Building2 size={20} style={{marginRight: '0.75rem', color: '#2563eb'}} />
                  <strong style={{fontSize: '1.1rem', color: '#1e293b'}}>Registered Companies</strong>
                </div>
                <p style={{fontSize: '1.5rem', fontWeight: 'bold', color: '#1e293b', margin: 0}}>150+</p>
              </div>
              <div className="profile-card" style={{padding: '1.5rem', backgroundColor: '#ffffff', boxShadow: '0 1px 3px rgba(0,0,0,0.1)'}}>
                <div style={{display: 'flex', alignItems: 'center', marginBottom: '0.5rem'}}>
                  <Briefcase size={20} style={{marginRight: '0.75rem', color: '#059669'}} />
                  <strong style={{fontSize: '1.1rem', color: '#1e293b'}}>Active Internships</strong>
                </div>
                <p style={{fontSize: '1.5rem', fontWeight: 'bold', color: '#1e293b', margin: 0}}>45</p>
              </div>
              <div className="profile-card" style={{padding: '1.5rem', backgroundColor: '#ffffff', boxShadow: '0 1px 3px rgba(0,0,0,0.1)'}}>
                <div style={{display: 'flex', alignItems: 'center', marginBottom: '0.5rem'}}>
                  <User size={20} style={{marginRight: '0.75rem', color: '#7c3aed'}} />
                  <strong style={{fontSize: '1.1rem', color: '#1e293b'}}>Enrolled Students</strong>
                </div>
                <p style={{fontSize: '1.5rem', fontWeight: 'bold', color: '#1e293b', margin: 0}}>1,200+</p>
              </div>
              <div className="profile-card" style={{padding: '1.5rem', backgroundColor: '#ffffff', boxShadow: '0 1px 3px rgba(0,0,0,0.1)'}}>
                <div style={{display: 'flex', alignItems: 'center', marginBottom: '0.5rem'}}>
                  <FileText size={20} style={{marginRight: '0.75rem', color: '#b45309'}} />
                  <strong style={{fontSize: '1.1rem', color: '#1e293b'}}>Pending Reports</strong>
                </div>
                <p style={{fontSize: '1.5rem', fontWeight: 'bold', color: '#1e293b', margin: 0}}>12</p>
              </div>
              <div className="profile-card" style={{padding: '1.5rem', backgroundColor: '#ffffff', boxShadow: '0 1px 3px rgba(0,0,0,0.1)'}}>
                <div style={{display: 'flex', alignItems: 'center', marginBottom: '0.5rem'}}>
                  <Briefcase size={20} style={{marginRight: '0.75rem', color: '#fbbf24'}} />
                  <strong style={{fontSize: '1.1rem', color: '#1e293b'}}>Completed Internship Months</strong>
                </div>
                <p style={{fontSize: '1.5rem', fontWeight: 'bold', color: '#1e293b', margin: 0}}>{getCompletedInternshipMonths()}</p>
              </div>
              <div className="profile-card" style={{padding: '1.5rem', backgroundColor: '#ffffff', boxShadow: '0 1px 3px rgba(0,0,0,0.1)'}}>
                <div style={{display: 'flex', alignItems: 'center', marginBottom: '0.5rem'}}>
                  <Briefcase size={20} style={{marginRight: '0.75rem', color: '#059669'}} />
                  <strong style={{fontSize: '1.1rem', color: '#1e293b'}}>Internships Completed</strong>
                </div>
                <p style={{fontSize: '1.5rem', fontWeight: 'bold', color: '#1e293b', margin: 0}}>{getCompletedInternshipCount()}</p>
              </div>
            </div>

            {/* Quick Actions Grid */}
            <h3 style={{fontSize: '1.25rem', color: '#1e293b', marginBottom: '1rem'}}>Quick Actions</h3>
            <div style={{
              display: 'grid',
              gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))',
              gap: '1rem'
            }}>
              {sidebarItems.filter(item => item.key !== 'dashboard').map(item => (
                <button
                  key={item.key}
                  onClick={() => setActiveSection(item.key)}
                  className="profile-card"
                  style={{
                    padding: '1.5rem',
                    backgroundColor: '#ffffff',
                    boxShadow: '0 1px 3px rgba(0,0,0,0.1)',
                    border: 'none',
                    cursor: 'pointer',
                    textAlign: 'left',
                    transition: 'transform 0.2s, box-shadow 0.2s'
                  }}
                  onMouseOver={e => {
                    e.currentTarget.style.transform = 'translateY(-2px)';
                    e.currentTarget.style.boxShadow = '0 4px 6px rgba(0,0,0,0.1)';
                  }}
                  onMouseOut={e => {
                    e.currentTarget.style.transform = 'translateY(0)';
                    e.currentTarget.style.boxShadow = '0 1px 3px rgba(0,0,0,0.1)';
                  }}
                >
                  <div style={{display: 'flex', alignItems: 'center', marginBottom: '0.5rem'}}>
                    {item.icon && <item.icon size={20} style={{marginRight: '0.75rem', color: '#fbbf24'}} />}
                    <strong style={{fontSize: '1.1rem', color: '#1e293b'}}>{item.label}</strong>
                  </div>
                  {/* Optionally, add a short description for each action here if desired */}
                </button>
              ))}
            </div>
          </div>
        );
      default:
        return null;
    }
  };

  // Add this helper to calculate total completed internship months
  const getCompletedInternshipMonths = () => {
    return pastPresentInternships
      .filter(i => i.status === 'Completed')
      .reduce((sum, i) => {
        // Try to extract the number of months from the duration string
        const match = i.duration.match(/(\d+)\s*month/);
        return sum + (match ? parseInt(match[1], 10) : 0);
      }, 0);
  };

  // Helper to count completed internships
  const getCompletedInternshipCount = () => {
    return pastPresentInternships.filter(i => i.status === 'Completed').length;
  };

  return (
    <div className={`dashboard-root${isDarkMode ? ' dark-mode' : ''}`}>
      {/* Sidebar */}
      <aside className="dashboard-sidebar" style={{ position: 'fixed', left: 0, top: 0, height: '100vh', zIndex: 200, width: 240, background: isDarkMode ? '#18181b' : '#fff', borderRight: '1.5px solid #e5e7eb', boxShadow: 'none', display: 'flex', flexDirection: 'column', alignItems: 'stretch', borderRadius: 0 }}>
        <div className="sidebar-logo" style={{ position: 'relative' }}>
          STUDENT PORTAL
          <span className="pro-ribbon">PRO</span>
        </div>
        <div className="nav-menu nav-menu-open">
          <div className="nav-menu-content">
            <button className={`nav-item ${activeSection === 'dashboard' ? 'active' : ''}`} onClick={() => setActiveSection('dashboard')}><ClipboardList size={20} /><span>Dashboard</span></button>
            <button className={`nav-item ${activeSection === 'profile' ? 'active' : ''}`} onClick={() => setActiveSection('profile')}><User size={20} /><span>Edit Profile</span></button>
            <button className={`nav-item ${activeSection === 'internships' ? 'active' : ''}`} onClick={() => setActiveSection('internships')}><Briefcase size={20} /><span>Internships</span></button>
            <button className={`nav-item ${activeSection === 'assessments' ? 'active' : ''}`} onClick={() => setActiveSection('assessments')}><ClipboardList size={20} /><span>Assessments</span></button>
            <button className={`nav-item ${activeSection === 'workshops' ? 'active' : ''}`} onClick={() => setActiveSection('workshops')}><Calendar size={20} /><span>Workshops</span></button>
            <button className={`nav-item ${activeSection === 'appointments' ? 'active' : ''}`} onClick={() => setActiveSection('appointments')}><Video size={20} /><span>Appointments</span></button>
            <div className="nav-divider"></div>
          </div>
        </div>
      </aside>

      {/* Main Area */}
      <div className="dashboard-main-area" style={{ marginLeft: 240 }}>
        {/* Animated PRO Watermark */}
        <div className="pro-watermark">PRO</div>
        {/* Top App Bar */}
        <header className="dashboard-topbar">
          <div className="topbar-title">{(() => {
            switch(activeSection) {
              case 'dashboard': return 'Dashboard';
              case 'profile': return 'Edit Profile';
              case 'suggested-companies': return 'Suggested Companies';
              case 'assessments': return 'Assessments';
              case 'workshops': return 'Workshops';
              case 'internships': return 'Internships';
              case 'appointments': return 'Appointments';
              default: return '';
            }
          })()}</div>
          <div className="topbar-actions">
            <span className="pro-badge-topbar">PRO</span>
            <button className="darkmode-toggle-btn" onClick={() => setIsDarkMode(dm => !dm)} aria-label="Toggle dark mode">
              {isDarkMode ? <Sun size={22} /> : <Moon size={22} />}
              </button>
            <button className="notification-button" onClick={() => setShowNotifications(!showNotifications)}><Bell size={24} />{notifications.some(n => !n.isRead) && (<span className="notification-badge"></span>)}</button>
            <button className="eye-button" onClick={() => setShowCompaniesModal(!showCompaniesModal)}><Eye size={24} /></button>
            <button className="logout-btn" onClick={() => {localStorage.removeItem('user'); window.location.href = '/login';}}>Logout</button>
            </div>
        </header>
        {/* Main Content */}
        <div className="dashboard-content-area">
          <main className="profile-content">{renderSection()}</main>
        </div>
        {/* Modals and overlays for notifications, companies, assessment, score, workshop */}
        {showNotifications && (
          <div className="notification-dropdown-pro">
            <div className="notification-header">
              <h3>Notifications</h3>
              <button className="mark-all-read" onClick={() => {
                  // Mark all as read logic here
                notifications.forEach(n => n.isRead = true);
                setShowNotifications(false);
              }}>Mark all as read</button>
            </div>
            <div className="notification-list">
              {notifications.map((notification) => (
                <div key={notification.id} className={`notification-item ${!notification.isRead ? 'unread' : ''}`}>
                  <div className="notification-icon"><Calendar size={20} /></div>
                  <div className="notification-content">
                    <h4>{notification.title}</h4>
                    <p>{notification.message}</p>
                    <span className="notification-time">{new Date(`${notification.date}T${notification.time}`).toLocaleString()}</span>
                  </div>
              </div>
            ))}
          </div>
        </div>
        )}
        {showCompaniesModal && (
          <div className="eye-modal-dropdown-pro">
            <div className="eye-modal-header">
              <Eye size={24} className="eye-modal-icon" />
              <h2>Companies That Viewed Your Profile</h2>
            </div>
            <ul className="eye-modal-list">
              {companyViewersList.map((company, idx) => (
                <li
                  key={company}
                  className="eye-modal-list-item"
                  draggable
                  onDragStart={() => handleDragStart(idx)}
                  onDragOver={handleDragOver}
                  onDrop={() => handleDrop(idx)}
                  style={{
                    opacity: draggedIndex === idx ? 0.5 : 1,
                    transform: draggedIndex === idx ? 'scale(0.98)' : 'scale(1)',
                    transition: 'all 0.2s ease'
                  }}
                >
                  <span className="eye-modal-drag">↕️</span>
                  <span className="eye-modal-company">{company}</span>
                </li>
              ))}
            </ul>
          </div>
        )}
      {/* Assessment Modal */}
      {showAssessmentModal && currentAssessment && (
        <div className="modal-overlay">
          <div className="modal-content assessment-modal">
            <div className="modal-header">
              <h3>{currentAssessment.title}</h3>
              <div className="timer">
                Time Remaining: {Math.floor(timeRemaining / 60)}:{(timeRemaining % 60).toString().padStart(2, '0')}
              </div>
            </div>
            <div className="progress-bar">
                <div className="progress-fill" style={{ width: `${((currentQuestionIndex + 1) / currentAssessment.questions.length) * 100}%` }}></div>
            </div>
            <div className="question-container">
              <h4>Question {currentQuestionIndex + 1} of {currentAssessment.questions.length}</h4>
              <p className="question-text">{currentAssessment.questions[currentQuestionIndex].question}</p>
              <div className="options-container">
                {currentAssessment.questions[currentQuestionIndex].options.map((option, index) => (
                  <label key={index} className="option-label">
                    <input
                      type="radio"
                      name={`question-${currentAssessment.questions[currentQuestionIndex].id}`}
                      value={option}
                      checked={assessmentAnswers[currentAssessment.questions[currentQuestionIndex].id] === option}
                      onChange={() => handleAnswerSelect(currentAssessment.questions[currentQuestionIndex].id, option)}
                      className="form-radio"
                    />
                    <span className="option-text">{option}</span>
                  </label>
                ))}
              </div>
            </div>
            <div className="modal-footer">
                <button className="btn btn-secondary" onClick={handlePreviousQuestion} disabled={currentQuestionIndex === 0}>Previous</button>
              {currentQuestionIndex === currentAssessment.questions.length - 1 ? (
                  <button className="btn btn-yellow" onClick={handleSubmitAssessment}>Submit Assessment</button>
              ) : (
                  <button className="btn btn-yellow" onClick={handleNextQuestion}>Next</button>
              )}
            </div>
          </div>
        </div>
      )}
      {/* Score Modal */}
      {showScoreModal && selectedScore && (
        <div className="modal-overlay">
          <div className="modal-content score-modal">
            <div className="modal-header">
              <h3>Assessment Results</h3>
              <button className="modal-close" onClick={() => setShowScoreModal(false)}>×</button>
            </div>
              <div className="score-display">{selectedScore.score}%</div>
            <div className="score-details">
              <p>Correct Answers: {selectedScore.correctAnswers} out of {selectedScore.totalQuestions}</p>
              <p>Assessment: {selectedScore.title}</p>
              <p>Date: {selectedScore.date}</p>
            </div>
            <div className="modal-footer">
                <button className="btn btn-yellow" onClick={() => setShowScoreModal(false)}>Close</button>
            </div>
          </div>
        </div>
      )}
      {/* Workshop Registration Modal */}
      {showWorkshopModal && selectedWorkshop && (
        <div className="modal-overlay">
          <div className="modal-content">
            <div className="modal-header">
              <h3>Register for Workshop</h3>
                <button className="modal-close" onClick={() => { setShowWorkshopModal(false); setSelectedWorkshop(null); }}>×</button>
            </div>
            <div className="workshop-registration-form">
              <p>You are about to register for: <strong>{selectedWorkshop.title}</strong></p>
              <p>Date: {selectedWorkshop.date}</p>
              <p>Time: {selectedWorkshop.time}</p>
              <p>Speaker: {selectedWorkshop.speaker}</p>
              <div className="modal-footer">
                  <button className="btn btn-secondary" onClick={() => { setShowWorkshopModal(false); setSelectedWorkshop(null); }}>Cancel</button>
                  <button className="btn btn-yellow" onClick={() => {
                    // Update workshop status
                    const updatedWorkshops = workshops.map(w => w.id === selectedWorkshop.id ? { ...w, status: 'registered' } : w);
                    setWorkshops(updatedWorkshops);
                    // Show success message
                    showToast({ title: 'Registration Successful', message: `You have been registered for ${selectedWorkshop.title}` });
                    // Close modal
                    setShowWorkshopModal(false);
                    setSelectedWorkshop(null);
                  }}>Confirm Registration</button>
              </div>
            </div>
          </div>
        </div>
      )}
      </div>
    </div>
  );
};

export default StudentProfile;
