import React, { useState } from 'react';
import {
  Box,
  Grid,
  Typography,
  Card,
  CardContent,
  LinearProgress,
  Button,
  CircularProgress,
  useTheme,
} from '@mui/material';
import {
  Description as DescriptionIcon,
  CheckCircle as CheckCircleIcon,
  Flag as FlagIcon,
  Assessment as AssessmentIcon,
  GetApp as DownloadIcon,
} from '@mui/icons-material';

const FacultyStatistics = () => {
  const theme = useTheme();
  const [isGenerating, setIsGenerating] = useState(false);
  const [statistics, setStatistics] = useState({
    totalReports: 150,
    accepted: 95,
    flaggedRejected: 35,
    averageReviewTime: '2.5 days'
  });

  const topCompanies = [
    { name: 'Tech Solutions Inc.', rating: 4.8, progress: 96 },
    { name: 'Global Marketing Group', rating: 4.6, progress: 92 },
    { name: 'Tech Corp', rating: 4.5, progress: 90 },
    { name: 'FinTech Solutions', rating: 4.4, progress: 88 },
    { name: 'AI Research Lab', rating: 4.3, progress: 86 }
  ];

  const handleGenerateReport = async () => {
    setIsGenerating(true);
    try {
      // Simulate API call to get real-time statistics
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      // Update statistics with "real-time" data
      setStatistics({
        totalReports: Math.floor(Math.random() * 50) + 150,
        accepted: Math.floor(Math.random() * 30) + 90,
        flaggedRejected: Math.floor(Math.random() * 20) + 30,
        averageReviewTime: `${(Math.random() * 2 + 1.5).toFixed(1)} days`
      });
    } catch (error) {
      console.error('Error generating report:', error);
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <Box sx={{ width: '100%', p: 3 }}>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 4 }}>
        <Typography variant="h5" sx={{ fontWeight: 500, color: 'text.primary' }}>
          Statistics Overview
        </Typography>
        <Button
          variant="contained"
          startIcon={isGenerating ? <CircularProgress size={20} color="inherit" /> : <DownloadIcon />}
          onClick={handleGenerateReport}
          disabled={isGenerating}
          sx={{
            bgcolor: 'primary.main',
            color: theme => theme.palette.mode === 'dark' ? '#000000' : '#000000',
            '&:hover': {
              bgcolor: 'primary.dark',
            },
            '& .MuiCircularProgress-root': {
              color: '#000000'
            }
          }}
        >
          {isGenerating ? 'Generating...' : 'Generate Report'}
        </Button>
      </Box>

      <Grid container direction="row" spacing={3} sx={{ mb: 4 }}>
        <Grid item className="MuiGrid-direction-xs-row">
          <Card sx={{ 
            boxShadow: '0px 2px 1px -1px rgba(0,0,0,0.2),0px 1px 1px 0px rgba(0,0,0,0.14),0px 1px 3px 0px rgba(0,0,0,0.12)',
            minWidth: 200
          }}>
            <CardContent sx={{ p: 2 }}>
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                <DescriptionIcon color="primary" />
                <Typography variant="h6" sx={{ fontWeight: 500 }}>{statistics.totalReports}</Typography>
              </Box>
              <Typography variant="body2" sx={{ mt: 1, color: 'text.secondary' }}>Total Reports</Typography>
            </CardContent>
          </Card>
        </Grid>

        <Grid item className="MuiGrid-direction-xs-row">
          <Card sx={{ 
            boxShadow: '0px 2px 1px -1px rgba(0,0,0,0.2),0px 1px 1px 0px rgba(0,0,0,0.14),0px 1px 3px 0px rgba(0,0,0,0.12)',
            minWidth: 200
          }}>
            <CardContent sx={{ p: 2 }}>
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                <CheckCircleIcon color="success" />
                <Typography variant="h6" sx={{ fontWeight: 500 }}>{statistics.accepted}</Typography>
              </Box>
              <Typography variant="body2" sx={{ mt: 1, color: 'text.secondary' }}>Accepted</Typography>
            </CardContent>
          </Card>
        </Grid>

        <Grid item className="MuiGrid-direction-xs-row">
          <Card sx={{ 
            boxShadow: '0px 2px 1px -1px rgba(0,0,0,0.2),0px 1px 1px 0px rgba(0,0,0,0.14),0px 1px 3px 0px rgba(0,0,0,0.12)',
            minWidth: 200
          }}>
            <CardContent sx={{ p: 2 }}>
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                <FlagIcon color="error" />
                <Typography variant="h6" sx={{ fontWeight: 500 }}>{statistics.flaggedRejected}</Typography>
              </Box>
              <Typography variant="body2" sx={{ mt: 1, color: 'text.secondary' }}>Flagged/Rejected</Typography>
            </CardContent>
          </Card>
        </Grid>

        <Grid item className="MuiGrid-direction-xs-row">
          <Card sx={{ 
            boxShadow: '0px 2px 1px -1px rgba(0,0,0,0.2),0px 1px 1px 0px rgba(0,0,0,0.14),0px 1px 3px 0px rgba(0,0,0,0.12)',
            minWidth: 200
          }}>
            <CardContent sx={{ p: 2 }}>
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                <AssessmentIcon color="primary" />
                <Typography variant="h6" sx={{ fontWeight: 500 }}>{statistics.averageReviewTime}</Typography>
              </Box>
              <Typography variant="body2" sx={{ mt: 1, color: 'text.secondary' }}>Average Review Time</Typography>
            </CardContent>
          </Card>
        </Grid>
      </Grid>

      <Typography variant="h6" gutterBottom sx={{ mb: 3, fontWeight: 500 }}>
        Top Rated Companies
      </Typography>

      <Grid container direction="row" spacing={3}>
        {topCompanies.map((company, index) => (
          <Grid item key={index} className="MuiGrid-direction-xs-row">
            <Card sx={{ 
              boxShadow: '0px 2px 1px -1px rgba(0,0,0,0.2),0px 1px 1px 0px rgba(0,0,0,0.14),0px 1px 3px 0px rgba(0,0,0,0.12)',
              minWidth: 200
            }}>
              <CardContent sx={{ p: 2 }}>
                <Typography variant="h6" gutterBottom sx={{ fontWeight: 500 }}>
                  {company.name}
                </Typography>
                <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 1 }}>
                  <Typography variant="body1" sx={{ color: 'text.secondary' }}>Rating:</Typography>
                  <Typography variant="h6" sx={{ fontWeight: 500 }}>{company.rating}</Typography>
                </Box>
                <LinearProgress
                  variant="determinate"
                  value={company.progress}
                  sx={{
                    height: 6,
                    borderRadius: 3,
                    bgcolor: theme.palette.mode === 'dark' ? 'rgba(255, 255, 255, 0.1)' : 'rgba(0, 0, 0, 0.1)',
                    '& .MuiLinearProgress-bar': {
                      borderRadius: 3,
                      bgcolor: 'primary.main'
                    }
                  }}
                />
              </CardContent>
            </Card>
          </Grid>
        ))}
      </Grid>
    </Box>
  );
};

export default FacultyStatistics; 