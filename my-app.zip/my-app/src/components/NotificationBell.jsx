import { useState } from 'react';
import {
  IconButton,
  Badge,
  Popover,
  List,
  ListItem,
  ListItemText,
  Typography,
  Box,
  Divider,
  ListItemIcon,
} from '@mui/material';
import {
  Notifications as NotificationsIcon,
  Business as BusinessIcon,
  Description as DescriptionIcon,
  Event as EventIcon,
  VideoCall as VideoCallIcon,
  CalendarMonth as CalendarMonthIcon,
} from '@mui/icons-material';

// Dummy notifications data
const dummyNotifications = [
  {
    id: 1,
    type: 'report',
    message: 'New internship report submitted by John Doe (Computer Science)',
    timestamp: '2024-03-20T10:30:00',
    read: false,
    icon: <DescriptionIcon color="primary" />,
  },
  {
    id: 2,
    type: 'report',
    message: 'Urgent: Report from Maria Garcia needs review (Flagged)',
    timestamp: '2024-03-20T09:15:00',
    read: false,
    icon: <DescriptionIcon sx={{ color: '#FFB800' }} />,
  },
  {
    id: 3,
    type: 'deadline',
    message: 'Reminder: 5 pending reports awaiting your review',
    timestamp: '2024-03-19T16:45:00',
    read: true,
    icon: <CalendarMonthIcon sx={{ color: '#f44336' }} />,
  },
  {
    id: 4,
    type: 'report',
    message: 'Report status updated: Sarah Thompson (Accepted)',
    timestamp: '2024-03-19T14:20:00',
    read: true,
    icon: <DescriptionIcon sx={{ color: '#4CAF50' }} />,
  },
  {
    id: 5,
    type: 'report',
    message: 'Report feedback required: Mohammed Ahmed (Engineering)',
    timestamp: '2024-03-19T11:00:00',
    read: true,
    icon: <DescriptionIcon color="primary" />,
  },
];

function NotificationBell() {
  const [anchorEl, setAnchorEl] = useState(null);
  const [notifications, setNotifications] = useState(dummyNotifications);

  const unreadCount = notifications.filter(notif => !notif.read).length;

  const handleClick = (event) => {
    setAnchorEl(event.currentTarget);
    // Mark all as read when opening
    setNotifications(notifications.map(notif => ({ ...notif, read: true })));
  };

  const handleClose = () => {
    setAnchorEl(null);
  };

  const open = Boolean(anchorEl);

  const formatTimestamp = (timestamp) => {
    const date = new Date(timestamp);
    const now = new Date();
    const diffInHours = Math.floor((now - date) / (1000 * 60 * 60));

    if (diffInHours < 24) {
      if (diffInHours < 1) {
        const diffInMinutes = Math.floor((now - date) / (1000 * 60));
        return `${diffInMinutes} minutes ago`;
      }
      return `${diffInHours} hours ago`;
    }
    return date.toLocaleDateString();
  };

  return (
    <>
      <IconButton
        color="inherit"
        onClick={handleClick}
        sx={{
          transition: 'transform 0.2s',
          '&:hover': {
            transform: 'scale(1.1)',
          },
        }}
      >
        <Badge badgeContent={unreadCount} color="error">
          <NotificationsIcon />
        </Badge>
      </IconButton>
      <Popover
        open={open}
        anchorEl={anchorEl}
        onClose={handleClose}
        anchorOrigin={{
          vertical: 'bottom',
          horizontal: 'right',
        }}
        transformOrigin={{
          vertical: 'top',
          horizontal: 'right',
        }}
        PaperProps={{
          sx: {
            width: 360,
            maxHeight: 480,
            backgroundImage: 'none',
          },
        }}
      >
        <Box sx={{ p: 2, bgcolor: 'background.paper' }}>
          <Typography variant="h6" gutterBottom>
            Notifications
          </Typography>
          {unreadCount === 0 && (
            <Typography color="text.secondary" variant="body2">
              No new notifications
            </Typography>
          )}
        </Box>
        <Divider />
        <List sx={{ p: 0 }}>
          {notifications.map((notification, index) => (
            <Box key={notification.id}>
              <ListItem
                sx={{
                  bgcolor: notification.read ? 'inherit' : 'action.hover',
                  '&:hover': {
                    bgcolor: 'action.hover',
                  },
                }}
              >
                <ListItemIcon>
                  {notification.icon}
                </ListItemIcon>
                <ListItemText
                  primary={notification.message}
                  secondary={formatTimestamp(notification.timestamp)}
                  primaryTypographyProps={{
                    variant: 'body2',
                    color: notification.read ? 'text.primary' : 'primary',
                  }}
                  secondaryTypographyProps={{
                    variant: 'caption',
                  }}
                />
              </ListItem>
              {index < notifications.length - 1 && <Divider />}
            </Box>
          ))}
        </List>
      </Popover>
    </>
  );
}

export default NotificationBell; 