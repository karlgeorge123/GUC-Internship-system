import React, { useState } from 'react';
import {
  Box,
  Grid,
  Paper,
  Typography,
  Button,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Snackbar,
  Alert,
  useTheme,
} from '@mui/material';
import {
  CheckCircle as CheckCircleIcon,
  Flag as FlagIcon,
  Cancel as CancelIcon,
  Download as DownloadIcon,
} from '@mui/icons-material';

const dummyReports = [
  {
    id: 1,
    studentName: 'John Doe',
    studentId: '2020-12345',
    major: 'Computer Science',
    submissionDate: '2024-03-20',
    status: 'pending',
  },
  {
    id: 2,
    studentName: 'Jane Smith',
    studentId: '2020-12346',
    major: 'Engineering',
    submissionDate: '2024-03-19',
    status: 'accepted',
  },
  {
    id: 3,
    studentName: 'Alex Johnson',
    studentId: '2020-12347',
    major: 'Business',
    submissionDate: '2024-03-18',
    status: 'pending',
  },
  {
    id: 4,
    studentName: 'Maria Garcia',
    studentId: '2020-12348',
    major: 'Computer Science',
    submissionDate: '2024-03-17',
    status: 'flagged',
  },
  {
    id: 5,
    studentName: 'Mohammed Ahmed',
    studentId: '2020-12349',
    major: 'Engineering',
    submissionDate: '2024-03-16',
    status: 'rejected',
  },
  {
    id: 6,
    studentName: 'Sarah Thompson',
    studentId: '2020-12350',
    major: 'Business',
    submissionDate: '2024-03-15',
    status: 'accepted',
  },
  {
    id: 7,
    studentName: 'David Wilson',
    studentId: '2020-12351',
    major: 'Computer Science',
    submissionDate: '2024-03-14',
    status: 'pending',
  },
  {
    id: 8,
    studentName: 'Emily Brown',
    studentId: '2020-12352',
    major: 'Engineering',
    submissionDate: '2024-03-13',
    status: 'accepted',
  },
];

const FacultyReports = () => {
  const theme = useTheme();
  const [reports, setReports] = useState(dummyReports);
  const [selectedMajor, setSelectedMajor] = useState('all');
  const [selectedStatus, setSelectedStatus] = useState('all');
  const [snackbar, setSnackbar] = useState({
    open: false,
    message: '',
    severity: 'success',
  });

  const handleStatusChange = async (reportId, newStatus) => {
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 500));
      
      setReports(reports.map(report => 
        report.id === reportId ? { ...report, status: newStatus } : report
      ));

      setSnackbar({
        open: true,
        message: `Report ${newStatus} successfully`,
        severity: 'success',
      });
    } catch (error) {
      setSnackbar({
        open: true,
        message: `Error updating report status: ${error.message}`,
        severity: 'error',
      });
    }
  };

  const handleDownload = async (reportId) => {
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 500));
      
      setSnackbar({
        open: true,
        message: 'Downloading report...',
        severity: 'info',
      });
    } catch (error) {
      setSnackbar({
        open: true,
        message: `Error downloading report: ${error.message}`,
        severity: 'error',
      });
    }
  };

  const handleCloseSnackbar = () => {
    setSnackbar({ ...snackbar, open: false });
  };

  const filteredReports = reports.filter(report => {
    const matchesMajor = selectedMajor === 'all' || report.major === selectedMajor;
    const matchesStatus = selectedStatus === 'all' || report.status === selectedStatus;
    return matchesMajor && matchesStatus;
  });

  return (
    <Box sx={{ p: 3 }}>
      <Grid container spacing={2} direction="row" sx={{ mb: 4 }}>
        <Grid item xs={12} sm={6} className="MuiGrid-direction-xs-row">
          <FormControl fullWidth>
            <InputLabel 
              sx={{
                bgcolor: 'background.paper',
                px: 0.5,
                '&.Mui-focused': {
                  color: 'primary.main',
                },
              }}
            >
              Filter by Major
            </InputLabel>
            <Select
              value={selectedMajor}
              label="Filter by Major"
              onChange={(e) => setSelectedMajor(e.target.value)}
              sx={{
                bgcolor: 'background.paper',
                backgroundImage: 'none',
                '& .MuiOutlinedInput-notchedOutline': {
                  borderColor: 'primary.main',
                },
                '&:hover .MuiOutlinedInput-notchedOutline': {
                  borderColor: 'primary.dark',
                },
                '&.Mui-focused .MuiOutlinedInput-notchedOutline': {
                  borderColor: 'primary.main',
                },
                '& .MuiSelect-select': {
                  bgcolor: 'background.paper',
                },
              }}
            >
              <MenuItem value="all">All Majors</MenuItem>
              <MenuItem value="Computer Science">Computer Science</MenuItem>
              <MenuItem value="Engineering">Engineering</MenuItem>
              <MenuItem value="Business">Business</MenuItem>
            </Select>
          </FormControl>
        </Grid>
        <Grid item xs={12} sm={6} className="MuiGrid-direction-xs-row">
          <FormControl fullWidth>
            <InputLabel 
              sx={{
                bgcolor: 'background.paper',
                px: 0.5,
                '&.Mui-focused': {
                  color: 'primary.main',
                },
              }}
            >
              Filter by Status
            </InputLabel>
            <Select
              value={selectedStatus}
              label="Filter by Status"
              onChange={(e) => setSelectedStatus(e.target.value)}
              sx={{
                bgcolor: 'background.paper',
                backgroundImage: 'none',
                '& .MuiOutlinedInput-notchedOutline': {
                  borderColor: 'primary.main',
                },
                '&:hover .MuiOutlinedInput-notchedOutline': {
                  borderColor: 'primary.dark',
                },
                '&.Mui-focused .MuiOutlinedInput-notchedOutline': {
                  borderColor: 'primary.main',
                },
                '& .MuiSelect-select': {
                  bgcolor: 'background.paper',
                },
              }}
            >
              <MenuItem value="all">All Status</MenuItem>
              <MenuItem value="pending">Pending</MenuItem>
              <MenuItem value="accepted">Accepted</MenuItem>
              <MenuItem value="rejected">Rejected</MenuItem>
              <MenuItem value="flagged">Flagged</MenuItem>
            </Select>
          </FormControl>
        </Grid>
      </Grid>

      <Paper 
        elevation={1} 
        sx={{
          bgcolor: 'background.paper',
          backgroundImage: 'none',
          borderRadius: 2,
          overflow: 'hidden',
        }}
      >
        <Box sx={{ p: 3 }}>
          <Typography 
            variant="h6" 
            gutterBottom 
            sx={{ 
              color: 'text.primary',
              fontWeight: 600,
            }}
          >
            Internship Reports ({filteredReports.length})
          </Typography>
        </Box>

        {filteredReports.map((report, index) => (
          <Box
            key={report.id}
            sx={{
              p: 3,
              borderTop: '1px solid',
              borderColor: 'divider',
              bgcolor: theme => {
                if (theme.palette.mode === 'dark') {
                  return index % 2 === 0 ? 'rgba(255, 255, 255, 0.05)' : 'background.paper';
                } else {
                  return index % 2 === 0 ? '#f8f8f8' : '#ffffff';
                }
              },
              transition: 'background-color 0.3s ease',
              '&:hover': {
                bgcolor: theme => theme.palette.mode === 'dark' ? 'rgba(255, 255, 255, 0.1)' : '#f0f0f0',
              },
            }}
          >
            <Grid container spacing={2}>
              <Grid item xs={12} sm={6}>
                <Typography variant="subtitle1" sx={{ fontWeight: 500 }}>
                  Student: {report.studentName}
                </Typography>
                <Typography variant="body2" color="text.secondary" sx={{ mt: 1 }}>
                  Major: {report.major}
                </Typography>
                <Typography variant="body2" color="text.secondary">
                  Submitted: {report.submissionDate}
                </Typography>
                <Typography
                  variant="body2"
                  sx={{
                    mt: 1,
                    color: theme => {
                      if (theme.palette.mode === 'dark') {
                        return report.status === 'accepted'
                          ? '#81c784'
                          : report.status === 'rejected'
                          ? '#e57373'
                          : report.status === 'flagged'
                          ? '#FFD54F'
                          : '#b0b0b0';
                      } else {
                        return report.status === 'accepted'
                          ? '#4CAF50'
                          : report.status === 'rejected'
                          ? '#f44336'
                          : report.status === 'flagged'
                          ? '#FFB800'
                          : '#757575';
                      }
                    },
                    fontWeight: 500,
                  }}
                >
                  Status: {report.status.charAt(0).toUpperCase() + report.status.slice(1)}
                </Typography>
              </Grid>
              <Grid item xs={12} sm={6}>
                <Box
                  sx={{
                    display: 'flex',
                    gap: 1,
                    flexWrap: 'wrap',
                    justifyContent: { xs: 'flex-start', sm: 'flex-end' },
                    mt: { xs: 2, sm: 0 },
                  }}
                >
                  {report.status === 'pending' && (
                    <>
                      <Button
                        variant="contained"
                        startIcon={<CheckCircleIcon />}
                        onClick={() => handleStatusChange(report.id, 'accepted')}
                        sx={{
                          bgcolor: theme => theme.palette.mode === 'dark' ? '#2e7d32' : '#4CAF50',
                          '&:hover': {
                            bgcolor: theme => theme.palette.mode === 'dark' ? '#1b5e20' : '#388E3C',
                          },
                        }}
                      >
                        Accept
                      </Button>
                      <Button
                        variant="contained"
                        startIcon={<FlagIcon />}
                        onClick={() => handleStatusChange(report.id, 'flagged')}
                        sx={{
                          bgcolor: theme => theme.palette.mode === 'dark' ? '#f9a825' : '#FFB800',
                          color: '#000000',
                          '&:hover': {
                            bgcolor: theme => theme.palette.mode === 'dark' ? '#f57f17' : '#FFA000',
                          },
                        }}
                      >
                        Flag
                      </Button>
                      <Button
                        variant="contained"
                        startIcon={<CancelIcon />}
                        onClick={() => handleStatusChange(report.id, 'rejected')}
                        sx={{
                          bgcolor: theme => theme.palette.mode === 'dark' ? '#c62828' : '#f44336',
                          '&:hover': {
                            bgcolor: theme => theme.palette.mode === 'dark' ? '#b71c1c' : '#d32f2f',
                          },
                        }}
                      >
                        Reject
                      </Button>
                    </>
                  )}
                  <Button
                    variant="outlined"
                    startIcon={<DownloadIcon />}
                    onClick={() => handleDownload(report.id)}
                    sx={{
                      borderColor: 'primary.main',
                      color: theme => theme.palette.mode === 'dark' ? 'primary.main' : '#000000',
                      '&:hover': {
                        borderColor: 'primary.dark',
                        bgcolor: 'action.hover',
                      },
                    }}
                  >
                    Download PDF
                  </Button>
                </Box>
              </Grid>
            </Grid>
          </Box>
        ))}
      </Paper>

      <Snackbar
        open={snackbar.open}
        autoHideDuration={6000}
        onClose={handleCloseSnackbar}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}
      >
        <Alert
          onClose={handleCloseSnackbar}
          severity={snackbar.severity}
          variant="filled"
          sx={{ width: '100%' }}
        >
          {snackbar.message}
        </Alert>
      </Snackbar>
    </Box>
  );
};

export default FacultyReports; 