
import React from 'react';
import {
  Box,
  Container,
  Grid,
  Paper,
  Typography,
} from '@mui/material';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  PieChart,
  Pie,
  Cell,
} from 'recharts';

const COLORS = ['#4CAF50', '#f44336', '#FFB800', '#90caf9'];

const Statistics = () => {
  // Dummy data for demonstration
  const statistics = {
    totalReports: 50,
    accepted: 30,
    rejected: 10,
    flagged: 5,
  };

  const pieData = [
    { name: 'Accepted', value: statistics.accepted },
    { name: 'Rejected', value: statistics.rejected },
    { name: 'Flagged', value: statistics.flagged },
    { name: 'Pending', value: statistics.totalReports - (statistics.accepted + statistics.rejected + statistics.flagged) },
  ];

  const barData = [
    { name: 'Computer Science', accepted: 15, rejected: 5, flagged: 3 },
    { name: 'Engineering', accepted: 12, rejected: 3, flagged: 2 },
    { name: 'Business', accepted: 8, rejected: 4, flagged: 1 },
  ];

  return (

    <Container maxWidth="lg" sx={{ mt: 4, mb: 4 }}>
      <Paper sx={{ p: 3, mb: 3 }}>
        <Typography variant="h5" gutterBottom sx={{ color: '#1976d2', fontWeight: 'medium', mb: 3 }}>
          Statistics Overview
        </Typography>
        
        <Grid container spacing={4}>
          {/* Statistics Summary */}
          <Grid item xs={12}>
            <Box sx={{ 
              display: 'flex', 
              justifyContent: 'space-around', 
              p: 2, 
              backgroundColor: '#f5f5f5',
              borderRadius: 1
            }}>
              <Box sx={{ textAlign: 'center' }}>
                <Typography variant="h4">{statistics.totalReports}</Typography>
                <Typography color="textSecondary">Total Reports</Typography>
              </Box>
              <Box sx={{ textAlign: 'center' }}>
                <Typography variant="h4" sx={{ color: '#4CAF50' }}>{statistics.accepted}</Typography>
                <Typography color="textSecondary">Accepted</Typography>
              </Box>
              <Box sx={{ textAlign: 'center' }}>
                <Typography variant="h4" sx={{ color: '#f44336' }}>{statistics.rejected}</Typography>
                <Typography color="textSecondary">Rejected</Typography>
              </Box>
              <Box sx={{ textAlign: 'center' }}>
                <Typography variant="h4" sx={{ color: '#FFB800' }}>{statistics.flagged}</Typography>
                <Typography color="textSecondary">Flagged</Typography>
              </Box>
            </Box>
          </Grid>

          {/* Charts */}
          <Grid item xs={12} md={6}>
            <Paper elevation={0} sx={{ p: 2, backgroundColor: '#f5f5f5' }}>
              <Typography variant="h6" gutterBottom sx={{ color: '#1976d2' }}>
                Report Status Distribution
              </Typography>
              <Box sx={{ height: 300, display: 'flex', justifyContent: 'center' }}>
                <PieChart width={400} height={300}>
                  <Pie
                    data={pieData}
                    cx={200}
                    cy={150}
                    innerRadius={60}
                    outerRadius={90}
                    fill="#8884d8"
                    paddingAngle={5}
                    dataKey="value"
                  >
                    {pieData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip />
                  <Legend />
                </PieChart>
              </Box>
            </Paper>
          </Grid>

          <Grid item xs={12} md={6}>
            <Paper elevation={0} sx={{ p: 2, backgroundColor: '#f5f5f5' }}>
              <Typography variant="h6" gutterBottom sx={{ color: '#1976d2' }}>
                Reports by Major
              </Typography>
              <Box sx={{ height: 300, display: 'flex', justifyContent: 'center' }}>
                <BarChart
                  width={400}
                  height={300}
                  data={barData}
                  margin={{
                    top: 20,
                    right: 30,
                    left: 20,
                    bottom: 5,
                  }}
                >
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  <Bar dataKey="accepted" fill={COLORS[0]} />
                  <Bar dataKey="rejected" fill={COLORS[1]} />
                  <Bar dataKey="flagged" fill={COLORS[2]} />
                </BarChart>
              </Box>
            </Paper>
          </Grid>
        </Grid>
      </Paper>
    </Container>
  );
};

export default Statistics; 