import { useState } from 'react';
import './Dashboard.css';

const InternshipReports = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [filters, setFilters] = useState({
    major: 'all',
    status: 'all',
  });

  // Dummy data
  const reports = [
    {
      id: 1,
      studentName: 'Ahmed Mohamed',
      major: 'Computer Science',
      title: 'Software Development Internship Report',
      status: 'Pending Review',
      submissionDate: '2024-03-15',
      company: 'Tech Solutions Inc.',
    },
    {
      id: 2,
      studentName: 'Sarah Ahmed',
      major: 'Business Administration',
      title: 'Financial Analysis Internship Report',
      status: 'Approved',
      submissionDate: '2024-03-10',
      company: 'Global Finance Ltd.',
    },
    {
      id: 3,
      studentName: 'Mohamed Ali',
      major: 'Engineering',
      title: 'Engineering Internship Report',
      status: 'Needs Revision',
      submissionDate: '2024-03-12',
      company: 'Healthcare Plus',
    },
  ];

  const majors = ['all', 'Computer Science', 'Business Administration', 'Engineering', 'Marketing'];
  const statuses = ['all', 'Pending Review', 'Approved', 'Needs Revision', 'Rejected'];

  const filteredReports = reports.filter(report => {
    const matchesSearch = 
      report.studentName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      report.title.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesMajor = filters.major === 'all' || report.major === filters.major;
    const matchesStatus = filters.status === 'all' || report.status === filters.status;
    return matchesSearch && matchesMajor && matchesStatus;
  });

  const handleStatusChange = (reportId, newStatus) => {
    // In a real application, this would make an API call
    console.log(`Changing status of report ${reportId} to ${newStatus}`);
  };

  return (
    <div className="dashboard-container">
      <div className="section-card p-6 !w-[1000px] !h-[800px] !max-w-[1000px] overflow-auto" style={{ marginLeft: '300px' }}>
        <div className="pl-8">
          <div>
            <h1 className="text-2xl font-semibold text-gray-900">Internship Reports</h1>
            <p className="mt-1 text-sm text-gray-500">
              Review and manage student internship reports.
            </p>
          </div>

          {/* Filters */}
          <div className="flex flex-col sm:flex-row gap-4 mt-6">
            <div className="flex-1">
              <input
                type="text"
                className="block w-full rounded-md border-0 py-1.5 px-3 text-gray-900 ring-1 ring-inset ring-gray-300 placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-[#FFD700] sm:text-sm sm:leading-6"
                placeholder="Search by student name or report title..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            <div className="sm:w-48">
              <select
                className="block w-full rounded-md border-0 py-1.5 pl-3 pr-10 text-gray-900 ring-1 ring-inset ring-gray-300 focus:ring-2 focus:ring-[#FFD700] sm:text-sm sm:leading-6"
                value={filters.major}
                onChange={(e) => setFilters(prev => ({ ...prev, major: e.target.value }))}
              >
                {majors.map((major) => (
                  <option key={major} value={major}>
                    {major.charAt(0).toUpperCase() + major.slice(1)}
                  </option>
                ))}
              </select>
            </div>
            <div className="sm:w-48">
              <select
                className="block w-full rounded-md border-0 py-1.5 pl-3 pr-10 text-gray-900 ring-1 ring-inset ring-gray-300 focus:ring-2 focus:ring-[#FFD700] sm:text-sm sm:leading-6"
                value={filters.status}
                onChange={(e) => setFilters(prev => ({ ...prev, status: e.target.value }))}
              >
                {statuses.map((status) => (
                  <option key={status} value={status}>
                    {status.charAt(0).toUpperCase() + status.slice(1)}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Table */}
          <div className="mt-8 flow-root">
            <div className="-mx-4 -my-2 overflow-x-auto sm:-mx-6 lg:-mx-8">
              <div className="inline-block w-full py-2 align-middle">
                <div className="overflow-hidden shadow-sm ring-1 ring-black ring-opacity-5 rounded-lg w-full">
                  <table className="w-full divide-y divide-gray-300">
                    <thead className="bg-gray-50">
                      <tr>
                        <th scope="col" className="py-3.5 pl-4 pr-3 text-left text-sm font-semibold text-gray-900">
                          Student
                        </th>
                        <th scope="col" className="px-3 py-3.5 text-left text-sm font-semibold text-gray-900">
                          Major
                        </th>
                        <th scope="col" className="px-3 py-3.5 text-left text-sm font-semibold text-gray-900">
                          Report Title
                        </th>
                        <th scope="col" className="px-3 py-3.5 text-left text-sm font-semibold text-gray-900">
                          Company
                        </th>
                        <th scope="col" className="px-3 py-3.5 text-left text-sm font-semibold text-gray-900">
                          Status
                        </th>
                        <th scope="col" className="px-3 py-3.5 text-left text-sm font-semibold text-gray-900">
                          Submission Date
                        </th>
                        <th scope="col" className="relative py-3.5 pl-3 pr-4">
                          <span className="sr-only">Actions</span>
                        </th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-200 bg-white">
                      {filteredReports.map((report) => (
                        <tr key={report.id} className="hover:bg-gray-50 transition-colors duration-200">
                          <td className="whitespace-nowrap py-4 pl-4 pr-3 text-sm font-medium text-gray-900">
                            {report.studentName}
                          </td>
                          <td className="whitespace-nowrap px-3 py-4 text-sm text-gray-500">
                            {report.major}
                          </td>
                          <td className="whitespace-nowrap px-3 py-4 text-sm text-gray-500">
                            {report.title}
                          </td>
                          <td className="whitespace-nowrap px-3 py-4 text-sm text-gray-500">
                            {report.company}
                          </td>
                          <td className="whitespace-nowrap px-3 py-4 text-sm text-gray-500">
                            <span
                              className={`inline-flex rounded-full px-2 text-xs font-semibold leading-5 ${
                                report.status === 'Approved'
                                  ? 'bg-green-100 text-green-800'
                                  : report.status === 'Rejected'
                                  ? 'bg-red-100 text-red-800'
                                  : report.status === 'Needs Revision'
                                  ? 'bg-yellow-100 text-yellow-800'
                                  : 'bg-blue-100 text-blue-800'
                              }`}
                            >
                              {report.status}
                            </span>
                          </td>
                          <td className="whitespace-nowrap px-3 py-4 text-sm text-gray-500">
                            {report.submissionDate}
                          </td>
                          <td className="relative whitespace-nowrap py-4 pl-3 pr-4 text-right text-sm font-medium">
                            <button
                              className="text-[#FFD700] hover:text-yellow-600 transition-colors duration-200"
                              onClick={() => console.log(`View report ${report.id}`)}
                            >
                              View Report
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default InternshipReports; 