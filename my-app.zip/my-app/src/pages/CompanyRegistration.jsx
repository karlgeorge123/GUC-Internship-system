import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import '../styles/companyRegistration.css';

const CompanyRegistration = () => {
  const navigate = useNavigate();
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState({
    companyName: '',
    industry: '',
    companySize: '',
    companyEmail: '',
    companyLogo: null,
    documents: null,
    paid: 'Yes'
  });
  const [loading, setLoading] = useState(false);
  const [applicationStatus, setApplicationStatus] = useState(null);
  const [errors, setErrors] = useState({});
  const [completedSteps, setCompletedSteps] = useState([]);
  const [showNotifications, setShowNotifications] = useState(false);
  const [showValidationPopup, setShowValidationPopup] = useState(false);
  const [validationMessage, setValidationMessage] = useState('');
  
  // Dummy email notifications data
  const [notifications, setNotifications] = useState([
    {
      id: 1,
      subject: "Welcome to Our Platform",
      date: "2024-02-14 10:30 AM",
      message: "Thank you for starting your registration process. We're excited to have you onboard!",
      read: false
    }
  ]);

  const markAsRead = (id) => {
    setNotifications(notifications.map(notif => 
      notif.id === id ? { ...notif, read: true } : notif
    ));
  };

  const NotificationsModal = () => (
    <div className={`notifications-modal ${showNotifications ? 'show' : ''}`}>
      <div className="notifications-content">
        <div className="notifications-header">
          <h3>Email Notifications</h3>
          <button 
            className="close-btn"
            onClick={() => setShowNotifications(false)}
          >
            ×
          </button>
        </div>
        <div className="notifications-list">
          {notifications.map(notification => (
            <div 
              key={notification.id} 
              className={`notification-item ${!notification.read ? 'unread' : ''}`}
              onClick={() => markAsRead(notification.id)}
            >
              <div className="notification-header">
                <span className="notification-subject">{notification.subject}</span>
                <span className="notification-date">{notification.date}</span>
              </div>
              <div className="notification-message">{notification.message}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );

  const validateEmail = (email) => {
    const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return re.test(email);
  };

  const validateStep1 = () => {
    const newErrors = {};
    if (!formData.companyName.trim()) {
      newErrors.companyName = 'Company name is required';
    }
    if (!formData.industry.trim()) {
      newErrors.industry = 'Industry is required';
    }
    if (!formData.companySize) {
      newErrors.companySize = 'Company size is required';
    }
    if (!formData.companyEmail.trim()) {
      newErrors.companyEmail = 'Email is required';
    } else if (!validateEmail(formData.companyEmail)) {
      newErrors.companyEmail = 'Please enter a valid email address';
    }
    if (!formData.companyLogo) {
      newErrors.companyLogo = 'Company logo is required';
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const validateStep2 = () => {
    const newErrors = {};
    if (!formData.documents) {
      newErrors.documents = 'Please upload required documents';
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleStepClick = (targetStep) => {
    // For step 2, validate step 1
    if (targetStep === 2 && step === 1) {
      if (!validateStep1()) {
        setValidationMessage('Please fill in the required fields.');
        setShowValidationPopup(true);
        return;
      }
    }

    // For step 3, validate step 2
    if (targetStep === 3) {
      if (step === 1 && !validateStep1()) {
        setValidationMessage('Please complete company information first.');
        setShowValidationPopup(true);
        return;
      }
      if (!formData.documents) {
        setValidationMessage('Please upload required documents first.');
        setShowValidationPopup(true);
        return;
      }
    }

    // If validation passes, update the step
    setStep(targetStep);
    
    // Add completed steps
    if (targetStep === 2) {
      setCompletedSteps(prev => [...new Set([...prev, 1])]);
    }
    if (targetStep === 3) {
      setCompletedSteps(prev => [...new Set([...prev, 1, 2])]);
    }
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
    // Clear error when user starts typing
    if (errors[name]) {
      setErrors(prev => ({
        ...prev,
        [name]: ''
      }));
    }
  };

  const handleFileChange = (e) => {
    const { name, files } = e.target;
    if (files.length > 0) {
      const file = files[0];
      setFormData(prev => ({
        ...prev,
        [name]: file
      }));
      // Clear error when file is selected
      if (errors[name]) {
        setErrors(prev => ({
          ...prev,
          [name]: ''
        }));
      }
      // Add a success message or filename display
      const fileInput = e.target;
      const fileLabel = fileInput.parentElement.querySelector('.file-name');
      if (fileLabel) {
        fileLabel.textContent = file.name;
      }
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);

    try {
      if (step === 1) {
        if (validateStep1()) {
          setCompletedSteps(prev => [...new Set([...prev, 1])]);
          setStep(2);
        }
      } else if (step === 2) {
        if (validateStep2()) {
          setCompletedSteps(prev => [...new Set([...prev, 2])]);
          setStep(3);
        }
      } else if (step === 3) {
        const result = await processApplication();
        setApplicationStatus(result);
        setCompletedSteps(prev => [...new Set([...prev, 3])]);
        
        // Simulate sending email
        console.log(`Email sent to ${formData.companyEmail}:
          Subject: Company Registration Application ${result.status.toUpperCase()}
          Body: ${result.message}
          Application ID: ${result.applicationId}
        `);
        
        // Add a new notification
        const newNotification = {
          id: notifications.length + 1,
          subject: `Application ${result.status.toUpperCase()}`,
          date: new Date().toLocaleString(),
          message: result.message,
          read: false
        };
        setNotifications(prev => [newNotification, ...prev]);
        
        // Wait before redirecting
        await new Promise(resolve => setTimeout(resolve, 3000));
        navigate('/company1');
      }
    } catch (error) {
      console.error('Error:', error);
      alert('An error occurred. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const renderStep1 = () => (
    <div className="registration-form">
      <h2>Company Registration</h2>
      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label htmlFor="companyName">Company Name</label>
          <input
            type="text"
            id="companyName"
            name="companyName"
            value={formData.companyName}
            onChange={handleInputChange}
            className={errors.companyName ? 'error' : ''}
          />
          {errors.companyName && <span className="error-message">{errors.companyName}</span>}
        </div>

        <div className="form-group">
          <label htmlFor="industry">Industry</label>
          <input
            type="text"
            id="industry"
            name="industry"
            value={formData.industry}
            onChange={handleInputChange}
            className={errors.industry ? 'error' : ''}
          />
          {errors.industry && <span className="error-message">{errors.industry}</span>}
        </div>

        <div className="form-group">
          <label htmlFor="companySize">Company Size</label>
          <select
            id="companySize"
            name="companySize"
            value={formData.companySize}
            onChange={handleInputChange}
            className={errors.companySize ? 'error' : ''}
          >
            <option value="">Select company size</option>
            <option value="0-50">small(less than or equal 50 employees)</option>
            <option value="51-100">medium(more than 50 and less than or equal 100 employess)</option>
            <option value="101-500">large(more than 100 and less than or equal 500)</option>
            <option value="501+">corporate(more than 500 employess)</option>
          </select>
          {errors.companySize && <span className="error-message">{errors.companySize}</span>}
        </div>

        <div className="form-group">
          <label htmlFor="companyEmail">Company Email</label>
          <input
            type="email"
            id="companyEmail"
            name="companyEmail"
            value={formData.companyEmail}
            onChange={handleInputChange}
            className={errors.companyEmail ? 'error' : ''}
          />
          {errors.companyEmail && <span className="error-message">{errors.companyEmail}</span>}
        </div>

        <div className="form-group">
          <label htmlFor="companyLogo">Company Logo</label>
          <div className="logo-upload-container">
            <div className="logo-preview">
              {formData.companyLogo ? (
                <img 
                  src={URL.createObjectURL(formData.companyLogo)} 
                  alt="Company Logo Preview" 
                  className="logo-preview-image"
                />
              ) : (
                <div className="logo-placeholder">
                  <span className="upload-icon">🖼️</span>
                  <span>Logo Preview</span>
                </div>
              )}
            </div>
            <div className="logo-upload-controls">
              <input
                type="file"
                id="companyLogo"
                name="companyLogo"
                accept="image/*"
                onChange={handleFileChange}
                className={`file-input ${errors.companyLogo ? 'error' : ''}`}
              />
              <label htmlFor="companyLogo" className="file-upload-label">
                <span className="upload-icon">📎</span>
                Choose Logo
              </label>
              <span className="file-name">
                {formData.companyLogo ? formData.companyLogo.name : 'No file chosen'}
              </span>
              <div className="file-info">
                <small>Accepted formats: PNG, JPG, JPEG (Max: 5MB)</small>
              </div>
            </div>
          </div>
          {errors.companyLogo && <span className="error-message">{errors.companyLogo}</span>}
        </div>
      </form>
    </div>
  );

  const renderStep2 = () => (
    <div className="registration-form document-upload-section">
      <h2>Company Verification Documents</h2>
      <div className="document-instructions">
        <h3>Required Documents</h3>
        <p>Please upload at least one of the following documents to verify your company's legitimacy:</p>
        <ul>
          <li>Business Registration Certificate</li>
          <li>Tax Registration Documents</li>
          <li>Company Incorporation Certificate</li>
          <li>Official Business License</li>
        </ul>
      </div>

      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label htmlFor="documents">Upload Verification Document</label>
          <div className="file-upload-container">
            <input
              type="file"
              id="documents"
              name="documents"
              accept=".pdf,.doc,.docx"
              onChange={handleFileChange}
              className={`file-input ${errors.documents ? 'error' : ''}`}
            />
            <label htmlFor="documents" className="file-upload-label">
              <span className="upload-icon">📎</span>
              Choose Document
            </label>
            <span className="file-name">
              {formData.documents ? formData.documents.name : 'No file chosen'}
            </span>
          </div>
          <div className="file-info">
            <small>Accepted formats: PDF, DOC, DOCX (Max: 10MB)</small>
          </div>
          {errors.documents && <span className="error-message">{errors.documents}</span>}
        </div>
      </form>
    </div>
  );

  const renderStep3 = () => (
    <div className="login-page">
      <div className="login-container">
        <button className="login-button">
          Login
        </button>
      </div>
    </div>
  );

  // Custom Popup Component
  const ValidationPopup = () => (
    <div className={`validation-popup ${showValidationPopup ? 'show' : ''}`}>
      <div className="validation-popup-content">
        <div className="validation-popup-header">
          <h3>Required Fields</h3>
          <button 
            className="close-btn"
            onClick={() => setShowValidationPopup(false)}
          >
            ×
          </button>
        </div>
        <div className="validation-popup-body">
          <span className="warning-icon">⚠️</span>
          <p>{validationMessage}</p>
        </div>
        <div className="validation-popup-footer">
          <button 
            className="ok-btn"
            onClick={() => setShowValidationPopup(false)}
          >
            OK
          </button>
        </div>
      </div>
    </div>
  );

  return (
    <div className="registration-container">
      <div className="header-actions" style={{ 
        width: '100%', 
        display: 'flex', 
        justifyContent: 'space-between',
        padding: '0 5%'
      }}>
        <button 
          className="notifications-btn"
          onClick={() => navigate('/login')}
          style={{ alignSelf: 'flex-start' }}
        >
          ← Back
        </button>
        <button 
          className="notifications-btn"
          onClick={() => setShowNotifications(true)}
        >
          📧 Notifications
          {notifications.some(n => !n.read) && <span className="notification-badge" />}
        </button>
      </div>
      
      <div className="registration-progress">
        <div 
          className={`progress-step ${step >= 1 ? 'active' : ''} ${completedSteps.includes(1) ? 'completed' : ''}`}
          onClick={() => handleStepClick(1)}
          role="button"
          tabIndex={0}
        >
          <div className="step-number">1</div>
          <div className="step-label">Company Information</div>
        </div>
        <div 
          className={`progress-step ${step >= 2 ? 'active' : ''} ${completedSteps.includes(2) ? 'completed' : ''}`}
          onClick={() => handleStepClick(2)}
          role="button"
          tabIndex={0}
        >
          <div className="step-number">2</div>
          <div className="step-label">Document Upload</div>
        </div>
        <div 
          className={`progress-step ${step >= 3 ? 'active' : ''} ${completedSteps.includes(3) ? 'completed' : ''}`}
          onClick={() => handleStepClick(3)}
          role="button"
          tabIndex={0}
        >
          <div className="step-number">3</div>
          <div className="step-label">Login</div>
        </div>
      </div>

      {step === 1 && renderStep1()}
      {step === 2 && renderStep2()}
      {step === 3 && renderStep3()}
      
      <NotificationsModal />
      <ValidationPopup />
    </div>
  );
};

export default CompanyRegistration; 