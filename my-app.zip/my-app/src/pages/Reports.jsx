import { useState } from 'react';
import {
  Box,
  Grid,
  Card,
  CardContent,
  Typography,
  Button,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Chip,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  TextField,
  Stack,
  Divider,
  LinearProgress,
  Tab,
  Tabs,
} from '@mui/material';
import {
  Description as DescriptionIcon,
  Assessment as AssessmentIcon,
  Flag as FlagIcon,
  CheckCircle as CheckCircleIcon,
  Cancel as CancelIcon,
  Schedule as ScheduleIcon,
  Business as BusinessIcon,
  Person as PersonIcon,
} from '@mui/icons-material';

// Dummy data for reports
const dummyReports = [
  {
    id: 1,
    studentName: 'Ahmed Mohamed',
    studentId: '2020-12345',
    companyName: 'Tech Solutions Inc.',
    supervisorName: 'Dr. Sarah Wilson',
    submissionDate: '2024-03-15',
    startDate: '2024-01-01',
    endDate: '2024-03-01',
    status: 'pending',
    major: 'Computer Science',
    content: 'During my internship at Tech Solutions Inc., I worked on developing a full-stack web application using React and Node.js. I implemented user authentication, real-time data visualization, and integrated third-party APIs. Key achievements include reducing page load time by 40% and implementing a new feature that increased user engagement by 25%.',
    feedback: '',
    rating: 4.5,
  },
  {
    id: 2,
    studentName: 'Sarah Ahmed',
    studentId: '2020-12346',
    companyName: 'Global Marketing Group',
    supervisorName: 'Dr. John Smith',
    submissionDate: '2024-03-14',
    startDate: '2024-01-01',
    endDate: '2024-03-01',
    status: 'flagged',
    major: 'Business Administration',
    content: 'As a marketing intern at Global Marketing Group, I assisted in planning and executing social media campaigns across multiple platforms. I conducted market research, created content calendars, and analyzed campaign metrics. The internship provided valuable insights into digital marketing strategies and analytics tools.',
    feedback: 'Please provide more details about the marketing campaigns you worked on and specific metrics achieved.',
    rating: 3.5,
  },
  {
    id: 3,
    studentName: 'Mohamed Hassan',
    studentId: '2020-12347',
    companyName: 'Tech Corp',
    supervisorName: 'Dr. Emily Brown',
    submissionDate: '2024-03-10',
    startDate: '2024-01-01',
    endDate: '2024-03-01',
    status: 'accepted',
    major: 'Computer Science',
    content: 'At Tech Corp, I worked on developing mobile applications using React Native. I implemented new features, fixed bugs, and optimized app performance. I also participated in code reviews and agile development processes. The experience enhanced my mobile development skills and understanding of software development lifecycle.',
    feedback: 'Excellent work and detailed documentation. Great demonstration of technical skills and professional growth.',
    rating: 5.0,
  },
  {
    id: 4,
    studentName: 'Nour Ibrahim',
    studentId: '2020-12348',
    companyName: 'FinTech Solutions',
    supervisorName: 'Dr. Michael Chen',
    submissionDate: '2024-03-08',
    startDate: '2024-01-15',
    endDate: '2024-03-15',
    status: 'accepted',
    major: 'Finance',
    content: 'My internship at FinTech Solutions focused on analyzing financial data and developing automated reporting systems. I worked with SQL databases, created Python scripts for data analysis, and developed financial models using Excel. I also assisted in preparing quarterly financial reports.',
    feedback: 'Strong analytical skills demonstrated. Excellent contribution to the automation project.',
    rating: 4.8,
  },
  {
    id: 5,
    studentName: 'Yara Mahmoud',
    studentId: '2020-12349',
    companyName: 'Creative Design Studio',
    supervisorName: 'Dr. Lisa Anderson',
    submissionDate: '2024-03-07',
    startDate: '2024-01-01',
    endDate: '2024-03-01',
    status: 'rejected',
    major: 'Graphic Design',
    content: 'Worked on various design projects including brand identity, website design, and marketing materials. Used Adobe Creative Suite to create visual content and participated in client meetings.',
    feedback: 'Report lacks specific details about projects and contributions. Please revise with more concrete examples and outcomes.',
    rating: 2.5,
  },
  {
    id: 6,
    studentName: 'Omar Khalil',
    studentId: '2020-12350',
    companyName: 'AI Research Lab',
    supervisorName: 'Dr. David Lee',
    submissionDate: '2024-03-05',
    startDate: '2024-01-01',
    endDate: '2024-03-01',
    status: 'pending',
    major: 'Computer Science',
    content: 'Participated in developing machine learning models for natural language processing. Implemented and tested various neural network architectures, worked with large datasets, and contributed to research papers. Gained experience in TensorFlow and PyTorch.',
    feedback: '',
    rating: 4.2,
  },
  {
    id: 7,
    studentName: 'Layla Hassan',
    studentId: '2020-12351',
    companyName: 'Global Consulting Firm',
    supervisorName: 'Dr. Sarah Thompson',
    submissionDate: '2024-03-03',
    startDate: '2024-01-01',
    endDate: '2024-03-01',
    status: 'flagged',
    major: 'Business Administration',
    content: 'Assisted in management consulting projects, conducted market research, and prepared client presentations. Worked with cross-functional teams and participated in client meetings.',
    feedback: 'Need more specific examples of your contributions to consulting projects. Please include quantitative results where possible.',
    rating: 3.8,
  }
];

// Statistics data
const statsData = {
  totalReports: 150,
  acceptedReports: 95,
  rejectedReports: 15,
  flaggedReports: 20,
  pendingReports: 20,
  averageReviewTime: '2.5 days',
  topCompanies: [
    { name: 'Tech Solutions Inc.', rating: 4.8, totalInterns: 25, acceptanceRate: '92%' },
    { name: 'Global Marketing Group', rating: 4.6, totalInterns: 20, acceptanceRate: '85%' },
    { name: 'Tech Corp', rating: 4.5, totalInterns: 18, acceptanceRate: '89%' },
    { name: 'FinTech Solutions', rating: 4.4, totalInterns: 15, acceptanceRate: '87%' },
    { name: 'AI Research Lab', rating: 4.3, totalInterns: 12, acceptanceRate: '83%' }
  ],
  majorDistribution: [
    { major: 'Computer Science', count: 45, successRate: '88%' },
    { major: 'Business Administration', count: 35, successRate: '82%' },
    { major: 'Finance', count: 25, successRate: '85%' },
    { major: 'Graphic Design', count: 15, successRate: '80%' },
    { major: 'Engineering', count: 30, successRate: '86%' }
  ],
  monthlySubmissions: [
    { month: 'January', count: 25 },
    { month: 'February', count: 35 },
    { month: 'March', count: 45 },
    { month: 'April', count: 30 },
    { month: 'May', count: 15 }
  ]
};

const statusColors = {
  pending: 'warning',
  flagged: 'error',
  accepted: 'success',
  rejected: 'error',
};

const statusIcons = {
  pending: <ScheduleIcon />,
  flagged: <FlagIcon />,
  accepted: <CheckCircleIcon />,
  rejected: <CancelIcon />,
};

function Reports() {
  const [reports, setReports] = useState(dummyReports);
  const [selectedStatus, setSelectedStatus] = useState('all');
  const [selectedMajor, setSelectedMajor] = useState('all');
  const [selectedReport, setSelectedReport] = useState(null);
  const [detailsOpen, setDetailsOpen] = useState(false);
  const [feedbackText, setFeedbackText] = useState('');
  const [currentTab, setCurrentTab] = useState(0);
  const [reportGenerateOpen, setReportGenerateOpen] = useState(false);

  const handleStatusChange = (event) => {
    setSelectedStatus(event.target.value);
  };

  const handleMajorChange = (event) => {
    setSelectedMajor(event.target.value);
  };

  const filteredReports = reports.filter((report) => {
    const matchesStatus = selectedStatus === 'all' || report.status === selectedStatus;
    const matchesMajor = selectedMajor === 'all' || report.major === selectedMajor;
    return matchesStatus && matchesMajor;
  });

  const handleViewDetails = (report) => {
    setSelectedReport(report);
    setFeedbackText(report.feedback);
    setDetailsOpen(true);
  };

  const handleUpdateStatus = (reportId, newStatus) => {
    setReports(
      reports.map((report) =>
        report.id === reportId
          ? { ...report, status: newStatus, feedback: feedbackText }
          : report
      )
    );
    setDetailsOpen(false);
  };

  const handleGenerateReport = () => {
    setReportGenerateOpen(true);
  };

  const handleCloseGenerateReport = () => {
    setReportGenerateOpen(false);
  };

  const StatCard = ({ title, value, icon: Icon, color = 'primary' }) => (
    <Card>
      <CardContent>
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 1 }}>
          <Icon color={color} />
          <Typography variant="h6" component="div">
            {value}
          </Typography>
        </Box>
        <Typography color="text.secondary" variant="body2">
          {title}
        </Typography>
      </CardContent>
    </Card>
  );

  return (
    <Box>
      <Typography variant="h4" gutterBottom>
        Internship Reports
      </Typography>

      <Box sx={{ display: 'flex', alignItems: 'center', mb: 4 }}>
        <Tabs 
          value={currentTab} 
          onChange={(e, newValue) => setCurrentTab(newValue)} 
          sx={{ flexGrow: 1 }}
        >
          <Tab label="Reports List" />
          <Tab label="Statistics" />
        </Tabs>
        {currentTab === 1 && (
          <Button
            variant="contained"
            color="warning"
            startIcon={<AssessmentIcon />}
            onClick={handleGenerateReport}
            sx={{ 
              ml: 2,
              bgcolor: '#ffc107',
              '&:hover': {
                bgcolor: '#ffb000',
              }
            }}
          >
            Generate Report
          </Button>
        )}
      </Box>

      {currentTab === 0 ? (
        <>
          <Grid container spacing={2} sx={{ mb: 4 }}>
            <Grid item xs={12} sm={6}>
              <FormControl fullWidth>
                <InputLabel>Filter by Status</InputLabel>
                <Select
                  value={selectedStatus}
                  label="Filter by Status"
                  onChange={handleStatusChange}
                >
                  <MenuItem value="all">All Reports</MenuItem>
                  <MenuItem value="pending">Pending</MenuItem>
                  <MenuItem value="flagged">Flagged</MenuItem>
                  <MenuItem value="accepted">Accepted</MenuItem>
                  <MenuItem value="rejected">Rejected</MenuItem>
                </Select>
              </FormControl>
            </Grid>
            <Grid item xs={12} sm={6}>
              <FormControl fullWidth>
                <InputLabel>Filter by Major</InputLabel>
                <Select
                  value={selectedMajor}
                  label="Filter by Major"
                  onChange={handleMajorChange}
                >
                  <MenuItem value="all">All Majors</MenuItem>
                  <MenuItem value="Computer Science">Computer Science</MenuItem>
                  <MenuItem value="Business Administration">Business Administration</MenuItem>
                </Select>
              </FormControl>
            </Grid>
          </Grid>

          <Grid container spacing={3} sx={{ mt: 2 }}>
            {filteredReports.map((report) => (
              <Grid 
                item 
                xs={12} 
                sm={6}
                md={4} 
                key={report.id} 
                sx={{ 
                  display: 'flex',
                  width: '100%'
                }}
              >
                <Card 
                  sx={{ 
                    width: '100%',
                    display: 'flex',
                    flexDirection: 'column',
                    transition: 'all 0.3s ease',
                    cursor: 'pointer',
                    '&:hover': {
                      transform: 'translateY(-8px)',
                      boxShadow: 6,
                    }
                  }}
                >
                  <CardContent 
                    sx={{ 
                      display: 'flex',
                      flexDirection: 'column',
                      height: '100%',
                      p: 3,
                      '&:last-child': { pb: 3 }
                    }}
                  >
                    <Box 
                      sx={{ 
                        display: 'flex', 
                        justifyContent: 'space-between', 
                        alignItems: 'flex-start',
                        mb: 2
                      }}
                    >
                      <Box>
                        <Typography variant="h6" gutterBottom>
                          {report.studentName}
                        </Typography>
                        <Typography color="text.secondary">
                          ID: {report.studentId}
                        </Typography>
                      </Box>
                      <Chip
                        icon={statusIcons[report.status]}
                        label={report.status.charAt(0).toUpperCase() + report.status.slice(1)}
                        color={statusColors[report.status]}
                      />
                    </Box>
                    <Stack spacing={1.5} sx={{ flex: 1 }}>
                      <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5 }}>
                        <BusinessIcon color="action" fontSize="small" />
                        <Typography variant="body2">
                          {report.companyName}
                        </Typography>
                      </Box>
                      <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5 }}>
                        <PersonIcon color="action" fontSize="small" />
                        <Typography variant="body2">
                          Supervisor: {report.supervisorName}
                        </Typography>
                      </Box>
                      <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5 }}>
                        <DescriptionIcon color="action" fontSize="small" />
                        <Typography variant="body2">
                          Submitted: {report.submissionDate}
                        </Typography>
                      </Box>
                    </Stack>
                    <Box 
                      sx={{ 
                        display: 'flex', 
                        justifyContent: 'flex-end',
                        mt: 'auto',
                        pt: 2
                      }}
                    >
                      <Button
                        variant="contained"
                        onClick={() => handleViewDetails(report)}
                        sx={{ minWidth: '120px' }}
                      >
                        View Details
                      </Button>
                    </Box>
                  </CardContent>
                </Card>
              </Grid>
            ))}
          </Grid>
        </>
      ) : (
        <Box>
          <Grid container spacing={3} sx={{ mb: 4 }}>
            <Grid item xs={12} sm={6} md={3}>
              <StatCard
                title="Total Reports"
                value={statsData.totalReports}
                icon={DescriptionIcon}
              />
            </Grid>
            <Grid item xs={12} sm={6} md={3}>
              <StatCard
                title="Accepted"
                value={statsData.acceptedReports}
                icon={CheckCircleIcon}
                color="success"
              />
            </Grid>
            <Grid item xs={12} sm={6} md={3}>
              <StatCard
                title="Flagged/Rejected"
                value={statsData.flaggedReports + statsData.rejectedReports}
                icon={FlagIcon}
                color="error"
              />
            </Grid>
            <Grid item xs={12} sm={6} md={3}>
              <StatCard
                title="Average Review Time"
                value={statsData.averageReviewTime}
                icon={AssessmentIcon}
              />
            </Grid>
          </Grid>

          <Typography variant="h6" gutterBottom sx={{ mt: 4 }}>
            Top Rated Companies
          </Typography>
          <Grid container spacing={3}>
            {statsData.topCompanies.map((company, index) => (
              <Grid item xs={12} sm={6} md={4} key={index}>
                <Card>
                  <CardContent>
                    <Typography variant="h6" gutterBottom>
                      {company.name}
                    </Typography>
                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                      <Typography variant="body1">Rating:</Typography>
                      <Typography variant="h6" color="primary">
                        {company.rating}
                      </Typography>
                    </Box>
                    <LinearProgress
                      variant="determinate"
                      value={(company.rating / 5) * 100}
                      sx={{ mt: 1 }}
                    />
                  </CardContent>
                </Card>
              </Grid>
            ))}
          </Grid>
        </Box>
      )}

      <Dialog open={detailsOpen} onClose={() => setDetailsOpen(false)} maxWidth="md" fullWidth>
        {selectedReport && (
          <>
            <DialogTitle>
              <Typography variant="h6">
                Internship Report Details
              </Typography>
              <Typography variant="subtitle1" color="text.secondary">
                {selectedReport.studentName} - {selectedReport.studentId}
              </Typography>
            </DialogTitle>
            <DialogContent>
              <Grid container spacing={3}>
                <Grid item xs={12} md={6}>
                  <Typography variant="subtitle1" gutterBottom>
                    Company Information
                  </Typography>
                  <Stack spacing={2}>
                    <Box>
                      <Typography variant="body2" color="text.secondary">
                        Company
                      </Typography>
                      <Typography variant="body1">
                        {selectedReport.companyName}
                      </Typography>
                    </Box>
                    <Box>
                      <Typography variant="body2" color="text.secondary">
                        Supervisor
                      </Typography>
                      <Typography variant="body1">
                        {selectedReport.supervisorName}
                      </Typography>
                    </Box>
                  </Stack>
                </Grid>
                <Grid item xs={12} md={6}>
                  <Typography variant="subtitle1" gutterBottom>
                    Internship Period
                  </Typography>
                  <Stack spacing={2}>
                    <Box>
                      <Typography variant="body2" color="text.secondary">
                        Start Date
                      </Typography>
                      <Typography variant="body1">
                        {selectedReport.startDate}
                      </Typography>
                    </Box>
                    <Box>
                      <Typography variant="body2" color="text.secondary">
                        End Date
                      </Typography>
                      <Typography variant="body1">
                        {selectedReport.endDate}
                      </Typography>
                    </Box>
                  </Stack>
                </Grid>
                <Grid item xs={12}>
                  <Divider sx={{ my: 2 }} />
                  <Typography variant="subtitle1" gutterBottom>
                    Report Content
                  </Typography>
                  <Typography variant="body1" paragraph>
                    {selectedReport.content}
                  </Typography>
                </Grid>
                <Grid item xs={12}>
                  <TextField
                    fullWidth
                    label="Feedback"
                    multiline
                    rows={4}
                    value={feedbackText}
                    onChange={(e) => setFeedbackText(e.target.value)}
                  />
                </Grid>
              </Grid>
            </DialogContent>
            <DialogActions>
              <Button onClick={() => setDetailsOpen(false)}>
                Cancel
              </Button>
              {selectedReport.status === 'pending' && (
                <>
                  <Button
                    color="error"
                    onClick={() => handleUpdateStatus(selectedReport.id, 'rejected')}
                  >
                    Reject
                  </Button>
                  <Button
                    color="warning"
                    onClick={() => handleUpdateStatus(selectedReport.id, 'flagged')}
                  >
                    Flag
                  </Button>
                  <Button
                    color="success"
                    variant="contained"
                    onClick={() => handleUpdateStatus(selectedReport.id, 'accepted')}
                  >
                    Accept
                  </Button>
                </>
              )}
            </DialogActions>
          </>
        )}
      </Dialog>

      <Dialog 
        open={reportGenerateOpen} 
        onClose={handleCloseGenerateReport}
        maxWidth="md"
        fullWidth
      >
        <DialogTitle>
          Generated Statistics Report
          <Typography variant="subtitle2" color="text.secondary">
            Generated on: {new Date().toLocaleString()}
          </Typography>
        </DialogTitle>
        <DialogContent>
          <Stack spacing={3}>
            <Box>
              <Typography variant="h6" gutterBottom>
                Overview
              </Typography>
              <Grid container spacing={2}>
                <Grid item xs={12} sm={6}>
                  <Typography variant="body2" color="text.secondary">
                    Total Reports
                  </Typography>
                  <Typography variant="h6">
                    {statsData.totalReports}
                  </Typography>
                </Grid>
                <Grid item xs={12} sm={6}>
                  <Typography variant="body2" color="text.secondary">
                    Average Review Time
                  </Typography>
                  <Typography variant="h6">
                    {statsData.averageReviewTime}
                  </Typography>
                </Grid>
              </Grid>
            </Box>

            <Divider />

            <Box>
              <Typography variant="h6" gutterBottom>
                Report Status Distribution
              </Typography>
              <Grid container spacing={2}>
                <Grid item xs={12} sm={6} md={3}>
                  <Typography variant="body2" color="text.secondary">
                    Accepted
                  </Typography>
                  <Typography variant="h6" color="success.main">
                    {statsData.acceptedReports}
                  </Typography>
                </Grid>
                <Grid item xs={12} sm={6} md={3}>
                  <Typography variant="body2" color="text.secondary">
                    Rejected
                  </Typography>
                  <Typography variant="h6" color="error.main">
                    {statsData.rejectedReports}
                  </Typography>
                </Grid>
                <Grid item xs={12} sm={6} md={3}>
                  <Typography variant="body2" color="text.secondary">
                    Flagged
                  </Typography>
                  <Typography variant="h6" color="error.main">
                    {statsData.flaggedReports}
                  </Typography>
                </Grid>
                <Grid item xs={12} sm={6} md={3}>
                  <Typography variant="body2" color="text.secondary">
                    Pending
                  </Typography>
                  <Typography variant="h6" color="warning.main">
                    {statsData.pendingReports}
                  </Typography>
                </Grid>
              </Grid>
            </Box>

            <Divider />

            <Box>
              <Typography variant="h6" gutterBottom>
                Top Performing Companies
              </Typography>
              <Stack spacing={2}>
                {statsData.topCompanies.map((company, index) => (
                  <Box key={index}>
                    <Typography variant="subtitle1">
                      {company.name}
                    </Typography>
                    <Box sx={{ display: 'flex', gap: 4, mt: 1 }}>
                      <Typography variant="body2" color="text.secondary">
                        Rating: {company.rating}
                      </Typography>
                      <Typography variant="body2" color="text.secondary">
                        Total Interns: {company.totalInterns}
                      </Typography>
                      <Typography variant="body2" color="text.secondary">
                        Acceptance Rate: {company.acceptanceRate}
                      </Typography>
                    </Box>
                  </Box>
                ))}
              </Stack>
            </Box>

            <Divider />

            <Box>
              <Typography variant="h6" gutterBottom>
                Major Distribution
              </Typography>
              <Grid container spacing={2}>
                {statsData.majorDistribution.map((major, index) => (
                  <Grid item xs={12} sm={6} md={4} key={index}>
                    <Typography variant="subtitle1">
                      {major.major}
                    </Typography>
                    <Box sx={{ mt: 1 }}>
                      <Typography variant="body2" color="text.secondary">
                        Count: {major.count}
                      </Typography>
                      <Typography variant="body2" color="text.secondary">
                        Success Rate: {major.successRate}
                      </Typography>
                    </Box>
                  </Grid>
                ))}
              </Grid>
            </Box>
          </Stack>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleCloseGenerateReport}>
            Close
          </Button>
          <Button 
            variant="contained" 
            color="warning"
            onClick={() => {
              handleCloseGenerateReport();
            }}
            sx={{ 
              bgcolor: '#ffc107',
              '&:hover': {
                bgcolor: '#ffb000',
              }
            }}
          >
            Download Report
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
}

export default Reports; 