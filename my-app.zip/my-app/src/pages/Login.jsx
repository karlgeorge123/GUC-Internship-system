// Login.jsx
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  Box, 
  TextField, 
  Button, 
  Typography, 
  Container, 
  Paper,
  Alert,
} from '@mui/material';
import { useTheme } from '../contexts/ThemeContext';

// User database with stronger passwords
const users = {
  'scad@guc.edu.eg': { password: 'Scad_2023!@#', role: 'scad' },
  'student@guc.edu.eg': { password: 'Student_2023!@#', role: 'student' },
  'pro@guc.edu.eg': { password: 'Pro_2023!@#', role: 'pro' },
  'company@guc.edu.eg': { password: 'Company_2023!@#', role: 'company' },
  'faculty@guc.edu.eg': { password: 'Faculty_2023!@#', role: 'faculty' }
};

function Login() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const navigate = useNavigate();
  const { darkMode } = useTheme();

  // No useEffect needed - redirection is now handled in the AuthRouter component

  const handleSubmit = (e) => {
    e.preventDefault();
    const lowerEmail = email.toLowerCase();
    console.log('Attempting login with:', lowerEmail);
    
    const user = users[lowerEmail];
    
    if (user && user.password === password) {
      try {
        // Store user data
        const userData = {
          email: lowerEmail,
          role: user.role,
        };
        
        // Clear previous data first
        localStorage.clear();
        
        // Set user data - ensure role is stored in both places for redundancy
        const userStr = JSON.stringify(userData);
        console.log('Login - Storing user data:', userStr);
        localStorage.setItem('user', userStr);
        localStorage.setItem('userRole', user.role);
        
        console.log('Login successful. Role:', user.role);
        console.log('Login - Verify localStorage:', {
          user: localStorage.getItem('user'),
          userRole: localStorage.getItem('userRole')
        });
        
        // Redirect based on role
        if (user.role === 'company') {
          window.location.href = '/company1';
        } else if (user.role === 'pro') {
          window.location.href = '/student-pro-profile';
        } else if (user.role === 'student') {
          window.location.href = '/student-profile';
        } else {
          // For other roles, go to the default route
          window.location.href = '/';
        }
        
      } catch (err) {
        console.error('Login error:', err);
        setError('An error occurred during login');
      }
    } else {
      console.log('Invalid credentials');
      setError('Invalid email or password');
    }

  };

  return (
      <Box
        sx={{
          minHeight: '100vh',
              display: 'flex',
              alignItems: 'center',
        justifyContent: 'center',
        bgcolor: 'background.default',
            }}
          >
      <Container maxWidth="xs">
            <Paper
          elevation={2}
              sx={{
            p: 4,
            borderRadius: 2,
            bgcolor: 'background.paper',
          }}
        >
          <Typography 
            variant="h4" 
            component="h1" 
            align="center" 
            gutterBottom
            color="primary"
            fontWeight="bold"
          >
            GUC Internship Portal
          </Typography>

          <Typography 
            variant="body1" 
            align="center" 
            sx={{ mb: 3, color: 'text.secondary' }}
          >
            Sign in to continue
          </Typography>

                {error && (
                  <Alert severity="error" sx={{ mb: 2 }}>
                    {error}
                  </Alert>
                )}

          <Box component="form" onSubmit={handleSubmit}>
                <TextField
                  margin="normal"
                  required
                  fullWidth
                  id="email"
                  label="Email Address"
                  name="email"
                  autoComplete="email"
                  autoFocus
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
              sx={{ mb: 2 }}
                />
            
                <TextField
                  margin="normal"
                  required
                  fullWidth
                  name="password"
                  label="Password"
                  type="password"
                  id="password"
                  autoComplete="current-password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
              sx={{ mb: 3 }}
                />
            
                <Button
                  type="submit"
                  fullWidth
                  variant="contained"
              size="large"
              sx={{ 
                py: 1.5,
                mb: 2,
                fontWeight: 'bold'
              }}
                >
                  Sign In
                </Button>
            
            <Box sx={{ textAlign: 'center', mt: 2 }}>
                  <Typography 
                    variant="body2" 
                    color="primary" 
                    sx={{ 
                      cursor: 'pointer',
                  '&:hover': { textDecoration: 'underline' }
                    }}
                    onClick={() => navigate('/company-registration')}
                  >
                    Sign up as a Company
                  </Typography>
                </Box>
              </Box>
            </Paper>
        </Container>
      </Box>

  );
}

export default Login;
