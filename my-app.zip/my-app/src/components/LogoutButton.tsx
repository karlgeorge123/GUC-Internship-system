import React from 'react';
import { LogOut } from 'lucide-react';
import { createPortal } from 'react-dom';

interface LogoutButtonProps {
  onLogout: () => void;
}

const LogoutButton = ({ onLogout }: LogoutButtonProps) => {
  return createPortal(
    <div 
      style={{
        position: 'absolute',
        left: '24px',
        bottom: '24px',
        zIndex: 9999,
      }}
    >
      <button
        className="flex items-center px-6 py-3 text-sm font-medium bg-white rounded-lg shadow-lg hover:bg-yellow-50 hover:text-yellow-600 transition-colors duration-200"
        onClick={onLogout}
      >
        <LogOut className="mr-3 h-5 w-5" aria-hidden="true" />
        Logout
      </button>
    </div>,
    document.body
  );
};

export default LogoutButton; 