import React from 'react';
import {
  Box,
  Grid,
  Typography,
  Card,
  CardContent,
  LinearProgress,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
} from '@mui/material';
import {
  Assessment as AssessmentIcon,
  School as SchoolIcon,
  Business as BusinessIcon,
  Group as GroupIcon,
} from '@mui/icons-material';

const ScadStatistics = () => {
  const statistics = {
    totalInternships: 450,
    activeCompanies: 85,
    totalStudents: 320,
    completionRate: '92%'
  };

  const departmentStats = [
    { department: 'Computer Science', students: 120, companies: 35, completionRate: 95 },
    { department: 'Engineering', students: 95, companies: 28, completionRate: 92 },
    { department: 'Business', students: 75, companies: 20, completionRate: 88 },
    { department: 'Information Systems', students: 30, companies: 12, completionRate: 93 }
  ];

  const topPerformers = [
    { name: 'Department of Computer Science', score: 95, progress: 95 },
    { name: 'Department of Engineering', score: 92, progress: 92 },
    { name: 'Department of Information Systems', score: 90, progress: 90 },
    { name: 'Department of Business', score: 88, progress: 88 }
  ];

  return (
    <Box sx={{ width: '100%', p: 3 }}>
      <Typography variant="h5" gutterBottom sx={{ mb: 4, fontWeight: 500, color: '#1976d2' }}>
        SCAD Office Statistics
      </Typography>

      <Grid container direction="row" spacing={3} sx={{ mb: 4 }}>
        <Grid item className="MuiGrid-direction-xs-row">
          <Card sx={{ 
            boxShadow: '0px 2px 1px -1px rgba(0,0,0,0.2),0px 1px 1px 0px rgba(0,0,0,0.14),0px 1px 3px 0px rgba(0,0,0,0.12)',
            minWidth: 200
          }}>
            <CardContent sx={{ p: 2 }}>
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                <AssessmentIcon color="primary" />
                <Typography variant="h6" sx={{ fontWeight: 500 }}>{statistics.totalInternships}</Typography>
              </Box>
              <Typography variant="body2" sx={{ mt: 1, color: 'text.secondary' }}>Total Internships</Typography>
            </CardContent>
          </Card>
        </Grid>

        <Grid item className="MuiGrid-direction-xs-row">
          <Card sx={{ 
            boxShadow: '0px 2px 1px -1px rgba(0,0,0,0.2),0px 1px 1px 0px rgba(0,0,0,0.14),0px 1px 3px 0px rgba(0,0,0,0.12)',
            minWidth: 200
          }}>
            <CardContent sx={{ p: 2 }}>
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                <BusinessIcon color="primary" />
                <Typography variant="h6" sx={{ fontWeight: 500 }}>{statistics.activeCompanies}</Typography>
              </Box>
              <Typography variant="body2" sx={{ mt: 1, color: 'text.secondary' }}>Active Companies</Typography>
            </CardContent>
          </Card>
        </Grid>

        <Grid item className="MuiGrid-direction-xs-row">
          <Card sx={{ 
            boxShadow: '0px 2px 1px -1px rgba(0,0,0,0.2),0px 1px 1px 0px rgba(0,0,0,0.14),0px 1px 3px 0px rgba(0,0,0,0.12)',
            minWidth: 200
          }}>
            <CardContent sx={{ p: 2 }}>
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                <GroupIcon color="primary" />
                <Typography variant="h6" sx={{ fontWeight: 500 }}>{statistics.totalStudents}</Typography>
              </Box>
              <Typography variant="body2" sx={{ mt: 1, color: 'text.secondary' }}>Total Students</Typography>
            </CardContent>
          </Card>
        </Grid>

        <Grid item className="MuiGrid-direction-xs-row">
          <Card sx={{ 
            boxShadow: '0px 2px 1px -1px rgba(0,0,0,0.2),0px 1px 1px 0px rgba(0,0,0,0.14),0px 1px 3px 0px rgba(0,0,0,0.12)',
            minWidth: 200
          }}>
            <CardContent sx={{ p: 2 }}>
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                <SchoolIcon color="primary" />
                <Typography variant="h6" sx={{ fontWeight: 500 }}>{statistics.completionRate}</Typography>
              </Box>
              <Typography variant="body2" sx={{ mt: 1, color: 'text.secondary' }}>Completion Rate</Typography>
            </CardContent>
          </Card>
        </Grid>
      </Grid>

      <Typography variant="h6" gutterBottom sx={{ mb: 3, fontWeight: 500 }}>
        Department Performance
      </Typography>

      <TableContainer component={Paper} sx={{ mb: 4, boxShadow: '0px 2px 1px -1px rgba(0,0,0,0.2),0px 1px 1px 0px rgba(0,0,0,0.14),0px 1px 3px 0px rgba(0,0,0,0.12)' }}>
        <Table>
          <TableHead>
            <TableRow>
              <TableCell>Department</TableCell>
              <TableCell align="right">Students</TableCell>
              <TableCell align="right">Companies</TableCell>
              <TableCell align="right">Completion Rate</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {departmentStats.map((row) => (
              <TableRow key={row.department}>
                <TableCell component="th" scope="row">
                  {row.department}
                </TableCell>
                <TableCell align="right">{row.students}</TableCell>
                <TableCell align="right">{row.companies}</TableCell>
                <TableCell align="right">{row.completionRate}%</TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>

      <Typography variant="h6" gutterBottom sx={{ mb: 3, fontWeight: 500 }}>
        Top Performing Departments
      </Typography>

      <Grid container direction="row" spacing={3}>
        {topPerformers.map((department, index) => (
          <Grid item key={index} className="MuiGrid-direction-xs-row">
            <Card sx={{ 
              boxShadow: '0px 2px 1px -1px rgba(0,0,0,0.2),0px 1px 1px 0px rgba(0,0,0,0.14),0px 1px 3px 0px rgba(0,0,0,0.12)',
              minWidth: 200
            }}>
              <CardContent sx={{ p: 2 }}>
                <Typography variant="h6" gutterBottom sx={{ fontWeight: 500 }}>
                  {department.name}
                </Typography>
                <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 1 }}>
                  <Typography variant="body1" sx={{ color: 'text.secondary' }}>Performance Score:</Typography>
                  <Typography variant="h6" sx={{ fontWeight: 500 }}>{department.score}</Typography>
                </Box>
                <LinearProgress
                  variant="determinate"
                  value={department.progress}
                  sx={{
                    height: 6,
                    borderRadius: 3,
                    backgroundColor: 'rgba(0, 0, 0, 0.1)',
                    '& .MuiLinearProgress-bar': {
                      borderRadius: 3,
                      backgroundColor: '#1976d2'
                    }
                  }}
                />
              </CardContent>
            </Card>
          </Grid>
        ))}
      </Grid>
    </Box>
  );
};

export default ScadStatistics; 