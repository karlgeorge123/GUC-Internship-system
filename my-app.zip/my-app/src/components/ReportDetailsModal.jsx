import React, { useState } from 'react';
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Button,
  Typography,
  TextField,
  Box,
  Divider,
} from '@mui/material';

const ReportDetailsModal = ({
  open,
  onClose,
  report,
  onStatusChange,
  onClarificationSubmit,
}) => {
  const [clarification, setClarification] = useState('');

  const handleClarificationSubmit = () => {
    onClarificationSubmit(report.id, clarification);
    setClarification('');
  };

  if (!report) return null;

  return (
    <Dialog open={open} onClose={onClose} maxWidth="md" fullWidth>
      <DialogTitle>
        Internship Report Details
      </DialogTitle>
      <DialogContent>
        <Box sx={{ mb: 3 }}>
          <Typography variant="h6" gutterBottom>
            Student Information
          </Typography>
          <Typography><strong>Name:</strong> {report.studentName}</Typography>
          <Typography><strong>Major:</strong> {report.major}</Typography>
          <Typography><strong>Submission Date:</strong> {report.submissionDate}</Typography>
          <Typography><strong>Status:</strong> {report.status}</Typography>
        </Box>

        <Divider sx={{ my: 2 }} />

        <Box sx={{ mb: 3 }}>
          <Typography variant="h6" gutterBottom>
            Report Content
          </Typography>
          <Typography variant="body1">
            {report.content}
          </Typography>
        </Box>

        {(report.status === 'flagged' || report.status === 'rejected') && (
          <Box sx={{ mt: 3 }}>
            <Typography variant="h6" gutterBottom>
              Submit Clarification
            </Typography>
            <TextField
              fullWidth
              multiline
              rows={4}
              value={clarification}
              onChange={(e) => setClarification(e.target.value)}
              placeholder="Enter your clarification here..."
              variant="outlined"
            />
          </Box>
        )}
      </DialogContent>
      <DialogActions>
        {(report.status === 'flagged' || report.status === 'rejected') && (
          <Button
            onClick={handleClarificationSubmit}
            variant="contained"
            color="primary"
            disabled={!clarification.trim()}
          >
            Submit Clarification
          </Button>
        )}
        <Button onClick={onClose} color="primary">
          Close
        </Button>
      </DialogActions>
    </Dialog>
  );
};

export default ReportDetailsModal; 